@echo off
TITLE EZ-CorridorKey
cd /d "%~dp0"

if exist "%~dp0hybrid.env.bat" call "%~dp0hybrid.env.bat"

REM DaVinci Resolve path (your install is non-standard)
if not defined CORRIDORKEY_RESOLVE_EXE set "CORRIDORKEY_RESOLVE_EXE=D:\New Folder\Resolve.exe"
if not defined CORRIDORKEY_RESOLVE_ROOT set "CORRIDORKEY_RESOLVE_ROOT=D:\New Folder"
if exist "%CORRIDORKEY_RESOLVE_EXE%" (
  echo Resolve: %CORRIDORKEY_RESOLVE_EXE%
) else (
  echo [WARN] Resolve.exe not found at %CORRIDORKEY_RESOLVE_EXE%
  echo        Run Install-Resolve-Bridge.bat to refresh paths.
)

REM AMD 4GB + CPU hybrid defaults (safe; CUDA still preferred if present)
if not defined CORRIDORKEY_OPT_MODE set "CORRIDORKEY_OPT_MODE=lowvram"
if not defined CORRIDORKEY_VRAM_GB set "CORRIDORKEY_VRAM_GB=4"
if not defined CORRIDORKEY_RAM_BUFFER_GB set "CORRIDORKEY_RAM_BUFFER_GB=10"

if not exist ".venv\Scripts\activate.bat" (
    echo [INFO] .venv not found. Running installer...
    call 1-install.bat
    if not exist ".venv\Scripts\activate.bat" (
        echo [ERROR] Installation failed. Please run 1-install.bat manually and check for errors.
        pause
        exit /b 1
    )
)

REM Add local ffmpeg to PATH if present
if exist "%~dp0tools\ffmpeg\bin\ffmpeg.exe" set "PATH=%~dp0tools\ffmpeg\bin;%PATH%"

call .venv\Scripts\activate.bat
start "" pythonw main.py %*
exit
