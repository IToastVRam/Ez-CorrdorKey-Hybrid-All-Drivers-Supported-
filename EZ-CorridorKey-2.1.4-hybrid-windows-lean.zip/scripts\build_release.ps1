#requires -Version 5.1
param(
  [switch]$StageOnly,
  [switch]$SkipZip,
  [switch]$IncludeCoreCheckpoints,
  [switch]$IncludeAllModels
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path (Join-Path $Root "main.py"))) {
  $Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}

$Version = "2.1.4-hybrid"
$vf = Join-Path $Root "VERSION"
if (Test-Path $vf) { $Version = (Get-Content $vf -Raw).Trim() }

$Release = Join-Path $Root "release"
$Stage = Join-Path $Release "stage"

Write-Host "EZ-CorridorKey release build v$Version" -ForegroundColor Cyan
Write-Host "Root: $Root"

if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Stage, $Release | Out-Null

# Always exclude these from GitHub portable package
$excludeDirNames = [System.Collections.Generic.HashSet[string]]::new(
  [string[]]@(
    ".venv", ".git", "release", "logs", "Output", "ClipsForInference", "Projects",
    "__pycache__", ".tmp", ".github", "node_modules"
  )
)

# Huge optional model trees - excluded unless flags set
if (-not $IncludeAllModels) {
  [void]$excludeDirNames.Add("stable-video-diffusion-img2vid-xt")
  # Keep VideoMaMaInferenceModule code but strip checkpoint binaries via filter later
}

function Should-SkipDir([string]$name) {
  return $excludeDirNames.Contains($name)
}

function Copy-TreeFiltered([string]$src, [string]$dst) {
  New-Item -ItemType Directory -Force -Path $dst | Out-Null
  Get-ChildItem $src -Force | ForEach-Object {
    if ($_.PSIsContainer) {
      if (Should-SkipDir $_.Name) {
        Write-Host "  skip dir $($_.Name)" -ForegroundColor DarkGray
        return
      }
      # Optional: skip entire VideoMaMa/GVM weight dumps
      if (-not $IncludeAllModels) {
        if ($_.FullName -match "VideoMaMaInferenceModule\\checkpoints\\stable-video") {
          Write-Host "  skip large SVD weights" -ForegroundColor DarkGray
          return
        }
        if ($_.FullName -match "gvm_core\\weights" -and -not $IncludeAllModels) {
          # copy structure placeholders only
          $target = Join-Path $dst $_.Name
          New-Item -ItemType Directory -Force -Path $target | Out-Null
          Set-Content (Join-Path $target "README_WEIGHTS.txt") "Download GVM weights via Install_GVM_Windows.bat" -Encoding ascii
          Write-Host "  stub gvm weights" -ForegroundColor DarkGray
          return
        }
      }
      Copy-TreeFiltered $_.FullName (Join-Path $dst $_.Name)
    } else {
      # Skip huge binaries unless included
      $ext = $_.Extension.ToLowerInvariant()
      $sizeMb = $_.Length / 1MB
      if (-not $IncludeAllModels) {
        if ($ext -in ".pth", ".pt", ".safetensors", ".bin", ".onnx" -and $sizeMb -gt 50) {
          if ($IncludeCoreCheckpoints -and $_.FullName -match "CorridorKeyModule\\checkpoints") {
            # keep core keyer weights
          } elseif ($IncludeCoreCheckpoints -and $_.FullName -match "BiRefNet" -and $sizeMb -lt 900) {
            # keep birefnet
          } elseif ($IncludeCoreCheckpoints -and $_.FullName -match "MatAnyone" -and $sizeMb -lt 200) {
            # keep matanyone
          } else {
            Write-Host "  skip weight $($_.Name) ($([math]::Round($sizeMb,1)) MB)" -ForegroundColor DarkGray
            return
          }
        }
      }
      if ($ext -eq ".pyc") { return }
      Copy-Item $_.FullName (Join-Path $dst $_.Name) -Force
    }
  }
}

Write-Host "Staging files..."
Copy-TreeFiltered $Root $Stage

# Ensure LICENSE exists for Inno
$licSrc = Join-Path $Root "LICENSE"
if (-not (Test-Path $licSrc)) {
  # Project uses CC-BY-NC-SA - check for LICENSE.md
  foreach ($c in @("LICENSE.md", "CorridorKeyModule\README.md")) {
    $p = Join-Path $Root $c
    if (Test-Path $p) {
      Copy-Item $p (Join-Path $Stage "LICENSE") -Force
      break
    }
  }
}
if (-not (Test-Path (Join-Path $Stage "LICENSE"))) {
  Set-Content (Join-Path $Stage "LICENSE") "See project README for license (CC-BY-NC-SA-4.0 components)." -Encoding ascii
}

# Portable readme
$pr = @"
EZ-CorridorKey $Version - Windows portable (hybrid GPU+CPU+RAM)

INSTALL (recommended)
1. Install Python 3.10-3.13 (Add to PATH)
2. Unzip this folder
3. Run installer\Install-Windows.bat
   OR installer\Install-Hybrid-GPU.bat (in-place)
4. Launch Desktop shortcut "EZ-CorridorKey Hybrid"

IN-PLACE
1. 1-install.bat
2. installer\Install-Hybrid-GPU.bat
3. 2-start-hybrid.bat

MODELS
Core CorridorKey weights: Install_CorridorKey_Windows.bat
GVM: Install_GVM_Windows.bat
VideoMaMa: Install_VideoMaMa_Windows.bat
(Large models are NOT in this portable zip.)

HYBRID ENV
CORRIDORKEY_DEVICE=auto|cuda|dml|cpu
CORRIDORKEY_VRAM_GB=4
CORRIDORKEY_RAM_BUFFER_GB=10
CORRIDORKEY_OPT_MODE=lowvram
CORRIDORKEY_HYBRID=1

DaVinci Resolve bridge (optional):
Install-Resolve-Bridge.bat
"@
Set-Content (Join-Path $Stage "PORTABLE-README.txt") $pr -Encoding ascii

# Copy VERSION
Copy-Item (Join-Path $Root "VERSION") (Join-Path $Stage "VERSION") -Force -ErrorAction SilentlyContinue

if ($StageOnly) {
  Write-Host "Stage only: $Stage"
  exit 0
}

if (-not $SkipZip) {
  Write-Host "Creating zip (this may take a while)..." -ForegroundColor Cyan
  $zipName = "EZ-CorridorKey-$Version-windows-portable.zip"
  $zipPath = Join-Path $Release $zipName
  if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
  Compress-Archive -Path (Join-Path $Stage "*") -DestinationPath $zipPath -CompressionLevel Optimal
  $mb = [math]::Round((Get-Item $zipPath).Length / 1MB, 2)
  Write-Host "  $zipPath ($mb MB)" -ForegroundColor Green
}

# Inno
$iscc = $null
foreach ($c in @(
  "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
  "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)) {
  if ($c -and (Test-Path $c)) { $iscc = $c; break }
}
if ($iscc) {
  Write-Host "Compiling Setup.exe..."
  & $iscc (Join-Path $Root "installer\EZ-CorridorKey.iss")
  $out = Get-ChildItem (Join-Path $Root "installer\Output") -Filter "EZ-CorridorKey-*-Setup.exe" -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($out) {
    Copy-Item $out.FullName $Release -Force
    Write-Host "  $($out.Name)" -ForegroundColor Green
  }
} else {
  Write-Host "Inno Setup not found - portable zip only (OK for GitHub)." -ForegroundColor Yellow
}

$sums = Join-Path $Release "SHA256SUMS.txt"
if (Test-Path $sums) { Remove-Item $sums -Force }
Get-ChildItem $Release -File | Where-Object { $_.Extension -in ".zip", ".exe" } | ForEach-Object {
  $h = (Get-FileHash $_.FullName -Algorithm SHA256).Hash
  $line = "$h  $($_.Name)"
  Write-Host $line
  Add-Content $sums $line -Encoding ascii
}

Write-Host ""
Write-Host "Done. Upload release\ to GitHub Releases." -ForegroundColor Green
