#requires -Version 5.1
# Build a GitHub-friendly portable zip under ~25 MB (no ffmpeg, no model weights).
param(
  [switch]$SkipZip
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path (Join-Path $Root "main.py"))) {
  $Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}

$Version = "2.1.4-hybrid"
$vf = Join-Path $Root "VERSION"
if (Test-Path $vf) { $Version = (Get-Content $vf -Raw).Trim() }

$Release = Join-Path $Root "release"
$Stage = Join-Path $Release "stage-lean"
$ZipName = "EZ-CorridorKey-$Version-windows-lean.zip"
$ZipPath = Join-Path $Release $ZipName

Write-Host "EZ-CorridorKey LEAN release v$Version (target under 25 MB)" -ForegroundColor Cyan

if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Stage, $Release | Out-Null

# Directory names never copied
$skipDirs = [System.Collections.Generic.HashSet[string]]::new([string[]]@(
  ".venv", ".git", ".github", "release", "logs", "Output", "ClipsForInference",
  "Projects", "__pycache__", ".tmp", "tools",  # tools/ffmpeg is ~700MB
  "docs", "tests", "docker"
))

# Path substrings that must not be packaged
$skipPathRegex = @(
  '\\tools\\',
  '\\checkpoints\\',
  '\\weights\\',
  '\\IgnoredCheckpoints\\',
  '\\sounds\\',                 # UI wavs ~7MB - optional UX
  '\\translations\\.*\.ts$',    # keep only .qm
  '\\fonts\\_download\\',
  '\\screenshots\\',
  '\\stable-video',
  '\\.cache\\'
)

# File extensions always skipped when large or binary weights
$skipExt = [System.Collections.Generic.HashSet[string]]::new([string[]]@(
  ".pth", ".pt", ".safetensors", ".bin", ".onnx", ".ckpt",
  ".mp4", ".mov", ".mkv", ".wav", ".flac", ".mp3",
  ".pyc", ".pyo"
))

function Test-SkipFile([System.IO.FileInfo]$f, [string]$rel) {
  if ($skipExt.Contains($f.Extension.ToLowerInvariant())) { return $true }
  foreach ($re in $skipPathRegex) {
    if ($rel -match $re) { return $true }
  }
  # Skip ffmpeg-related anywhere
  if ($f.Name -match '^(ffmpeg|ffprobe|ffplay)(\.exe)?$') { return $true }
  # Skip junk
  if ($f.Name -match '^(_w|_write_test|install-meta)') { return $true }
  return $false
}

function Copy-Lean([string]$src, [string]$dst, [string]$relBase = "") {
  New-Item -ItemType Directory -Force -Path $dst | Out-Null
  Get-ChildItem $src -Force -ErrorAction SilentlyContinue | ForEach-Object {
    $rel = if ($relBase) { Join-Path $relBase $_.Name } else { $_.Name }
    $relUnix = $rel -replace '/', '\'
    if ($_.PSIsContainer) {
      if ($skipDirs.Contains($_.Name)) { return }
      if ($_.Name -eq "checkpoints" -or $_.Name -eq "weights") {
        # Create placeholder only
        $ph = Join-Path $dst $_.Name
        New-Item -ItemType Directory -Force -Path $ph | Out-Null
        Set-Content (Join-Path $ph "DOWNLOAD.txt") "Run Install_CorridorKey_Windows.bat / Install_GVM_Windows.bat / Install_VideoMaMa_Windows.bat to fetch model weights." -Encoding ascii
        return
      }
      Copy-Lean $_.FullName (Join-Path $dst $_.Name) $rel
    } else {
      if (Test-SkipFile $_ $relUnix) { return }
      Copy-Item $_.FullName (Join-Path $dst $_.Name) -Force
    }
  }
}

Copy-Lean $Root $Stage

# Ensure hybrid/installer entrypoints present
foreach ($must in @(
  "main.py", "2-start-hybrid.bat", "2-start.bat", "1-install.bat",
  "installer\Install-Hybrid-GPU.bat", "installer\Install-Windows.bat",
  "backend\device_accel.py", "pyproject.toml", "requirements.txt"
)) {
  $p = Join-Path $Stage $must
  if (-not (Test-Path $p)) {
    $src = Join-Path $Root $must
    if (Test-Path $src) {
      $dir = Split-Path $p -Parent
      New-Item -ItemType Directory -Force -Path $dir | Out-Null
      Copy-Item $src $p -Force
    } else {
      Write-Host "WARN missing: $must" -ForegroundColor Yellow
    }
  }
}

# tools/ffmpeg stub + downloader
$ffdir = Join-Path $Stage "tools\ffmpeg"
New-Item -ItemType Directory -Force -Path $ffdir | Out-Null
@"
FFmpeg is NOT bundled (keeps the zip under 25 MB).

On first hybrid install, run:
  installer\Download-FFmpeg.ps1

Or install system FFmpeg and add it to PATH.
Windows builds: https://www.gyan.dev/ffmpeg/builds/
"@ | Set-Content (Join-Path $ffdir "README.txt") -Encoding ascii

# Small portable readme
@"
EZ-CorridorKey $Version - LEAN portable (<25 MB)

WHY SO SMALL?
- No bundled FFmpeg (~700 MB)
- No AI model weights (download after install)
- No tests/docs media/UI sound packs

INSTALL
1. Python 3.10-3.13 on PATH
2. Unzip
3. installer\Install-Windows.bat
   (or 1-install.bat then installer\Install-Hybrid-GPU.bat)
4. installer\Download-FFmpeg.ps1
5. Install_CorridorKey_Windows.bat  (core models ~800MB+)
6. 2-start-hybrid.bat

HYBRID GPU+CPU+RAM
CORRIDORKEY_DEVICE=auto|cuda|dml|cpu
CORRIDORKEY_VRAM_GB=4
CORRIDORKEY_RAM_BUFFER_GB=10
CORRIDORKEY_OPT_MODE=lowvram
"@ | Set-Content (Join-Path $Stage "PORTABLE-README.txt") -Encoding ascii

# LICENSE stub if needed
if (-not (Test-Path (Join-Path $Stage "LICENSE"))) {
  if (Test-Path (Join-Path $Root "LICENSE")) {
    Copy-Item (Join-Path $Root "LICENSE") (Join-Path $Stage "LICENSE")
  } else {
    Set-Content (Join-Path $Stage "LICENSE") "See upstream CorridorKey CC-BY-NC-SA-4.0 and project README." -Encoding ascii
  }
}

Copy-Item (Join-Path $Root "VERSION") (Join-Path $Stage "VERSION") -Force -ErrorAction SilentlyContinue

# Report size before zip
$stageBytes = (Get-ChildItem $Stage -Recurse -File -EA SilentlyContinue | Measure-Object Length -Sum).Sum
Write-Host ("Stage uncompressed: {0:N2} MB" -f ($stageBytes/1MB))

if (-not $SkipZip) {
  if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
  Compress-Archive -Path (Join-Path $Stage "*") -DestinationPath $ZipPath -CompressionLevel Optimal
  $zipMb = [math]::Round((Get-Item $ZipPath).Length / 1MB, 2)
  Write-Host "ZIP: $ZipPath ($zipMb MB)" -ForegroundColor Green
  if ($zipMb -ge 25) {
    Write-Host "WARNING: still >= 25 MB. Listing largest staged files:" -ForegroundColor Yellow
    Get-ChildItem $Stage -Recurse -File | Sort-Object Length -Descending | Select-Object -First 15 |
      ForEach-Object { "{0,8:N2} MB  {1}" -f ($_.Length/1MB), $_.FullName.Substring($Stage.Length+1) }
  } else {
    Write-Host "OK: under 25 MB target." -ForegroundColor Green
  }
  $sums = Join-Path $Release "SHA256SUMS-lean.txt"
  $h = (Get-FileHash $ZipPath -Algorithm SHA256).Hash
  Set-Content $sums "$h  $ZipName" -Encoding ascii
  Write-Host $h
}

Write-Host "Done."
