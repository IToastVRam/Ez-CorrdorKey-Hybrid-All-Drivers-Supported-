FFmpeg is NOT bundled (keeps the zip under 25 MB).

On first hybrid install, run:
  installer\Download-FFmpeg.ps1

Or install system FFmpeg and add it to PATH.
Windows builds: https://www.gyan.dev/ffmpeg/builds/
