"""Download model weights for EZ-CorridorKey.

Uses huggingface_hub for robust downloading with resume support,
progress bars, and idempotent behavior (skips existing files).

Usage:
    python scripts/setup_models.py --corridorkey       # Required (383MB)
    python scripts/setup_models.py --corridorkey-blue  # Blue screen variant (401MB)
    python scripts/setup_models.py --corridorkey-mlx   # Apple Silicon MLX weights (2x 380MB)
    python scripts/setup_models.py --sam2             # SAM2 Base+ (324MB)
    python scripts/setup_models.py --sam2 large       # SAM2 Large (898MB)
    python scripts/setup_models.py --gvm               # Optional (~6GB)
    python scripts/setup_models.py --videomama          # Optional (~37GB)
    python scripts/setup_models.py --matanyone2         # Optional (~141MB)
    python scripts/setup_models.py --all                # Everything
    python scripts/setup_models.py --check              # Status report
"""

from __future__ import annotations

import argparse
import glob
import hashlib
import importlib.util
import os
import platform
import shutil
import sys
import urllib.request
from pathlib import Path

_SCRIPT_ROOT = Path(__file__).resolve().parent.parent


def _proxy_guard():
    """Proxy sanitation for downloads; no-op when backend is unavailable.

    See backend/net_proxy.py: upgrades socks4 system proxies to socks5 for
    the duration of a download so httpx-based huggingface_hub can work.
    """
    try:
        if str(_SCRIPT_ROOT) not in sys.path:
            sys.path.insert(0, str(_SCRIPT_ROOT))
        from backend.net_proxy import sanitized_proxy_env
        return sanitized_proxy_env()
    except Exception:
        from contextlib import nullcontext
        return nullcontext()


def _data_root() -> Path:
    """Writable root for model downloads.

    In dev mode: project root (checkpoints live in CorridorKeyModule/checkpoints/).
    In frozen PyInstaller builds: delegates to backend.project.get_data_dir().
    Falls back to standalone logic when backend is not importable (script run directly).
    """
    if not getattr(sys, "frozen", False):
        return _SCRIPT_ROOT
    try:
        from backend.project import get_data_dir
        return Path(get_data_dir())
    except ImportError:
        pass
    # Standalone fallback (script run outside frozen app)
    try:
        from PySide6.QtCore import QSettings
        saved = QSettings().value("app/install_path", "", type=str)
        if saved and os.path.isdir(saved):
            return Path(saved)
    except Exception:
        pass
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "EZ-CorridorKey"
    elif sys.platform == "win32":
        return Path(os.environ.get("APPDATA", Path.home())) / "EZ-CorridorKey"
    else:
        return Path.home() / ".local" / "share" / "EZ-CorridorKey"


PROJECT_ROOT = _data_root()
HF_CACHE_DIR = Path.home() / ".cache" / "huggingface" / "hub"

# Built-in MLX engine weights (green + blue), hosted as GitHub release
# assets on our repo. Replaces the external corridorkey-mlx package that
# had quality complaints.
_MLX_RELEASE_BASE = (
    "https://github.com/edenaion/EZ-CorridorKey/releases/download/v2.1.0"
)
MLX_CHECKPOINTS = [
    {
        "url": f"{_MLX_RELEASE_BASE}/CorridorKey.mlx.safetensors",
        "sha256_url": f"{_MLX_RELEASE_BASE}/CorridorKey.mlx.safetensors.sha256",
        "filename": "CorridorKey.mlx.safetensors",
        "local_dir": PROJECT_ROOT / "CorridorKeyModule" / "checkpoints",
        "size_human": "380 MB",
        "size_bytes": 398_847_216,
    },
    {
        "url": f"{_MLX_RELEASE_BASE}/CorridorKeyBlue_1.0.mlx.safetensors",
        "sha256_url": f"{_MLX_RELEASE_BASE}/CorridorKeyBlue_1.0.mlx.safetensors.sha256",
        "filename": "CorridorKeyBlue_1.0.mlx.safetensors",
        "local_dir": PROJECT_ROOT / "CorridorKeyModule" / "checkpoints",
        "size_human": "380 MB",
        "size_bytes": 398_847_216,
    },
]

MODELS = {
    "corridorkey": {
        "repo_id": "nikopueringer/CorridorKey_v1.0",
        "filename": "CorridorKey_v1.0.pth",
        "local_dir": PROJECT_ROOT / "CorridorKeyModule" / "checkpoints",
        "check_glob": "*.pth",
        "size_human": "383 MB",
        "size_bytes": 400_000_000,
        "required": True,
    },
    "corridorkey-blue": {
        "repo_id": "nikopueringer/CorridorKeyBlue_1.0",
        "filename": "CorridorKeyBlue_1.0.pth",
        "local_dir": PROJECT_ROOT / "CorridorKeyModule" / "checkpoints",
        "check_file": "CorridorKeyBlue_1.0.pth",
        "size_human": "401 MB",
        "size_bytes": 420_000_000,
        "required": False,
    },
    "gvm": {
        "repo_id": "geyongtao/gvm",
        "local_dir": PROJECT_ROOT / "gvm_core" / "weights",
        "check_file": "unet/diffusion_pytorch_model.safetensors",
        "size_human": "~6 GB",
        "size_bytes": 6_500_000_000,
        "required": False,
    },
    "videomama": {
        "repo_id": "SammyLim/VideoMaMa",
        "local_dir": PROJECT_ROOT / "VideoMaMaInferenceModule" / "checkpoints",
        "check_file": "VideoMaMa/diffusion_pytorch_model.safetensors",
        "size_human": "~37 GB",
        "size_bytes": 40_000_000_000,
        "required": False,
        "base_model": {
            "repo_id": "stabilityai/stable-video-diffusion-img2vid-xt",
            "subfolder": "stable-video-diffusion-img2vid-xt",
            "check_file": "stable-video-diffusion-img2vid-xt/model_index.json",
        },
    },
}

MATANYONE2_CHECKPOINT = {
    "url": "https://github.com/pq-yang/MatAnyone2/releases/download/v1.0.0/matanyone2.pth",
    "filename": "matanyone2.pth",
    "local_dir": PROJECT_ROOT / "modules" / "MatAnyone2Module" / "checkpoints",
    "size_human": "141 MB",
    "size_bytes": 141_429_115,
}

# BiRefNet: 16 model variants all live under ZhengPeng7/ on HuggingFace.
# The setup wizard offers the default "Matting" variant as an optional
# pre-download (~940 MB) so installed macOS users don't hit a lazy
# write-to-.app-bundle path on first use. Users who skip this get the
# same model lazy-downloaded at first BiRefNet click — the wrapper's
# ``_resolve_model_dir`` routes that lazy download to the same writable
# location, so cold starts still work without pre-selection.
BIREFNET_DEFAULT_CHECKPOINT = {
    "repo_id": "ZhengPeng7/BiRefNet-matting",
    "repo_name": "BiRefNet-matting",
    "local_dir": PROJECT_ROOT / "modules" / "BiRefNetModule" / "checkpoints" / "BiRefNet-matting",
    "size_human": "~940 MB",
    "size_bytes": 940_000_000,
}

SAM2_MODELS = {
    "small": {
        "repo_id": "facebook/sam2.1-hiera-small",
        "filename": "sam2.1_hiera_small.pt",
        "size_human": "184 MB",
        "size_bytes": 184_000_000,
        "default": False,
    },
    "base-plus": {
        "repo_id": "facebook/sam2.1-hiera-base-plus",
        "filename": "sam2.1_hiera_base_plus.pt",
        "size_human": "324 MB",
        "size_bytes": 324_000_000,
        "default": True,
    },
    "large": {
        "repo_id": "facebook/sam2.1-hiera-large",
        "filename": "sam2.1_hiera_large.pt",
        "size_human": "898 MB",
        "size_bytes": 898_000_000,
        "default": False,
    },
}


def tracker_dependency_installed() -> bool:
    """Check whether the optional SAM2 Python package is installed.

    Probes sam2.build_sam, the exact module the runtime imports, rather
    than the bare top-level package so a broken partial install does not
    report as ready.
    """
    try:
        return importlib.util.find_spec("sam2.build_sam") is not None
    except Exception:
        return False


def is_installed(name: str) -> bool:
    """Check if a model's weights are already downloaded."""
    cfg = MODELS[name]
    local_dir = cfg["local_dir"]
    if "check_glob" in cfg:
        if len(glob.glob(str(local_dir / cfg["check_glob"]))) == 0:
            return False
    if "check_file" in cfg:
        if not (local_dir / cfg["check_file"]).is_file():
            return False
    # Also check base_model dependency if defined
    if "base_model" in cfg:
        base_check = cfg["base_model"].get("check_file")
        if base_check and not (local_dir / base_check).is_file():
            return False
    if "check_glob" not in cfg and "check_file" not in cfg:
        return False
    return True


def is_sam2_installed(name: str) -> bool:
    """Check whether a SAM2 checkpoint is present in the HF cache."""
    from huggingface_hub import try_to_load_from_cache
    from huggingface_hub.file_download import _CACHED_NO_EXIST

    cfg = SAM2_MODELS[name]
    cached = try_to_load_from_cache(
        repo_id=cfg["repo_id"],
        filename=cfg["filename"],
        cache_dir=HF_CACHE_DIR,
    )
    return isinstance(cached, str) and cached != _CACHED_NO_EXIST and os.path.isfile(cached)


def check_disk_space(needed_bytes: int, path: Path) -> bool:
    """Check if there's enough disk space for a download."""
    path.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(path)
    # Require 10% headroom beyond the download size
    return usage.free > needed_bytes * 1.1


def download_corridorkey() -> bool:
    """Download the CorridorKey checkpoint (single file)."""
    from huggingface_hub import hf_hub_download

    cfg = MODELS["corridorkey"]
    local_dir = cfg["local_dir"]
    local_dir.mkdir(parents=True, exist_ok=True)

    print(f"  Downloading CorridorKey checkpoint ({cfg['size_human']})...")
    try:
        downloaded = hf_hub_download(
            repo_id=cfg["repo_id"],
            filename=cfg["filename"],
            local_dir=str(local_dir),
        )
        # huggingface_hub downloads to local_dir/filename
        # The backend globs for *.pth, so the exact name doesn't matter
        print(f"  Saved to: {downloaded}")
        return True
    except Exception as e:
        print(f"  [ERROR] Download failed: {e}")
        print(f"  Manual download: https://huggingface.co/{cfg['repo_id']}")
        return False


def download_corridorkey_blue() -> bool:
    """Download the CorridorKey Blue checkpoint (single file)."""
    from huggingface_hub import hf_hub_download

    cfg = MODELS["corridorkey-blue"]
    local_dir = cfg["local_dir"]
    local_dir.mkdir(parents=True, exist_ok=True)

    print(f"  Downloading CorridorKey Blue checkpoint ({cfg['size_human']})...")
    try:
        downloaded = hf_hub_download(
            repo_id=cfg["repo_id"],
            filename=cfg["filename"],
            local_dir=str(local_dir),
        )
        print(f"  Saved to: {downloaded}")
        return True
    except Exception as e:
        print(f"  [ERROR] Download failed: {e}")
        print(f"  Manual download: https://huggingface.co/{cfg['repo_id']}")
        return False


def is_mlx_installed() -> bool:
    """Check if both MLX .safetensors checkpoints are already present."""
    return all(
        (cfg["local_dir"] / cfg["filename"]).is_file() for cfg in MLX_CHECKPOINTS
    )


def _download_mlx_one(cfg: dict, reporthook=None) -> bool:
    """Download one MLX checkpoint from GitHub Releases with SHA256 verify.

    *reporthook* follows the urllib.request.urlretrieve contract so callers
    (CLI progress, setup wizard progress bars) can plug their own. Does not
    require huggingface_hub.
    """
    local_dir = cfg["local_dir"]
    local_dir.mkdir(parents=True, exist_ok=True)
    dest = local_dir / cfg["filename"]

    if dest.is_file():
        print(f"  [OK] {cfg['filename']} already installed")
        return True

    if not check_disk_space(cfg["size_bytes"], local_dir):
        usage = shutil.disk_usage(local_dir)
        free_gb = usage.free / (1024**3)
        print(f"  [ERROR] Not enough disk space for {cfg['filename']} ({cfg['size_human']})")
        print(f"  Available: {free_gb:.1f} GB")
        return False

    print(f"  Downloading {cfg['filename']} ({cfg['size_human']})...")
    tmp_dest = dest.with_suffix(".safetensors.tmp")
    try:
        urllib.request.urlretrieve(cfg["url"], str(tmp_dest), reporthook=reporthook)
        print()  # newline after progress

        # Verify SHA256
        try:
            sha256_resp = urllib.request.urlopen(cfg["sha256_url"])
            expected_hash = sha256_resp.read().decode().strip().split()[0]
            actual_hash = hashlib.sha256(tmp_dest.read_bytes()).hexdigest()
            if actual_hash != expected_hash:
                print(f"  [ERROR] SHA256 mismatch!")
                print(f"  Expected: {expected_hash}")
                print(f"  Got:      {actual_hash}")
                tmp_dest.unlink(missing_ok=True)
                return False
            print(f"  [OK] SHA256 verified")
        except Exception as e:
            print(f"  [WARN] Could not verify SHA256: {e}")
            print("  Proceeding anyway (file downloaded successfully)")

        tmp_dest.rename(dest)
        print(f"  Saved to: {dest}")
        return True
    except Exception as e:
        print(f"\n  [ERROR] Download failed: {e}")
        print(f"  Manual download: {cfg['url']}")
        print(f"  Place in: {local_dir}/")
        tmp_dest.unlink(missing_ok=True)
        return False


def download_corridorkey_mlx() -> bool:
    """Download both MLX checkpoints (green + blue) from GitHub Releases."""

    def _progress(block_num, block_size, total_size):
        downloaded = block_num * block_size
        if total_size > 0:
            pct = min(100, downloaded * 100 // total_size)
            mb = downloaded / (1024 * 1024)
            total_mb = total_size / (1024 * 1024)
            print(f"\r  {mb:.0f}/{total_mb:.0f} MB ({pct}%)", end="", flush=True)

    ok = True
    for cfg in MLX_CHECKPOINTS:
        ok = _download_mlx_one(cfg, reporthook=_progress) and ok
    return ok


def download_sam2(name: str) -> bool:
    """Download a SAM2 checkpoint into the shared Hugging Face cache."""
    from huggingface_hub import hf_hub_download

    cfg = SAM2_MODELS[name]
    HF_CACHE_DIR.mkdir(parents=True, exist_ok=True)

    print(f"  Downloading SAM2 {name} checkpoint ({cfg['size_human']})...")
    try:
        downloaded = hf_hub_download(
            repo_id=cfg["repo_id"],
            filename=cfg["filename"],
            cache_dir=HF_CACHE_DIR,
        )
        print(f"  Saved to cache: {downloaded}")
        return True
    except Exception as e:
        print(f"  [ERROR] Download failed: {e}")
        print(f"  Manual download: https://huggingface.co/{cfg['repo_id']}")
        return False


def download_repo(name: str) -> bool:
    """Download a full HuggingFace repo (GVM or VideoMaMa)."""
    from huggingface_hub import snapshot_download

    cfg = MODELS[name]
    local_dir = cfg["local_dir"]
    local_dir.mkdir(parents=True, exist_ok=True)

    # Download base model dependency first (e.g. SVD for VideoMaMa)
    if "base_model" in cfg:
        base = cfg["base_model"]
        base_dir = local_dir / base["subfolder"]
        base_check = base.get("check_file")
        if base_check and (local_dir / base_check).is_file():
            print(f"  [OK] Base model already downloaded")
        else:
            print(f"  Downloading base model ({base['repo_id']})...")
            print("  This may take a while. Downloads resume if interrupted.")
            try:
                snapshot_download(
                    repo_id=base["repo_id"],
                    local_dir=str(base_dir),
                )
                print(f"  [OK] Base model saved to: {base_dir}")
            except Exception as e:
                print(f"  [ERROR] Base model download failed: {e}")
                print(f"  Manual download: https://huggingface.co/{base['repo_id']}")
                return False

    print(f"  Downloading {name} weights ({cfg['size_human']})...")
    print("  This may take a while. Downloads resume if interrupted.")
    try:
        snapshot_download(
            repo_id=cfg["repo_id"],
            local_dir=str(local_dir),
        )
        # SammyLim/VideoMaMa repo has unet/ but code expects VideoMaMa/
        if name == "videomama":
            unet_dir = local_dir / "unet"
            videomama_dir = local_dir / "VideoMaMa"
            if unet_dir.is_dir() and not videomama_dir.is_dir():
                unet_dir.rename(videomama_dir)
                print(f"  Renamed unet/ -> VideoMaMa/")
        print(f"  Saved to: {local_dir}")
        return True
    except Exception as e:
        print(f"  [ERROR] Download failed: {e}")
        print(f"  Manual download: https://huggingface.co/{cfg['repo_id']}")
        return False


def download_model(name: str) -> bool:
    """Download a model's weights, skipping if already present."""
    cfg = MODELS[name]

    if is_installed(name):
        print(f"  [OK] {name} weights already installed")
        return True

    # Disk space check
    if not check_disk_space(cfg["size_bytes"], cfg["local_dir"]):
        usage = shutil.disk_usage(cfg["local_dir"])
        free_gb = usage.free / (1024**3)
        print(f"  [ERROR] Not enough disk space for {name} ({cfg['size_human']})")
        print(f"  Available: {free_gb:.1f} GB")
        return False

    with _proxy_guard():
        if name == "corridorkey":
            return download_corridorkey()
        elif name == "corridorkey-blue":
            return download_corridorkey_blue()
        else:
            return download_repo(name)


def download_sam2_model(name: str) -> bool:
    """Download one SAM2 checkpoint, skipping if already cached."""
    cfg = SAM2_MODELS[name]

    if is_sam2_installed(name):
        print(f"  [OK] sam2-{name} checkpoint already cached")
        return True

    if not check_disk_space(cfg["size_bytes"], HF_CACHE_DIR):
        usage = shutil.disk_usage(HF_CACHE_DIR)
        free_gb = usage.free / (1024**3)
        print(f"  [ERROR] Not enough disk space for SAM2 {name} ({cfg['size_human']})")
        print(f"  Available: {free_gb:.1f} GB")
        return False

    with _proxy_guard():
        return download_sam2(name)


def is_matanyone2_installed() -> bool:
    """Check if the MatAnyone2 checkpoint is already present."""
    return (MATANYONE2_CHECKPOINT["local_dir"] / MATANYONE2_CHECKPOINT["filename"]).is_file()


def download_matanyone2() -> bool:
    """Download the MatAnyone2 checkpoint from GitHub Releases."""
    cfg = MATANYONE2_CHECKPOINT
    local_dir = cfg["local_dir"]
    local_dir.mkdir(parents=True, exist_ok=True)
    dest = local_dir / cfg["filename"]

    if dest.is_file():
        print(f"  [OK] MatAnyone2 checkpoint already installed")
        return True

    if not check_disk_space(cfg["size_bytes"], local_dir):
        usage = shutil.disk_usage(local_dir)
        free_gb = usage.free / (1024**3)
        print(f"  [ERROR] Not enough disk space for MatAnyone2 ({cfg['size_human']})")
        print(f"  Available: {free_gb:.1f} GB")
        return False

    print(f"  Downloading MatAnyone2 checkpoint ({cfg['size_human']})...")
    tmp_dest = dest.with_suffix(".pth.tmp")
    try:
        def _progress(block_num, block_size, total_size):
            downloaded = block_num * block_size
            if total_size > 0:
                pct = min(100, downloaded * 100 // total_size)
                mb = downloaded / (1024 * 1024)
                total_mb = total_size / (1024 * 1024)
                print(f"\r  {mb:.0f}/{total_mb:.0f} MB ({pct}%)", end="", flush=True)

        urllib.request.urlretrieve(cfg["url"], str(tmp_dest), reporthook=_progress)
        print()  # newline after progress

        tmp_dest.rename(dest)
        print(f"  Saved to: {dest}")
        return True
    except Exception as e:
        print(f"\n  [ERROR] Download failed: {e}")
        print(f"  Manual download: {cfg['url']}")
        print(f"  Place in: {local_dir}/")
        tmp_dest.unlink(missing_ok=True)
        return False


def is_birefnet_installed() -> bool:
    """Check if the default BiRefNet Matting variant is already downloaded.

    We only check for any .safetensors in the target directory because
    snapshot_download pulls a handful of files and any usable
    BiRefNet-matting snapshot will contain at least one .safetensors.
    """
    local_dir = BIREFNET_DEFAULT_CHECKPOINT["local_dir"]
    try:
        if not local_dir.is_dir():
            return False
        return any(p.suffix == ".safetensors" for p in local_dir.iterdir() if p.is_file())
    except OSError:
        return False


def download_birefnet() -> bool:
    """Download the default BiRefNet Matting variant to the data-dir path.

    The wrapper's ``_resolve_model_dir`` will find this at first use and
    skip the lazy runtime download entirely. Users who skip this during
    setup get the same content lazy-downloaded on demand — this is
    strictly a UX improvement for pre-selecting the default variant.
    """
    cfg = BIREFNET_DEFAULT_CHECKPOINT
    local_dir = cfg["local_dir"]
    local_dir.mkdir(parents=True, exist_ok=True)

    if is_birefnet_installed():
        print(f"  [OK] BiRefNet ({cfg['repo_name']}) already installed")
        return True

    if not check_disk_space(cfg["size_bytes"], local_dir):
        usage = shutil.disk_usage(local_dir)
        free_gb = usage.free / (1024**3)
        print(f"  [ERROR] Not enough disk space for BiRefNet ({cfg['size_human']})")
        print(f"  Available: {free_gb:.1f} GB")
        return False

    print(f"  Downloading BiRefNet ({cfg['repo_name']}, {cfg['size_human']})...")
    try:
        from huggingface_hub import snapshot_download
        with _proxy_guard():
            snapshot_download(
                repo_id=cfg["repo_id"],
                local_dir=str(local_dir),
                local_dir_use_symlinks=False,
            )
        print(f"  Saved to: {local_dir}")
        return True
    except Exception as e:
        print(f"\n  [ERROR] Download failed: {e}")
        print(f"  Manual download: https://huggingface.co/{cfg['repo_id']}")
        print(f"  Place in: {local_dir}/")
        return False


def check_all():
    """Print status of all models."""
    print("\nModel Status:")
    print("-" * 50)
    for name, cfg in MODELS.items():
        installed = is_installed(name)
        status = "INSTALLED" if installed else "NOT INSTALLED"
        required = " (required)" if cfg["required"] else " (optional)"
        mark = "[OK]" if installed else "[--]"
        print(f"  {mark} {name:12s} {cfg['size_human']:>8s}  {status}{required}")

        if installed and "check_glob" in cfg:
            files = glob.glob(str(cfg["local_dir"] / cfg["check_glob"]))
            for f in files:
                size_mb = os.path.getsize(f) / (1024**2)
                print(f"       -> {os.path.basename(f)} ({size_mb:.0f} MB)")

    # MatAnyone2 checkpoint
    ma2_installed = is_matanyone2_installed()
    ma2_mark = "[OK]" if ma2_installed else "[--]"
    ma2_status = "INSTALLED" if ma2_installed else "NOT INSTALLED"
    print(f"  {ma2_mark} matanyone2   {MATANYONE2_CHECKPOINT['size_human']:>8s}  {ma2_status} (optional)")

    # BiRefNet default Matting variant
    brn_installed = is_birefnet_installed()
    brn_mark = "[OK]" if brn_installed else "[--]"
    brn_status = "INSTALLED" if brn_installed else "NOT INSTALLED"
    print(f"  {brn_mark} birefnet     {BIREFNET_DEFAULT_CHECKPOINT['size_human']:>8s}  {brn_status} (optional)")

    # MLX checkpoint (Apple Silicon only, but show status on all platforms)
    mlx_installed = is_mlx_installed()
    mlx_mark = "[OK]" if mlx_installed else "[--]"
    mlx_status = "INSTALLED" if mlx_installed else "NOT INSTALLED"
    mlx_note = " (Apple Silicon)" if sys.platform == "darwin" and platform.machine() == "arm64" else " (Apple Silicon only)"
    print(f"  {mlx_mark} corridorkey-mlx {'2x 380 MB':>8s}  {mlx_status}{mlx_note}")

    tracker_installed = tracker_dependency_installed()
    tracker_mark = "[OK]" if tracker_installed else "[--]"
    tracker_status = "INSTALLED" if tracker_installed else "NOT INSTALLED"
    print(f"  {tracker_mark} sam2-tracker  python pkg   {tracker_status} (optional)")
    print(f"       -> cache: {HF_CACHE_DIR}")
    for name, cfg in SAM2_MODELS.items():
        installed = is_sam2_installed(name)
        status = "CACHED" if installed else "NOT CACHED"
        mark = "[OK]" if installed else "[--]"
        label = f"sam2-{name}"
        if cfg.get("default"):
            label += " (default)"
        print(f"  {mark} {label:18s} {cfg['size_human']:>8s}  {status}")
    print()


def main():
    parser = argparse.ArgumentParser(description="Download model weights for EZ-CorridorKey")
    parser.add_argument("--corridorkey", action="store_true", help="Download CorridorKey checkpoint (383MB, required)")
    parser.add_argument("--corridorkey-blue", action="store_true", help="Download CorridorKey Blue checkpoint (401MB, optional)")
    parser.add_argument("--corridorkey-mlx", action="store_true", help="Download MLX checkpoints for Apple Silicon, green and blue (380MB each)")
    parser.add_argument(
        "--sam2",
        nargs="?",
        const="base-plus",
        choices=["small", "base-plus", "large", "all"],
        help="Download SAM2 checkpoint(s): small, base-plus, large, or all (default: base-plus)",
    )
    parser.add_argument("--gvm", action="store_true", help="Download GVM weights (~6GB, optional)")
    parser.add_argument("--videomama", action="store_true", help="Download VideoMaMa weights (~37GB, optional)")
    parser.add_argument("--matanyone2", action="store_true", help="Download MatAnyone2 weights (~141MB, optional)")
    parser.add_argument("--birefnet", action="store_true", help="Download default BiRefNet Matting variant (~940MB, optional)")
    parser.add_argument("--all", action="store_true", help="Download all models")
    parser.add_argument("--check", action="store_true", help="Check installation status")
    args = parser.parse_args()

    mlx_flag = getattr(args, 'corridorkey_mlx', False)
    blue_flag = getattr(args, 'corridorkey_blue', False)

    # Default to --check if no flags
    if not any([args.corridorkey, blue_flag, mlx_flag, args.sam2, args.gvm, args.videomama, args.matanyone2, args.birefnet, args.all, args.check]):
        args.check = True

    if args.check:
        check_all()
        if not any([args.corridorkey, blue_flag, mlx_flag, args.sam2, args.gvm, args.videomama, args.matanyone2, args.birefnet, args.all]):
            return

    targets = []
    sam2_targets: list[str] = []
    download_mlx = False
    download_ma2 = False
    download_brn = False
    if args.all:
        targets = list(MODELS.keys())
        sam2_targets = list(SAM2_MODELS.keys())
        download_ma2 = True
        download_brn = True
        # --all on Apple Silicon auto-includes MLX weights
        if sys.platform == "darwin" and platform.machine() == "arm64":
            download_mlx = True
    else:
        if args.corridorkey:
            targets.append("corridorkey")
        if blue_flag:
            targets.append("corridorkey-blue")
        if mlx_flag:
            download_mlx = True
        if args.matanyone2:
            download_ma2 = True
        if args.birefnet:
            download_brn = True
        if args.sam2:
            if args.sam2 == "all":
                sam2_targets = list(SAM2_MODELS.keys())
            else:
                sam2_targets = [args.sam2]
        if args.gvm:
            targets.append("gvm")
        if args.videomama:
            targets.append("videomama")

    if not targets and not sam2_targets and not download_mlx and not download_ma2 and not download_brn:
        return

    total_targets = (
        len(targets)
        + len(sam2_targets)
        + (1 if download_mlx else 0)
        + (1 if download_ma2 else 0)
        + (1 if download_brn else 0)
    )
    print(f"\nDownloading {total_targets} model(s)...\n")
    results = {}
    for name in targets:
        print(f"[{name}]")
        results[name] = download_model(name)
        print()
    if download_mlx:
        print("[corridorkey-mlx]")
        results["corridorkey-mlx"] = download_corridorkey_mlx()
        print()
    if download_ma2:
        print("[matanyone2]")
        results["matanyone2"] = download_matanyone2()
        print()
    if download_brn:
        print("[birefnet]")
        results["birefnet"] = download_birefnet()
        print()
    for name in sam2_targets:
        result_key = f"sam2-{name}"
        print(f"[{result_key}]")
        results[result_key] = download_sam2_model(name)
        print()

    # Summary
    print("Summary:")
    for name, ok in results.items():
        print(f"  {'[OK]' if ok else '[FAIL]'} {name}")

    if not all(results.values()):
        sys.exit(1)


if __name__ == "__main__":
    main()
