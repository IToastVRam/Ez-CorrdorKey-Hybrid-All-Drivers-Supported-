EZ-CorridorKey 2.1.4-hybrid - LEAN portable (<25 MB)

WHY SO SMALL?
- No bundled FFmpeg (~700 MB)
- No AI model weights (download after install)
- No tests/docs media/UI sound packs

INSTALL
1. Python 3.10-3.13 on PATH
2. Unzip
3. installer\Install-Windows.bat
   (or 1-install.bat then installer\Install-Hybrid-GPU.bat)
4. installer\Download-FFmpeg.ps1
5. Install_CorridorKey_Windows.bat  (core models ~800MB+)
6. 2-start-hybrid.bat

HYBRID GPU+CPU+RAM
CORRIDORKEY_DEVICE=auto|cuda|dml|cpu
CORRIDORKEY_VRAM_GB=4
CORRIDORKEY_RAM_BUFFER_GB=10
CORRIDORKEY_OPT_MODE=lowvram
