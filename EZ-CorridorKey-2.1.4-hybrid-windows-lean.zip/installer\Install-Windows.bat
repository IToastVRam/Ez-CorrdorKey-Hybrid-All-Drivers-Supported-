@echo off
setlocal
cd /d "%~dp0\.."
title EZ-CorridorKey Windows Installer
echo.
echo  EZ-CorridorKey - Windows Installer (GPU+CPU+RAM hybrid)
echo  Installs to %%LOCALAPPDATA%%\EZ-CorridorKey
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Windows.ps1" -SourceRoot "%cd%"
echo.
pause
