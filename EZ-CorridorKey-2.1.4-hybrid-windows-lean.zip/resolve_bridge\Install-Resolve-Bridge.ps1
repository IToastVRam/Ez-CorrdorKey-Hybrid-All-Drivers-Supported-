# Install CorridorKey menu scripts into DaVinci Resolve Fusion Scripts paths.
# Paths CorridorKey <-> Resolve (your Resolve is at D:\New Folder).

$ErrorActionPreference = "Stop"
$CK = "E:\Dev\EZ-CorridorKey"
$Bridge = Join-Path $CK "resolve_bridge"
$ScriptsSrc = Join-Path $Bridge "scripts"
$PathsJson = Join-Path $Bridge "paths.json"

$ResolveExe = "D:\New Folder\Resolve.exe"
$ResolveRoot = "D:\New Folder"
if (-not (Test-Path $ResolveExe)) {
  # Try Start Menu shortcut
  $lnk = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Blackmagic Design\DaVinci Resolve\DaVinci Resolve.lnk"
  if (Test-Path $lnk) {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($lnk)
    if (Test-Path $sc.TargetPath) {
      $ResolveExe = $sc.TargetPath
      $ResolveRoot = Split-Path $ResolveExe -Parent
    }
  }
}

if (-not (Test-Path $ResolveExe)) {
  Write-Host "ERROR: Resolve.exe not found. Edit resolve_bridge\paths.json after install." -ForegroundColor Red
} else {
  Write-Host "Resolve: $ResolveExe" -ForegroundColor Green
}

# Write paths.json
$paths = @{
  corridor_key_root     = $CK
  corridor_start_bat    = (Join-Path $CK "2-start.bat")
  corridor_clips_in     = (Join-Path $CK "ClipsForInference")
  corridor_output       = (Join-Path $CK "Output")
  resolve_root          = $ResolveRoot
  resolve_exe           = $ResolveExe
  resolve_fuscript      = (Join-Path $ResolveRoot "fuscript.exe")
  resolve_scripts_user  = "$env:APPDATA\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts"
  resolve_scripts_system= "C:\ProgramData\Blackmagic Design\DaVinci Resolve\Fusion\Scripts"
  amd_hybrid            = $true
  vram_budget_gb        = 4
  notes                 = "Auto-installed by Install-Resolve-Bridge.ps1"
}
$paths | ConvertTo-Json | Set-Content -Path $PathsJson -Encoding UTF8

# Ensure folders
New-Item -ItemType Directory -Force -Path $paths.corridor_clips_in | Out-Null
New-Item -ItemType Directory -Force -Path $paths.corridor_output | Out-Null

# Deploy scripts to Resolve user + system Utility/Edit menus
$targets = @(
  $paths.resolve_scripts_user,
  $paths.resolve_scripts_system
)

$files = @(
  @{ Name = "CorridorKey_Open.py";          Menus = @("Utility", "Edit") },
  @{ Name = "CorridorKey_SendClip.py";      Menus = @("Edit", "Utility") },
  @{ Name = "CorridorKey_ImportOutput.py";  Menus = @("Edit", "Deliver", "Utility") }
)

foreach ($root in $targets) {
  if (-not $root) { continue }
  foreach ($f in $files) {
    $src = Join-Path $ScriptsSrc $f.Name
    if (-not (Test-Path $src)) {
      Write-Host "Missing source: $src" -ForegroundColor Yellow
      continue
    }
    foreach ($menu in $f.Menus) {
      $destDir = Join-Path $root $menu
      New-Item -ItemType Directory -Force -Path $destDir | Out-Null
      $dest = Join-Path $destDir $f.Name
      Copy-Item -Force $src $dest
      # Drop paths.json next to each script for local resolution
      Copy-Item -Force $PathsJson (Join-Path $destDir "paths.json")
      Write-Host "Installed: $dest"
    }
  }
}

# Desktop helper to re-run install / open CK linked to Resolve
$desktop = [Environment]::GetFolderPath("Desktop")
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut((Join-Path $desktop "CorridorKey (Resolve).lnk"))
$sc.TargetPath = (Join-Path $CK "2-start.bat")
$sc.WorkingDirectory = $CK
$sc.Description = "CorridorKey keyed for DaVinci Resolve at $ResolveRoot"
$sc.Save()

# Env helper for Resolve path (session + user)
[Environment]::SetEnvironmentVariable("CORRIDORKEY_RESOLVE_EXE", $ResolveExe, "User")
[Environment]::SetEnvironmentVariable("CORRIDORKEY_RESOLVE_ROOT", $ResolveRoot, "User")
[Environment]::SetEnvironmentVariable("CORRIDORKEY_ROOT", $CK, "User")

Write-Host ""
Write-Host "=== Done ===" -ForegroundColor Green
Write-Host "CorridorKey: $CK"
Write-Host "Resolve:     $ResolveExe"
Write-Host ""
Write-Host "In DaVinci Resolve (restart Resolve if it was open):"
Write-Host "  Workspace → Scripts → Utility → CorridorKey Open"
Write-Host "  Workspace → Scripts → Edit    → CorridorKey Send Clip"
Write-Host "  Workspace → Scripts → Edit    → CorridorKey Import Output"
Write-Host ""
Write-Host "If Scripts menu is empty: Preferences → System → General →"
Write-Host "  enable External scripting using: Local"
Write-Host ""
