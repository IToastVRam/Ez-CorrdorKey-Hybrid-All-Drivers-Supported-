"""DaVinci Resolve: send current timeline clip (or Media Pool selection) to CorridorKey.

Workspace → Scripts → Edit → CorridorKey Send Clip
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path


def _load() -> dict:
    cfg_paths = [
        Path(__file__).resolve().parent / "paths.json",
        Path(r"E:\Dev\EZ-CorridorKey\resolve_bridge\paths.json"),
    ]
    data = {}
    for cfg in cfg_paths:
        if cfg.exists():
            data = json.loads(cfg.read_text(encoding="utf-8"))
            break
    ck = Path(os.path.expandvars(data.get("corridor_key_root", r"E:\Dev\EZ-CorridorKey")))
    return {
        "ck": ck,
        "bat": Path(os.path.expandvars(data.get("corridor_start_bat", str(ck / "2-start.bat")))),
        "clips": Path(os.path.expandvars(data.get("corridor_clips_in", str(ck / "ClipsForInference")))),
        "output": Path(os.path.expandvars(data.get("corridor_output", str(ck / "Output")))),
        "resolve_exe": Path(os.path.expandvars(data.get("resolve_exe", r"D:\New Folder\Resolve.exe"))),
    }


def _msg(title: str, body: str) -> None:
    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(0, body, title, 0x40)
    except Exception:
        print(title, body)


def _get_resolve():
    # Inside Resolve Scripts menu
    try:
        return bmd.scriptapp("Resolve")  # type: ignore[name-defined]
    except Exception:
        pass
    try:
        import DaVinciResolveScript as dvr  # type: ignore

        return dvr.scriptapp("Resolve")
    except Exception:
        return None


def _clip_paths_from_resolve(resolve) -> list[str]:
    paths: list[str] = []
    if resolve is None:
        return paths
    pm = resolve.GetProjectManager()
    project = pm.GetCurrentProject() if pm else None
    if not project:
        return paths

    # 1) Media pool selected clips
    try:
        mp = project.GetMediaPool()
        folder = mp.GetCurrentFolder() if mp else None
        clips = folder.GetClipList() if folder else None
        if clips:
            for c in clips:
                try:
                    # Prefer selected — API varies by version
                    props = c.GetClipProperty() or {}
                    fp = props.get("File Path") or props.get("File Path") or c.GetClipProperty("File Path")
                    if fp and os.path.isfile(fp):
                        paths.append(fp)
                except Exception:
                    continue
    except Exception:
        pass

    # 2) Timeline current clip media path
    try:
        timeline = project.GetCurrentTimeline()
        if timeline:
            track_count = timeline.GetTrackCount("video") or 0
            for t in range(1, int(track_count) + 1):
                items = timeline.GetItemListInTrack("video", t) or []
                for item in items:
                    try:
                        mpi = item.GetMediaPoolItem()
                        if not mpi:
                            continue
                        fp = mpi.GetClipProperty("File Path")
                        if fp and os.path.isfile(fp) and fp not in paths:
                            paths.append(fp)
                    except Exception:
                        continue
    except Exception:
        pass

    return paths


def main() -> None:
    p = _load()
    p["clips"].mkdir(parents=True, exist_ok=True)
    p["output"].mkdir(parents=True, exist_ok=True)

    resolve = _get_resolve()
    media_paths = _clip_paths_from_resolve(resolve)

    if not media_paths:
        _msg(
            "CorridorKey Send Clip",
            "No media file paths found.\n\n"
            "Select clips in the Media Pool (or put clips on the timeline)\n"
            "that point to real files on disk, then run again.\n\n"
            f"Clips drop folder:\n{p['clips']}",
        )
        return

    copied = []
    for src in media_paths[:20]:
        name = Path(src).name
        dest = p["clips"] / name
        try:
            if Path(src).resolve() != dest.resolve():
                shutil.copy2(src, dest)
            copied.append(str(dest))
        except Exception as exc:
            copied.append(f"FAIL {src}: {exc}")

    # Launch CK
    env = os.environ.copy()
    env["CORRIDORKEY_OPT_MODE"] = "lowvram"
    env["CORRIDORKEY_VRAM_GB"] = "4"
    env["CORRIDORKEY_RESOLVE_EXE"] = str(p["resolve_exe"])
    env["CORRIDORKEY_RESOLVE_ROOT"] = str(p["resolve_exe"].parent)

    if p["bat"].exists():
        subprocess.Popen(["cmd.exe", "/c", "start", "", str(p["bat"])], cwd=str(p["ck"]), env=env)

    _msg(
        "CorridorKey Send Clip",
        f"Sent {len(copied)} clip(s) to CorridorKey:\n\n"
        + "\n".join(copied[:12])
        + ("\n…" if len(copied) > 12 else "")
        + f"\n\nCorridorKey folder:\n{p['clips']}\n\nResolve:\n{p['resolve_exe']}",
    )


if __name__ == "__main__":
    main()
