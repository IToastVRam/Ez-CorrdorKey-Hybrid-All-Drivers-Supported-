@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0resolve_bridge\Install-Resolve-Bridge.ps1"
echo.
pause
