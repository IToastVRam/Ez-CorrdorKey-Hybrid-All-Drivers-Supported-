# Publishing EZ-CorridorKey on GitHub

## What you ship

| Artifact | Description |
|----------|-------------|
| `EZ-CorridorKey-*-windows-portable.zip` | Code + hybrid installers (models downloaded separately) |
| `EZ-CorridorKey-*-Setup.exe` | Optional Inno Setup wrapper (if ISCC installed) |
| `SHA256SUMS.txt` | Checksums |

**Not bundled** (too large for GitHub): VideoMaMa SVD (~37GB), GVM weights (~6GB). Users run:

- `Install_CorridorKey_Windows.bat` — core keyer weights  
- `Install_GVM_Windows.bat` / `Install_VideoMaMa_Windows.bat` — optional  

Optional lean checkpoints in zip:

```powershell
.\scripts\build_release.ps1 -IncludeCoreCheckpoints
```

## Build

```powershell
cd E:\Dev\EZ-CorridorKey
.\scripts\build_release.ps1
```

## GitHub steps

1. Create repo (respect **CC-BY-NC-SA-4.0** on upstream CorridorKey components)
2. Push code (`.gitignore` should exclude `.venv`, `release/`, huge checkpoints)
3. Tag `v2.1.4-hybrid` and attach `release\*.zip` + `SHA256SUMS.txt`
4. Paste `PORTABLE-README.txt` into release notes

## End-user install

1. Python **3.10–3.13** on PATH  
2. Unzip → `installer\Install-Windows.bat`  
3. Desktop: **EZ-CorridorKey Hybrid**  
4. Download models via the Install_*_Windows.bat scripts if missing  

## Hybrid modes

| Mode | Flag | Use case |
|------|------|----------|
| NVIDIA | `CORRIDORKEY_DEVICE=cuda` | CUDA GPU |
| AMD | `CORRIDORKEY_DEVICE=dml` | DirectML + RAM |
| CPU | `CORRIDORKEY_DEVICE=cpu` | System RAM only |
| Auto | `CORRIDORKEY_DEVICE=auto` | Detect best |

VRAM/RAM budgets: `CORRIDORKEY_VRAM_GB`, `CORRIDORKEY_RAM_BUFFER_GB`, `CORRIDORKEY_OPT_MODE=lowvram`.
