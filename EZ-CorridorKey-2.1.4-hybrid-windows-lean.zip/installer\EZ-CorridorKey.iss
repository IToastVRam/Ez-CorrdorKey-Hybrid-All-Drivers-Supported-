; Inno Setup 6 - build after scripts\build_release.ps1 -StageOnly
#define MyAppName "EZ-CorridorKey"
#define MyAppVersion "2.1.4-hybrid"
#define MyAppPublisher "EZ-CorridorKey"
#define MyAppURL "https://github.com/YOUR_USER/EZ-CorridorKey"
#define StageDir "..\release\stage"

[Setup]
AppId={{A1C0FFEE-C0A1-4B2D-9E11-EZCORRIDORKEY01}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
DefaultDirName={localappdata}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
LicenseFile={#StageDir}\LICENSE
OutputDir=Output
OutputBaseFilename=EZ-CorridorKey-{#MyAppVersion}-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible
SetupLogging=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create Desktop shortcuts"; GroupDescription: "Icons:"

[Files]
Source: "{#StageDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName} Hybrid"; Filename: "{app}\2-start-hybrid.bat"; WorkingDir: "{app}"
Name: "{group}\{#MyAppName}"; Filename: "{app}\2-start.bat"; WorkingDir: "{app}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName} Hybrid"; Filename: "{app}\2-start-hybrid.bat"; WorkingDir: "{app}"; Tasks: desktopicon
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\2-start.bat"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "powershell.exe"; \
  Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\Install-Hybrid-GPU.ps1"" -SourceRoot ""{app}"""; \
  Flags: waituntilterminated; \
  StatusMsg: "Installing hybrid GPU+CPU+RAM stack (long first run)..."
Filename: "{app}\2-start-hybrid.bat"; Description: "Launch {#MyAppName} Hybrid"; Flags: nowait postinstall skipifsilent shellexec

[UninstallDelete]
Type: filesandordirs; Name: "{app}\.venv"
Type: filesandordirs; Name: "{app}\logs"
Type: filesandordirs; Name: "{app}\Output"
Type: filesandordirs; Name: "{app}\ClipsForInference"
