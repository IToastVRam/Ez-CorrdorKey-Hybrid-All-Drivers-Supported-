#requires -Version 5.1
<#
.SYNOPSIS
  User-level Windows installer for EZ-CorridorKey (GitHub portable package).
  Copies app to %LOCALAPPDATA%\EZ-CorridorKey, runs base install + hybrid GPU setup.
#>
param(
  [string]$InstallDir = "",
  [string]$SourceRoot = "",
  [switch]$Uninstall,
  [ValidateSet("auto", "cuda", "dml", "cpu")]
  [string]$Device = "auto"
)

$ErrorActionPreference = "Stop"
$AppName = "EZ-CorridorKey"

if (-not $SourceRoot) {
  $SourceRoot = Split-Path -Parent $PSScriptRoot
}
$SourceRoot = (Resolve-Path $SourceRoot).Path

if (-not $InstallDir) {
  $InstallDir = Join-Path $env:LOCALAPPDATA $AppName
}

$Desktop = [Environment]::GetFolderPath("Desktop")
$StartMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\$AppName"

function Remove-Shortcuts {
  foreach ($p in @(
    (Join-Path $Desktop "$AppName.lnk"),
    (Join-Path $Desktop "$AppName Hybrid.lnk"),
    (Join-Path $StartMenu "$AppName.lnk"),
    (Join-Path $StartMenu "$AppName Hybrid.lnk")
  )) {
    if (Test-Path $p) { Remove-Item $p -Force -ErrorAction SilentlyContinue }
  }
  if (Test-Path $StartMenu) {
    Remove-Item $StartMenu -Recurse -Force -ErrorAction SilentlyContinue
  }
}

if ($Uninstall) {
  Write-Host "Uninstalling $AppName from $InstallDir"
  Remove-Shortcuts
  if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force }
  Write-Host "Done."
  return
}

Write-Host "Installing $AppName"
Write-Host "  From: $SourceRoot"
Write-Host "  To:   $InstallDir"

if (-not (Test-Path (Join-Path $SourceRoot "main.py"))) {
  throw "Source root missing main.py"
}

# Robocopy-style copy excluding heavy runtime junk
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
$excludeDirs = @(
  ".venv", ".git", "release", "logs", "Output", "ClipsForInference",
  "__pycache__", ".tmp", "Projects"
)
# Use robocopy for reliability on large trees
$xd = ($excludeDirs | ForEach-Object { "/XD"; $_ })
$args = @($SourceRoot, $InstallDir, "/E", "/NFL", "/NDL", "/NJH", "/NJS", "/nc", "/ns", "/np") + $xd
& robocopy @args | Out-Null
# robocopy exit 0-7 = success
if ($LASTEXITCODE -ge 8) { throw "robocopy failed with code $LASTEXITCODE" }

# Strip huge optional model packs from install if user wants lean install - keep structure
# VideoMaMa/GVM are optional - leave whatever was in the package

Write-Host "Running hybrid GPU installer in target..."
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $InstallDir "installer\Install-Hybrid-GPU.ps1") `
  -SourceRoot $InstallDir -Device $Device

New-Item -ItemType Directory -Force -Path $StartMenu | Out-Null
$ws = New-Object -ComObject WScript.Shell
foreach ($pair in @(
  @{ Name = $AppName; Bat = "2-start.bat" },
  @{ Name = "$AppName Hybrid"; Bat = "2-start-hybrid.bat" }
)) {
  $bat = Join-Path $InstallDir $pair.Bat
  if (-not (Test-Path $bat)) { continue }
  foreach ($dir in @($Desktop, $StartMenu)) {
    $sc = $ws.CreateShortcut((Join-Path $dir "$($pair.Name).lnk"))
    $sc.TargetPath = $bat
    $sc.WorkingDirectory = $InstallDir
    $ico = Join-Path $InstallDir "ui\theme\corridorkey.ico"
    if (Test-Path $ico) { $sc.IconLocation = $ico }
    $sc.Save()
  }
}

@"
param()
& "`$PSScriptRoot\installer\Install-Windows.ps1" -InstallDir "`$PSScriptRoot" -Uninstall
"@ | Set-Content (Join-Path $InstallDir "Uninstall.ps1") -Encoding UTF8

Write-Host ""
Write-Host "Install complete: $InstallDir" -ForegroundColor Green
Write-Host "Launch: Desktop -> $AppName Hybrid"
