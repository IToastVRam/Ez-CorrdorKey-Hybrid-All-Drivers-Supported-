# Changelog

All notable changes to EZ-CorridorKey are documented here.

> **Updating:** Hotfix and patch releases (the third version number, like 2.1.1 or 2.1.2) ship as in-app updates only. They do not come with a fresh full installer. Get them by clicking the update button in the app, or run `3-update.bat` (Windows) or `3-update.sh` (macOS/Linux) for source installs.

---

## [2.1.4] - 2026-07-11 - Reliable video imports, verified FFmpeg builds, optional error reporting

> 2.1.4 ships as a Windows in-app auto-update. No new full installer this release; existing Windows apps update in place.

### Fixed

- **AI alpha generation no longer fails with "failed to read frame" or "Unrecognized option 'apply_trc'" on import or export.** Earlier versions could end up running an unverified FFmpeg build: a development nightly that writes corrupt frames under NVIDIA hardware decoding, or one missing options the app needs for export. The app now accepts only verified FFmpeg 8.1.2 full builds, so any other build (nightly, development, or too old) is caught and fixed with one click on Repair FFmpeg. If you already run a good 8.1.2 build you are not asked to change anything. Repair only ever installs into the app's own folder and never touches your system PATH. ([#184](https://github.com/edenaion/EZ-CorridorKey/issues/184))
- **The command-line installer now installs the same verified FFmpeg build.** `1-install.bat` used to download a rolling development nightly of FFmpeg, and its extraction step silently failed on machines with Git installed, leaving no bundled FFmpeg at all. It now installs the exact verified build the in-app Repair uses.
- **Every import is now integrity-checked.** Each extracted frame is verified readable; if corruption is detected the import automatically re-runs in a safe mode and only completes when every frame checks out.
- **Extraction failures are visible.** Failed imports show a dialog with fix steps instead of a stuck "Extracting frames..." viewer, and the RUN EXTRACTION button retries failed clips instead of doing nothing.
- **4K imports no longer fail on memory-constrained machines.** Frame encoding now adapts its memory use to what the machine has free, and a genuine out-of-memory condition reports a clear message instead of a raw codec error.

### Added

- **Optional direct error reports.** The Report Issue dialog can now also send the diagnostic summary you already see straight to the developer, controlled by a visible checkbox. The GitHub flow is unchanged.
- **Optional automatic crash reporting, off by default.** New users are asked once during setup; everyone can change it anytime in Preferences > Privacy. Nothing is ever sent unless you turn it on or file a report yourself, paths are anonymized, and media file names are never included. The README has a new Privacy section documenting exactly this.

---

## [2.1.3] - 2026-07-09 - AI alpha fix for non-ASCII user folders, installer repairs

> 2.1.3 ships as a Windows in-app auto-update. No new full installer this release; existing Windows apps update in place.

### Fixed

- **AI alpha generation now works when your Windows user folder contains accented or non-Latin characters.** GVM Auto, all BiRefNet variants, Dynamic Matting, and VideoMaMa failed with "Failed to read frame" errors for usernames like "José" or "Владимир", because the AI model modules bypassed the Unicode-safe file layer added in 2.1.1. Every model now reads and writes through it, and a build guard keeps this class of bug from returning. ([#184](https://github.com/edenaion/EZ-CorridorKey/issues/184))
- **The command-line installer's FFmpeg check works again.** An internal file reorganization left `1-install` pointing at a module that no longer exists, so the FFmpeg verification step always failed on every platform.
- **The updater repairs a broken branch setup instead of failing.** `3-update` now reconnects a checkout whose main branch lost its upstream, instead of stopping with "no tracking information".
- **The Windows updater reports failed updates honestly.** A scripting bug made `3-update.bat` print success and exit cleanly even when the code update failed. It now reports "Update INCOMPLETE" with a nonzero exit code, matching the Mac/Linux script.

### Added

- **Video tutorial in the installation guide.** The README links the creator's step-by-step walkthrough at the top of the Installation section, in all 17 languages.
- **Official site link.** The README now carries a Website badge pointing at [ezcorridorkey.com](https://ezcorridorkey.com).

---

## [2.1.2] - 2026-06-27 - FFmpeg import fix, update button, 2 new languages

> 2.1.2 ships as a Windows in-app auto-update. No new full installer this release; existing Windows apps update in place.

### Fixed

- **Video import no longer fails with "Unrecognized option 'vsync'".** Newer FFmpeg builds removed the old `-vsync` option, which broke frame extraction on those builds. Extraction now uses the current equivalent (`-fps_mode`), so imports work on every supported FFmpeg version. ([#175](https://github.com/edenaion/EZ-CorridorKey/issues/175))
- **Repair FFmpeg now installs a stable build.** The button previously downloaded a nightly development build that could be missing options the app relies on. It now fetches the latest stable FFmpeg release, validates it, and only then replaces your existing copy. A failed or interrupted repair restores the previous working FFmpeg instead of leaving you with none. ([#175](https://github.com/edenaion/EZ-CorridorKey/issues/175))
- **The update button no longer covers the VRAM meter.** It now sits in the top center of the title bar, clear of the GPU memory readout. ([#176](https://github.com/edenaion/EZ-CorridorKey/issues/176))
- **Eyedropper button label now translates in every language.** The "Pick Screen Color" button kept its English text in all translated interfaces because of an emoji-encoding mismatch in its translation key. It now appears in your selected language.

### Added

- **Two more interface languages: Ukrainian and Traditional Chinese.** EZ-CorridorKey now ships 16 languages. Traditional Chinese uses Taiwan VFX terminology, and first-run detection routes Taiwan, Hong Kong, and Macau to Traditional Chinese, mainland and Singapore to Simplified.
- **Show update notifications toggle.** Preferences > User Interface has a new switch to hide the update button and skip update checks entirely. ([#176](https://github.com/edenaion/EZ-CorridorKey/issues/176))

### Changed

- **Update checks now read published releases.** The app checks GitHub's latest release, the same source the updater installs from, instead of the development branch. The update button only appears when a downloadable update actually exists. ([#176](https://github.com/edenaion/EZ-CorridorKey/issues/176))

---

## [2.1.1] - 2026-06-17 - Non-ASCII paths, first-run language

> **Windows only.** 2.1.1 ships as a Windows auto-update. There is no macOS build for this release; macOS is moving to a fully native app (see the 2.1.0 note above).

### Fixed

- **Projects with non-ASCII folder names now work.** Projects whose path contains Cyrillic, CJK, Arabic, Hindi, or accented Latin characters showed blank input/output previews and produced no output, because OpenCV cannot open such paths on Windows. All image and video reads and writes now go through a Unicode-safe layer. ASCII paths are unchanged, so existing projects produce byte-identical output.
- **First-run language now matches the Preferences menu.** When the app detected your system language on first launch (for example Russian), the interface switched but the language dropdown still showed English. The detected language is now saved on first run, so the menu reflects the active language. Manually chosen languages are never overwritten.

---

## [2.1.0] - 2026-06-12 - Batch Pipeline, 14-language UI, fixes

> **Python macOS support ends with this release.** Starting with 2.1.1+, all macOS effort moves to a fully native Mac application, coming to the App Store shortly. Subscribe on [YouTube](https://www.youtube.com/@edenaion) for release updates.

### Added

- **UI translated into 14 languages:** German, Spanish, French, Hindi, Indonesian, Italian, Japanese, Korean, Polish, Portuguese, Russian, Turkish, Vietnamese, Chinese. Pick a language at the top of Preferences.
- **Language switching applies instantly:** changing the language in Preferences reloads the interface on the spot. No restart needed, and the open project, selected clip, and parameters carry over.
- **Built-in MLX inference engine** (macOS source installs): EZ-CorridorKey ships its own MLX model port for Apple Silicon, replacing the external `corridorkey_mlx` package that had quality complaints. Both green and blue checkpoints are converted to `.mlx.safetensors` format (380 MB each). Runs in float16 for roughly 2x speed (5.2s to 2.5s per frame at 1024 on an M1 Pro) with output verified at 52-67 dB PSNR on real 4K footage. Auto-detection routes green/blue clips to the correct MLX checkpoint on Apple Silicon and falls back to Torch/MPS elsewhere.
- **Apple Vision foreground hint** (macOS 14+ source installs): new APPLE VISION button in the Alpha Generation panel. Uses Apple's Neural Engine via `VNGenerateForegroundInstanceMaskRequest` to generate a foreground segmentation hint without any painting or annotation, with guided-filter edge refinement for clean mask borders. Auto-hidden on non-macOS platforms.
- **Batch Pipeline** — File > Batch Pipeline opens a dialog for batch-processing an entire folder of clips. Select a folder, configure which alpha generation model to use (GVM, BiRefNet, VideoMaMa, MatAnyone2), and run everything autonomously. Per-clip overrides let you mix models in the same batch. Live progress bars and checkmarks track each clip's status. Works with image sequence folders too: sequence subfolders are detected and can be mixed with videos in one batch.
- **Companion hint auto-detection** — when importing a video, files containing "alphahint" or "maskhint" anywhere in the filename (case insensitive) are automatically paired as hints instead of being imported as separate clips. AlphaHint files route to `AlphaHint.{ext}` at clip root; MaskHint files route to `VideoMamaMaskHint.{ext}`.
- **Frame sequence companion detection** — sibling folders or video files with "alphahint" or "maskhint" in their name are detected when importing frame sequences, same as video imports.
- **Tandem viewer pan and zoom:** panning or zooming either viewer now moves both viewers together, so input and output always show the same region. Double-click reset applies to both.
- **Left-drag panning:** drag with the left mouse button anywhere on a viewer to pan, no middle button required. Drawing, eyedropper, split divider, and wipe line keep priority over the pan. Double-click reset is unaffected, and a quick click right after a drag will not reset the view.

### Fixed

- **Menus, queue panel, status bar, and clip badges were untranslated:** the first translation pass missed every string routed through the main-window helper (File/Edit/View/Help menus and all menu actions), the queue tab and its job status labels, status bar progress phases, clip state badges, and thumbnail captions. All 605 strings are now extracted and translated in every language.
- **Queue items could not be dismissed:** the dismiss button on a queue row only appeared if the job was already finished when the row was drawn. Jobs that finished while displayed never got one. The button now appears the moment a job completes, is cancelled, or fails.
- **Status bar buttons truncated long translations:** RUN INFERENCE / RESUME / STOP now grow with their text instead of clipping.
- **CONTRIBUTING.md pointed to stale requirements.txt** — dev setup now recommends `pip install -e ".[dev]"` which installs from `pyproject.toml`, the canonical dependency source. ([#154](https://github.com/edenaion/EZ-CorridorKey/issues/154))
- **Queue panel covered the timeline:** the queue overlay now stops above the coverage bar, so the scrubber, completion lanes, and in/out bracket markers stay visible while the queue is open.
- **Right parameter panel loaded cut off:** the panel now opens at its full content width and can no longer be shrunk to the point of clipping controls on the right.
- **HDR clips failed frame extraction on FFmpeg 8:** ffprobe-style bt2020 matrix tags (bt2020nc and friends) are now mapped to the plain `bt2020` constant the FFmpeg 8 scale filter accepts, fixing EXR extraction for iPhone HDR footage. ([#91](https://github.com/edenaion/EZ-CorridorKey/issues/91))
- **Output writes failed on non-ASCII paths (Windows):** PNG and other image outputs are written through a unicode-safe encoder, so project paths with accented or non-Latin characters no longer break rendering.
- **Installer treated a broken NVIDIA driver as a working GPU:** the Windows installer now requires nvidia-smi to actually run before selecting CUDA wheels. A failing driver aborts the install with clear reinstall guidance instead of silently installing CPU-only PyTorch and failing verification with a confusing message. Resolves the recurring auto-filed reports. ([#159](https://github.com/edenaion/EZ-CorridorKey/issues/159), [#149](https://github.com/edenaion/EZ-CorridorKey/issues/149), [#136](https://github.com/edenaion/EZ-CorridorKey/issues/136), [#135](https://github.com/edenaion/EZ-CorridorKey/issues/135), [#124](https://github.com/edenaion/EZ-CorridorKey/issues/124), [#120](https://github.com/edenaion/EZ-CorridorKey/issues/120))
- **In-app updater was broken on Linux:** the Update button resolved the update script one directory level short of the project root, so clicking it did nothing. 3-update.sh also ignored the --relaunch flag the app passes, and a failed git pull still claimed success. All fixed: the script path resolves correctly, the app relaunches after updating, a failed pull reports "Update INCOMPLETE" with a nonzero exit, and a stale "Update Available" button re-validates when clicked and clears itself if the app is already up to date. The button also moved to a floating overlay so it no longer squishes at narrow window widths. ([#146](https://github.com/edenaion/EZ-CorridorKey/issues/146))
- **Download Manager showed SAM2 as installed when it was not:** the installed check now requires both the SAM2 Python package and the cached checkpoint, matching what track mask actually needs. The "SAM2 is not installed" error also reports the interpreter path and the underlying import error so environment mismatches are diagnosable. ([#157](https://github.com/edenaion/EZ-CorridorKey/issues/157))
- **Model downloads crashed behind socks4 system proxies:** users running V2Ray-family proxy clients hit "Unknown scheme for proxy URL" on any model not already cached. Downloads now upgrade socks4 to socks5 on the same port for the duration of the transfer, plain socks5 proxies work out of the box, and proxy misconfigurations surface as clear instructions instead of an unexpected error.
- **GVM AUTO produced a black alpha on Apple Silicon:** the float16 UNet/VAE triggered Metal NaN assertions on MPS. The GVM pipeline now runs in float32 with vanilla attention on Apple Silicon. ([#115](https://github.com/edenaion/EZ-CorridorKey/issues/115))
- **Import Alpha with EXR files produced a black alpha:** the import read path truncated float EXR data to zeros. EXR alphas now read at full depth.
- **Cmd key did not work for zoom or multi-select on macOS:** Cmd+scroll zoom and Cmd+click multi-select now behave like Ctrl on Windows and Linux.
- **Companion hint copied to wrong location** — `_copy_companion_alphahint` was copying hint files into `Source/` where they could be mistaken for the input video. Now correctly placed at the clip root where `find_assets()` discovers them.
- **MLX FG output blocky artifacts** — the external `corridorkey_mlx` package produced lower-quality foreground output. The built-in MLX engine eliminates this by using our own verified model port with proper `model.eval()`, correct weight transposition, and `pytorch_compatible=True` GroupNorm.
- **MLX mixed-precision to match torch.autocast** — LayerNorm, GroupNorm, BatchNorm, and softmax now run in float32 on MLX, matching PyTorch's autocast policy. Norm inputs are upcast to fp32, computed, then cast back to fp16 to prevent type promotion cascading through the graph. Softmax uses head-by-head fp32 processing for global attention blocks (16K+ tokens) to stay within 16 GB unified memory. Fixes blocky/stepped alpha edges on hair at 2048 resolution.
- **EXR alpha hints quantized to 8-bit on import** — importing EXR alpha hints previously converted them to 8-bit PNG, losing float precision. EXR files are now preserved as-is during import.
- **OpenEXR codec disabled at runtime** — `OPENCV_IO_ENABLE_OPENEXR` was set after `cv2` import in several modules, so OpenCV never enabled EXR read/write support. Now set before import in all entry points.
- **Out-of-range alpha from EXR** — `normalize_mask_dtype` now clips all mask values to [0, 1] regardless of source dtype, preventing rendering artifacts from EXR files with values outside unit range.
- **1px outline around subjects in the final matte:** the refiner additive guard took a plain per-pixel max of the model's alpha and the alpha hint, which burned the hint's edge over-coverage (generator slack, hint resizing) into the output as a thin line tracing the subject. The line sat inside the hint region, so the garbage matte could never remove it and appeared to "add" a border once surrounding gunk was cleared. The guard now trusts the model's own edge inside a thin shell around the solid silhouette and applies the full max() protection only beyond it, keeping detached hair strands protected. The garbage matte also binarizes the hint before dilation and feathers its cut boundary, so low pixel settings no longer scale down or hard-clip the subject edge. Applies to both CUDA and MLX engines.

### Changed

- **Setup wizard "Install path" renamed to "Data directory (models, projects, frame cache)"** so it is clear what the folder holds.
- **QComboBox disabled state** — added `QComboBox:disabled` style to the global theme so disabled dropdowns are visually distinct (darker background, dim text).

### Distribution

- Windows installer only. Linux stays supported through the source install scripts (1-install.sh). No macOS installer is published for this release; a Mac in-app update payload ships untested, update at your own risk (see the notice at the top). The native Mac app arrives on the App Store separately.
- Skinny update zip continues to strip all model weights (users get models via the setup wizard or the full installer).

---

## [2.0.0] - 2026-05-07 — Blue screen keying, chroma key holdout mask, eyedropper, i18n

### Added

- **Blue screen auto-detect** — CorridorKey now keys blue screens with the same quality as green. A new `CorridorKeyBlue_1.0.pth` checkpoint (401 MB) handles blue-screen footage natively. Detection runs automatically on clip selection: the middle frame is downsampled and analyzed in HSV to determine whether the dominant chroma is green or blue. The correct checkpoint loads transparently.
- **BG Color dropdown** — new Auto / Green / Blue selector above Color Space in the inference panel. Auto uses the detector; manual override forces a specific model regardless of frame content.
- **UI accent follows screen color** — when a blue clip is active, brand accent shifts from green (#2CC350) to blue (#0082CF) across the KEY text, slider knobs, and welcome button.
- **VideoMaMa mask import** — small + button next to the VIDEOMAMA button opens a file picker for importing pre-made alpha masks (video or image sequence). Grayscale values are crushed to binary (threshold at 127). Clip transitions to MASKED state, ready for VideoMaMa inference without SAM2 tracking.
- **Despeckle uncap** — spinbox range expanded from (50, 2000) to (0, 999999). Zero keeps everything; high values remove larger blobs. Requested by Nico (upstream).
- **FFmpeg Browse button** — Preferences gains a manual file picker for FFmpeg with bin/ auto-detection and path validation. Custom path persists in QSettings.
- **Blue checkpoint in Download Manager** — CorridorKey Blue appears in the setup wizard model list (after Green, before SAM2). Default checked for new installs. CLI: `python scripts/setup_models.py --corridorkey-blue`.
- **On-demand blue download** — when a blue clip is detected and the blue checkpoint is missing (skinny update / git clone users), a dialog offers to download it via the setup wizard.
- **Chroma key holdout mask** — paint foreground (1) and background (2) strokes directly on the chroma key preview to force regions. Background strokes force alpha to 0 (transparent), foreground strokes force alpha to 1 (opaque). The mask is static per-clip, applied to every frame. Strokes render as outlines so the matte preview shows through. Persists to `holdout_strokes.json`. Ctrl+Z undoes strokes, Ctrl+C clears all holdout strokes. Hotkeys 1/2 automatically route to holdout painting when chroma key mode is active, and to SAM2 annotation painting when it is not.
- **Garbage matte cleanup:** post-inference cleanup in the Inference section. Dilates the alpha hint by a configurable pixel amount and zeroes everything outside it, removing edge-of-frame artifacts and background gunk inference leaves behind. Works with any hint source (chroma key, BiRefNet, VideoMaMa, SAM2) and all engines.
- **First launch installs automatically:** the start scripts now run the installer when no virtual environment is found, so a fresh clone or zip starts with one click. ([#90](https://github.com/edenaion/EZ-CorridorKey/pull/90), thanks Benjamin Morgan)
- **Chroma key eyedropper drag-sampling** — the eyedropper (E) now samples a range of colors via click-drag instead of a single pixel click. A floating color chip shows the running average near the cursor. The keyer uses the 10th percentile screen excess across all samples for normalization, so dragging across shadows and hotspots produces a cleaner key than a single click.
- **Chroma key hotkey** — tilde (`` ` ``) toggles chroma key mode on/off.
- **Localization / i18n support** ([#109](https://github.com/edenaion/EZ-CorridorKey/issues/109)) — all 329 user-visible strings are marked for translation via Qt i18n. Language picker in Preferences. Translators can contribute by editing `.ts` files with Qt Linguist. See `ui/translations/TRANSLATING.md`.
- **Paint brush HUD overlay** — yellow text above the viewport shows current brush mode, size, and controls (Shift+drag to resize, Alt+drag for straight lines). Same overlay appears for both holdout and SAM2 paint modes.
- **Eyedropper HUD overlay** — yellow text above the viewport reminds users to click and drag across varied background tones for the best key.
- **Single-step slider scrolling** — all parameter panel sliders now move exactly one tick per scroll notch instead of Qt's default 3x multiplier.

### Fixed

- **SAM2 checkpoint validation** ([#116](https://github.com/edenaion/EZ-CorridorKey/issues/116)) — `torch.load()` crashed with `[Errno 22] Invalid argument` on Windows when the HuggingFace cached checkpoint was a pointer file or incomplete download. Added pre-load validation: checks file size (>10 MB) and ZIP magic bytes before passing to the model builder. Clear error message tells users to delete the cache folder and restart.
- **Triton compile warning spam** ([#127](https://github.com/edenaion/EZ-CorridorKey/issues/127)) — when torch.compile fails at runtime (e.g. Triton cache race on Windows), the warning now logs once at WARNING level instead of repeating for every engine in the pool. Subsequent engines log at DEBUG. Fallback to eager mode still works correctly.
- **FFmpeg SSL certificate failure on repair download** ([#117](https://github.com/edenaion/EZ-CorridorKey/issues/117)) — SSL verification now falls back through certifi, system default, then unverified, so corporate proxies and missing root CAs no longer block the FFmpeg auto-repair.
- **FFmpeg discovery on Windows** — extended search paths cover Scoop, Chocolatey, Downloads, and Desktop glob patterns.
- **Triton runtime hook** — catches `sysconfig.KeyError` in frozen PyInstaller builds that lack the sysconfig data module.
- **Despill parameterized for blue** — `despill()` swaps the suppression channel (green ch1 vs blue ch2) based on screen color. `_restore_opaque_source_detail()` spill detection likewise adapts.
- **All "green spill" tooltips** now read "screen spill" for neutrality.
- **Annotation strokes took seconds to appear on the other viewer:** overlays now sync between viewers immediately. The E hotkey also deactivates paint mode before entering the eyedropper, so the two cursor modes can no longer be active at once.
- **Middle-click reset did not work on spinboxes:** middle-clicking a spinbox now resets it to its default like the sliders do.

### Changed

- **Inference panel reordered to signal-chain order** (despeckle, garbage matte, despill, refiner) so controls follow the processing pipeline top to bottom.

### Distribution

- Full installers (Windows .exe, macOS .pkg) and portable zip now bundle both green and blue checkpoints.
- Skinny update zip remains code-only; blue checkpoint downloads on first use if missing.
- macOS skinny update zip now strips model checkpoints before re-signing and re-notarizing (324 MB instead of 2.4 GB). Mac users can receive in-app updates for the first time.
- Git cloners: `python scripts/setup_models.py --corridorkey-blue` or `--all`.

---

## [1.10.0] - 2026-04-16 — Project output dirs, wizard overhaul, frozen build fixes

> **Pascal (GTX 10-series) users**: 1.10.0 ships the same PyTorch build as 1.9.1 (torch 2.9.1 + cu130), which does **not** include Pascal GPU kernels. If you are running on a GTX 10-series card you will need to perform a one-time manual PyTorch swap inside the app's `_internal` folder -- see [docs/PASCAL-MANUAL-INSTALL.md](docs/PASCAL-MANUAL-INSTALL.md) for step-by-step instructions. The startup diagnostic will detect your card and link you to the guide automatically. All RTX 20-series and newer users are unaffected and can update normally via Help > Check for Updates.

> **macOS users on 1.9.x**: 1.10.0 does **not** auto-update on Mac. Help > Check for Updates has no Mac patch payload for this release. Download the new `EZ-CorridorKey-1.10.0-macOS-arm64.pkg` from Gumroad and run it manually. The installer replaces `/Applications/EZ-CorridorKey.app` in place. Your settings, projects, and any models you already downloaded live in `~/Library/Application Support/EZ-CorridorKey/` and carry over to the new version untouched. Mac auto-update returns in 1.11.0 or later once the update payload moves off GitHub Releases.

### Fixed
- **Preview panels empty after inference when a custom output directory is set** ([#86](https://github.com/edenaion/EZ-CorridorKey/issues/86)) — FG / Matte / Comp / Processed previews scanned `clip_root/Output/...` unconditionally and ignored the resolved output directory from per-clip and global "Default Output Directory" preferences. Users who pointed their output at an external path saw inference complete successfully but empty preview panels even though files existed on disk. The preview viewport now respects `clip.output_dir` everywhere.
- **Startup Diagnostic told installed-exe users to activate a `.venv` that doesn't exist** ([#89](https://github.com/edenaion/EZ-CorridorKey/issues/89)) — the fix-step list was hardcoded with developer instructions (`.venv\Scripts\activate`, `pip install ...`) that can't work on the frozen installer build and can't help users without an NVIDIA GPU at all. Diagnostic steps are now context-aware: frozen users get "reinstall the full installer" guidance, users without an NVIDIA card get honest "this app requires an NVIDIA GPU" messaging instead of a pip-install goose chase, and developer guidance is preserved only for source checkouts.
- **VideoMaMa and GVM couldn't find their checkpoints on installed builds** — `VideoMaMaInferenceModule` and `gvm_core` resolved checkpoint paths against their own `__file__` location, which in PyInstaller onedir builds lands under `_internal/`. Meanwhile the setup wizard downloaded weights to `backend.project.get_data_dir()`. The installer's download destination and the module's lookup path disagreed, so installed users hit FileNotFoundError on VideoMaMa base model load. Both modules now check the data dir first and fall back to the bundled directory.
- **BiRefNet and MatAnyone2 crashed on installed macOS builds with "Permission denied"** — both modules lazy-downloaded their checkpoints via `os.path.dirname(__file__) + "checkpoints"`, which on installed macOS builds resolves inside `/Applications/EZ-CorridorKey.app/Contents/Frameworks/modules/.../checkpoints` — a read-only path for non-admin users. Mac users clicking BiRefNet or MatAnyone2 for the first time hit `[Errno 13] Permission denied`. Both wrappers now use the same `_candidate_checkpoint_dirs()` data-dir-first pattern as VideoMaMa/GVM: lookups prefer the writable `<data_dir>/modules/<Name>/checkpoints` path and lazy downloads always target there. The bundled path stays as a read-only fallback for dev and manual installs.
- **BiRefNet OOMed on very large image sequences** ([#95](https://github.com/edenaion/EZ-CorridorKey/issues/95)) — a user running BiRefNet on a 109,192-frame 4K UHD EXR sequence hit a numpy `ArrayMemoryError` because `_load_named_sequence_frames` eagerly materialized every frame into a Python list before handing the batch to BiRefNet (~2.6 TiB of uint8 pixel data for that workload). The BiRefNet pipeline now streams frames through a new `_iter_named_sequence_frames` generator — exactly one frame lives in RAM at a time, regardless of clip length, so the upper bound is disk scan speed rather than system memory. No speed or quality impact for normal-sized clips. The guided-mode pipelines (GVM / VideoMaMa / MatAnyone2) still use the eager loader for now because their inner loops retain temporal context across frames; porting them to the streaming loader will come in a follow-up.
- **Hair strands lost in clean_matte despeckle** -- the despeckle pass treated thin hair strands as noise and erased them. Adjusted the morphological filter to preserve fine edge detail while still removing genuine speckle artifacts.
- **Refiner eroded input guide confidence** -- the refiner output was overwriting high-confidence regions from the input alpha guide with its own lower-confidence predictions. The refiner now only contributes where its confidence exceeds the input guide, preserving sharp edges on hair and fabric.
- **GVM rejected square input images** -- GVM auto alpha crashed on clips where width equals height because the aspect-ratio guard assumed landscape or portrait orientation. Square inputs are now accepted.
- **QHelpEvent crash in thumbnail tooltip handler** — every clip thumbnail hover logged an `AttributeError: 'QHelpEvent' object has no attribute 'position'` because the handler used the QMouseEvent-only `position()` / `globalPosition()` accessors on a `QHelpEvent`. Switched to the correct `pos()` / `globalPos()` calls. Visible as noise in user bug reports (e.g. the log attached to #95) but never actually broke the tooltip in practice because Qt silently swallows the exception inside `QWidget::event`.
- **SAM2 tracker crashed on repeated runs or after MatAnyone2** -- hydra's global state poisoned sam2's config registration. If diffusers or MatAnyone2 touched hydra first, sam2's YAML configs never registered and `compose()` failed with "GlobalHydra is not initialized." Now explicitly clears and re-initializes hydra with sam2's config module before every predictor build. Also added two-pass `reset_state` between forward/reverse propagation passes.
- **MatAnyone2 and imageio missing from frozen builds** ([#101](https://github.com/edenaion/EZ-CorridorKey/issues/101), [#103](https://github.com/edenaion/EZ-CorridorKey/issues/103)) -- the PyInstaller spec's `collect_data_files` silently dropped .py source files from the matanyone2 vendored package (only bundled .yaml configs). Added a custom tree walker to include all matanyone2 code. Also added `imageio` to `copy_metadata` and `hiddenimports` because `imageio/__init__.py` queries `importlib.metadata.version("imageio")` at import time and crashed with `PackageNotFoundError` on Auto GVM. Belt-and-braces: 22 packages now have explicit `copy_metadata` entries to prevent future hook regressions.
- **macOS spec under-specified** -- the macOS PyInstaller spec was missing most hiddenimports, collect_submodules, copy_metadata, and tree walkers that the Windows spec had. Mirrored all Windows hardening into the macOS spec.
- **Docker: unauthenticated services** — VNC now requires a password (was `-nopw`), filebrowser now requires login (was `--noauth`). Both use `EZ-CorridorKey` as the default password so local/single-user setups have one deterministic credential to remember. See [`docker/README.md`](docker/README.md) for how to change it.
- **Docker: ports bound to all interfaces** — all exposed ports (5900, 6080, 6081) now bind to `127.0.0.1` only, preventing LAN/WAN access.
- **macOS Processing backend switch needed an app restart** -- the Preferences > Processing backend dropdown saved the new MLX / MPS value to settings but the engine pool had already been lazy-loaded and was never dropped. Inference kept using the old backend until the next launch. The pool now clears when the backend selection changes so the next inference call rebuilds on the newly selected backend with no restart.

### Added
- **BiRefNet as an optional setup-wizard download** — the default `BiRefNet-matting` variant (~940 MB) can now be pre-downloaded from the setup wizard alongside GVM / MatAnyone2 / VideoMaMa. It is **off by default**; users who skip it still get the same model lazy-downloaded the first time they click BiRefNet in the app. Either path now writes to the writable data dir, so it works on installed macOS builds.
- **Mode buttons dim per-frame based on available outputs** — scrubbing through a clip now visually indicates which preview modes (MASK / ALPHA / FG / MATTE / COMP / PROC) have frames at the current position. Modes without data at the current stem are disabled and unclickable, so you can't accidentally click into an empty panel. The currently selected mode stays enabled through gaps, and the viewport falls back to showing the input frame in those gaps so the screen is never blank. Selection resumes automatically when you scrub back into a range where the selected mode has data.
- **Clip resolution in the preview header** — the info bar now shows the clip's actual dimensions (e.g. `182 frames · 1920x1080 · READY`) instead of the uninformative static `sequence` / `video` label.
- **Install method in Report Issue system info** — every bug report now includes a distinct install-method label (`Windows Installer (.exe)`, `Portable (frozen)`, `macOS .app (pkg/dmg)`, `git clone (venv)`, `GitHub source zip (no .git, venv)`, etc.) so issue triage can immediately tell how a user installed the app instead of guessing from error output.
- **Per-project output directory** -- File > Set Project Output Folder lets you set a shared output location for all clips in a project. Priority chain: per-clip > per-project > global preference > default `Output/` folder. Persists to `project.json`.
- **Ko-fi donation link in About dialog** -- Help > About now includes a link to support development.
- **DCRepublic credited in About dialog** -- added to Special Thanks for Docker integration.
- **Download Manager in Edit menu** -- model downloads moved from Preferences to Edit > Download Manager so they are always accessible without opening the preferences dialog.
- **Signed release manifests** -- every GitHub release now ships `manifest.json` + `manifest.json.sig` (Ed25519 signature). The in-app updater verifies the signature against a baked-in public key before applying any update. If the signature is invalid or the downloaded zip's SHA-256 doesn't match the manifest, the update is rejected and the user is warned. Pre-signing releases (1.9.x and earlier) still work without a manifest.
- **SHA-256 checksums on releases** -- build scripts now auto-generate `dist/SHA256SUMS.txt` with hashes for all release artifacts. Uploaded alongside binaries so users can manually verify downloads.
- **Git commit signing** -- all commits to `main` must be signed (Ed25519 SSH key). Branch protection ruleset enforces this.
- **SECURITY.md** -- vulnerability disclosure policy with GitHub private advisory and email contact.
- **CONTRIBUTING.md** -- contributor guidelines adapted from upstream, covering dev setup, PR workflow, and code style.

### Changed
- **Startup Diagnostic dialog** — fix-step guidance branches on `sys.frozen` and NVIDIA GPU presence so users see advice that actually applies to their install.
- **Pascal-on-cu130 startup advisory repurposed** — the Pascal-detection diagnostic added in the 1.10 dev cycle now links users to [docs/PASCAL-MANUAL-INSTALL.md](docs/PASCAL-MANUAL-INSTALL.md) for a manual torch 2.8.0+cu128 swap, instead of directing them to a nonexistent Pascal-ready installer. 1.10.0 does not bundle a different PyTorch build from 1.9.1 — Pascal users need the manual workaround.
- Updated EZSCAPE Discord link in README.

### Known limitations
- **GTX 10-series / Pascal GPUs still crash with "CUDA error: no kernel image is available"** ([#87](https://github.com/edenaion/EZ-CorridorKey/issues/87)) — 1.9.1 and 1.10.0 both ship PyTorch 2.9.1 cu130 wheels which omit sm_60/61 GPU kernels. The dev cycle for 1.10 attempted to pin back to torch 2.8.0 + cu128 (the last release still covering Pascal) but the strategy was reverted because it would have forced a full reinstall for every user on the in-app update path and broken compatibility between the older installed runtime and the new Python code. Instead, Pascal users can manually replace the bundled PyTorch with a Pascal-compatible wheel in place — see [docs/PASCAL-MANUAL-INSTALL.md](docs/PASCAL-MANUAL-INSTALL.md). A startup diagnostic detects the mismatch automatically and links to the guide.

### Developer notes
- New regression firewall: `tests/test_update_zip_exclusions.py` asserts that `build_update_zip.py`'s `EXCLUDE_DIRS` always contains `torch`, `torch.libs`, `torchvision`, `torchvision.libs`, `triton`, and `nvidia`. The in-app updater uses `xcopy` to overlay code-only updates on top of existing installs, so those exclusions are the mechanism that protects existing users' torch runtime from being overwritten between releases. Removing any of them would break every existing user on the next release. Do not relax this test casually.
- New defensive tests: `tests/test_pascal_cu130_diagnostic.py` covers every Pascal / RTX / error-state / broken-torch combination for the runtime advisory, including seven "must never raise" tests that pin the startup-safety contract.
- New regression firewall: `tests/test_module_checkpoint_paths.py` asserts that the BiRefNet and MatAnyone2 wrappers expose a `_candidate_checkpoint_dirs()` helper whose first entry is routed through `backend.project.get_data_dir()` rather than `os.path.dirname(__file__)`. This is the Mac read-only-bundle regression guard.
- New regression firewall: `tests/test_birefnet_streaming.py` stress-tests the BiRefNet frame loader against a synthetic 100,001-frame sequence (comfortably past the 109,192-frame workload that triggered #95) and asserts that (a) `_iter_named_sequence_frames` is a real lazy generator, (b) exactly one frame lives in memory at any time during iteration, (c) `BiRefNetProcessor.process_frames` accepts a bare Python generator rather than requiring a list, and (d) the eager `_load_named_sequence_frames` still returns a list for backwards compat.
- Pinned `sam-2` tracker dependency to commit `2b90b9f5ceec` for reproducible builds.
- New supply-chain tooling: `scripts/generate_signing_key.py` (one-time Ed25519 keygen), `scripts/sign_release.py` (release manifest signer), `backend/update_verify.py` (runtime signature + hash verification). See AGENTS.md "Supply-chain security" section for full workflow.
- Added `cryptography>=43.0` to dependencies for Ed25519 signature verification in the updater.

---

## [1.9.0] - 2026-04-09 — Windows Installer, macOS App, Export Overhaul

> **Fresh install required** — due to the codebase refactor, existing Desktop App installations cannot use the in-app updater for this release. Please download and install v1.9.0 fresh. The in-app updater will return for future patch releases (v1.9.1+).

### Added
- **Windows installer** — one-click `.exe` installer with dark-themed setup wizard, desktop shortcut, and Start Menu entry. Requires NVIDIA GPU (GTX 10-series or newer).
- **Windows portable** — standalone ZIP, no installer or registry. Unzip to a USB stick or any folder and run. All data (models, projects, logs) stays next to the exe.
- **macOS app bundle** — native `.app` with first-launch setup wizard, code signed and notarized.
- **First-launch setup wizard** — choose install location, select which AI models to download, and create a desktop shortcut.
- **Download Models in Preferences** — download or update AI model weights without reinstalling.
- **Custom output directory** — set a global default output location in Preferences, or override per-clip via right-click > Set Output Directory.
- **Auto-update for installed apps** — check for updates and download new versions directly from the app.
- **WebM alpha video export** — export keyed output as WebM with VP9 alpha transparency for web and motion graphics workflows.
- **ProRes 4444 alpha video export** — export keyed output as ProRes 4444 with embedded alpha channel for professional NLE workflows.
- **Batch export dialog** — select multiple clips, choose export formats (WebM/MP4) per output, view frame counts, and monitor progress.
- **MLX/MPS backend toggle** — macOS Preferences now lets you switch between MLX and MPS backends without restarting.

### Fixed
- **Crash on video import** ([#70](https://github.com/edenaion/EZ-CorridorKey/issues/70), [#63](https://github.com/edenaion/EZ-CorridorKey/issues/63), [#65](https://github.com/edenaion/EZ-CorridorKey/issues/65), [#51](https://github.com/edenaion/EZ-CorridorKey/issues/51)) — app crashed with a stack overflow (`0xc00000fd` in `pyside6.abi3.dll`) when importing any video file. Root cause: `clear_in_out()` emitted a Qt signal connected back to itself, creating infinite recursion through PySide6's C++ signal dispatch. On Linux this surfaced as a `RecursionError`; on Windows the native stack overflowed before Python could intervene. Affected all platforms.
- **Slow inference when window loses focus** ([#68](https://github.com/edenaion/EZ-CorridorKey/issues/68)) — GPU worker thread was started at `LowPriority` on Windows, causing CPU starvation when the app lost foreground focus. Fixed by raising worker thread to `HighPriority` and setting process to `ABOVE_NORMAL_PRIORITY_CLASS`.
- **Processed PNG output dark/semi-transparent** — missing linear→sRGB conversion when writing Processed output as PNG.
- **Version detection in frozen builds** — version now reads directly from pyproject.toml, fixing incorrect version display in installed apps.
- **Installer finished page** — fixed Discord and website links, updated EZSCAPE branding.
- **PyTorch 2.6+ compatibility** — resolved `torch.load` errors on newer PyTorch versions.
- **Split view panels** now fit images to their own width.
- **Update script** — prevents stale cache conflicts after updates.

### Changed
- **I/O tray grid layout** — thumbnail cards now wrap into a responsive grid with vertical scrolling instead of a single horizontal row.
- **EZ-CorridorKey branding** — all references, filenames, and install paths updated from `CorridorKey` to `EZ-CorridorKey`.
- **Major codebase refactor** — restructured core modules for maintainability and performance.

### Known Issues
- **MLX FG output can be blocky** — on macOS with the MLX backend, the FG (foreground) output may produce blocky/artifacted results. Workaround: disable FG output and use Matte + Processed outputs instead. CUDA users are not affected.

---

## [1.8.0] - 2026-03-16 — A/B Wipe, View Hotkeys, Docker, Model Resolution

### Added
- **Source passthrough** for CUDA — preserves original pixels in confidently opaque interior regions. 1:1 quality with your input image. Proud of this one :)
- **A/B wipe comparison viewer** (hotkey **A**) — diagonal split between input and output with draggable/rotatable divider line. Scroll wheel slides the divider, Shift+scroll for fine-grain control. Middle-click resets to default position.
- **F1–F7 hotkeys** for instant view mode switching (INPUT, MASK, ALPHA, FG, MATTE, COMP, PROC). Hotkeys shown in button tooltips.
- **Ctrl+,** opens/closes Preferences (toggle, like F12 for debug console).
- **Docker / noVNC browser mode** — run EZ-CorridorKey in a container with browser-based access. Contributed by [DCRepublic](https://github.com/DCRepublic).
- **Model resolution setting** Exposed in Preferences — defaults to 1024 (Apple Silicon only) but users can now change to 2048 for CUDA quality parity at the cost of processing speed.

### Fixed
- **Despill label** showing 1.0 instead of 0.5 on startup.
- **Default model resolution** on Apple Silicon set to 1024.
- **Premultiplied RGBA output** restored on both CUDA and MLX paths.
- **F-key view mode hotkeys** now match ViewMode enum case correctly.
- **A/B wipe B-side** updates live when switching view modes.
- **MLX despill** unified with inference defaults.

### Changed
- **Docker files organized** into `docker/` folder to keep repo root clean.
- **Preferences sections** reordered for clarity.

---

## [1.7.0] - 2026-03-15 — BiRefNet, Color Accuracy, UI Polish

### Added
- **BiRefNet automatic alpha generation** — new one-click alpha hint method with 16 model variants (Matting, Portrait, General, HR, Lite, etc.). Downloads on first use from HuggingFace and caches locally. Inline model selector dropdown in the parameter panel. No painting or annotation required. *(Adapted from [Warwlock](https://github.com/Warwlock)'s [PR #10](https://github.com/edenaion/EZ-CorridorKey/pull/10))*
- **"Automatic" / "Requires brushstrokes" section labels** in the Alpha Generation panel for clearer workflow guidance.

### Fixed
- **Processed output color accuracy** — removed `match_luminance` which was comparing the model's foreground against the full green-screen source, causing systematic brightness shifts. Output colors now faithfully match the input on both CUDA and MLX paths.
- **Processed viewer washout** — removed global Reinhard tone map (`x/(1+x)`) from the PROC display transform. A single hot pixel above 1.0 was compressing the entire image, making it appear washed out.
- **Viewer clears on clip deletion** — deleting the currently-viewed clip now either selects the left neighbor or shows a "No clip selected" placeholder instead of displaying stale cached frames.
- **Export strip refresh on Clear Outputs** — the export thumbnail strip now correctly removes clips when outputs are cleared (COMPLETE → READY state change).
- **INPUT / EXPORT strip selection sync** — clicking either strip now highlights the same clip in both, preventing visual confusion about which clip the viewer is showing.
- **Left-neighbor selection on delete** — deleting clip N now selects clip N-1 instead of jumping to the first clip.
- **torch.compile hang after BiRefNet** — clearing the inductor code cache during model switch prevents a one-time freeze when transitioning from BiRefNet to CorridorKey inference.
- **Debug console stays on top** — the floating console window no longer hides behind the main window.

---

## [1.6.7] - 2026-03-14 — Color Truth, Export Fidelity, MLX Parity

### Added
- **Manual alpha-video import in `Import Alpha`** — the UI can now accept alpha-hint video files as well as image folders, then normalize them into `AlphaHint/*.png` frames so they follow the same downstream path as imported stills.

### Fixed
- **Source color-space truth in viewers and thumbnails** — the left `INPUT` viewer, input thumbnails, and output/export previews now honor the selected source interpretation for video, LDR image sequences, and linear EXR sequences instead of silently drifting back to auto-detect.
- **Sticky clip-level color-space overrides** — reselecting tray thumbnails, clearing outputs, importing alpha, or stopping inference no longer resets a clip from `Linear` back to `sRGB` behind the user's back.
- **Alpha-import preview mode mismatches** — importing alpha no longer replaces `INPUT` / `ALPHA` preview modes with the wrong pixel payload during live preview refreshes.
- **Fresh-launch live preview** — the first live-preview reprocess now warms the inference engine on demand instead of appearing inert until a prior inference run.
- **EXR export correctness** — `FG.exr` and `Comp.exr` are now written from linear-light data, and `Processed.exr` is written as straight linear RGBA instead of a mismatched contract that came back too dark in comp apps.
- **Processed export luminance parity** — `Processed` output now preserves keyed-subject luminance closely enough for A-B Resolve / Fusion checks.
- **Export thumbnail truth** — export tray thumbnails now track the saved output mode they represent instead of mirroring input cards or stale preview state.
- **Apple Silicon memory meter mismatch** — the macOS memory bar and `used / total` text now derive from the same unified-memory basis, so the bar and number agree.
- **macOS startup regression after alpha-video work** — startup no longer hard-fails if an older `frame_io` helper layout is present; service import is backward-compatible again.

### Changed
- **Parallel frames messaging** — the main-panel tooltip now explicitly says the feature is CUDA-only today and unsupported on Apple Silicon right now.
- **Preferences cleanup** — removed the duplicate `Performance` / `Parallel frames` controls from Preferences so the setting only exists in the main inference UI.
- **Default despill strength** — the default moved from `1.0` to `0.5`.
- **Branding polish** — app chrome now uses `EZ-CorridorKey` as the product name, while the in-app logo remains `EZ-CORRIDORKEY` in all caps.

### Apple Silicon / MLX
- **Linear-input handoff fixed** — linear sources are converted to sRGB before entering the MLX path instead of being treated like already-display-encoded input.
- **Higher-precision MLX postprocess path** — the adapter now recovers float MLX outputs before uint8 quantization when possible, aligns resize behavior with upstream bicubic handling, and applies the same downstream export contract as the Torch path.
- **Opaque-detail preservation** — MLX output assembly now preserves more original source detail on confidently opaque, low-spill regions so fine costume details and fabric do not get overcooked.
- **Low-spill edge tint reduction** — reduces orange/red tint on low-spill opaque clothing edges while still letting MLX control genuinely contaminated green-screen boundaries.

---

## [1.6.6] - 2026-03-13 — Parallel Frames & Apple Silicon UX

### Improvements
- **Parallel frames raised to 1-64** — for high-memory CUDA systems (RTX 6000, multi-GPU workstations). OOM-safe: if you set more engines than memory can handle, the app automatically scales back. Values above 8 are marked experimental in the tooltip.
- **Note:** MLX (Apple Silicon) remains capped at 1 engine. Multi-engine parallelization is CUDA-only for now.

### Bug Fixes
- **Fix MLX crash on older corridorkey_mlx** — `CorridorKeyMLXEngine.__init__()` may not accept `tile_size`/`overlap` kwargs on older versions. Now falls back to full-frame inference gracefully.

---

## [1.6.4] - 2026-03-13 — Apple Silicon Memory Display

### Improvements
- **Unified memory display on Apple Silicon** — GPU info bar now shows system memory usage instead of "No GPU" on Macs. Label shows "Memory" instead of "VRAM" since Apple Silicon shares RAM between CPU and GPU.
- Detects Apple chip name (e.g. "Apple M3 Max") via sysctl

---

## [1.6.3] - 2026-03-13 — MLX Auto-Download

### Improvements
- **Auto-download MLX checkpoint** — Apple Silicon users no longer need to manually download or set environment variables for `.safetensors` weights. Fresh installs and updates handle it automatically.
- `setup_models.py --corridorkey-mlx` flag for manual download with SHA256 verification
- `--all` on Apple Silicon auto-includes MLX weights

---

## [1.6.2] - 2026-03-13 — Live Preview Fix

### Bug Fixes
- **Fix live preview breaking after first use** — the GPU queue's "all jobs done" handler was unloading the inference engine after every preview reprocess, causing `is_engine_loaded()` to return false on subsequent parameter changes. Preview now keeps the engine resident; model switching is already handled by `_ensure_model()`. Fixes [#20](https://github.com/edenaion/EZ-CorridorKey/issues/20).

---

## [1.6.1] - 2026-03-13 — MLX Python Version Fix

### Bug Fixes
- **Fix MLX install on Python 3.10** — `corridorkey-mlx` requires Python ≥3.11 but `pyproject.toml` allowed 3.10, causing uv to fail resolving the `[mlx]` extra on Apple Silicon. Added `python_version >= '3.11'` marker to the mlx optional dependency so the resolver skips it on older Pythons. Windows/Linux users unaffected.

---

## [1.6.0] - 2026-03-13 — Parallel Inference, MatAnyone2, MLX Apple Silicon, macOS Support,

### Parallel Inference
- **Multi-engine frame processing!** — inference engine pool processes multiple frames concurrently when VRAM allows, with user-configurable pool sizing based on available memory. 1.8-2x speed increase clocked on 4K footage via RTX 5090 at 4 parallel frames. Experimental up to 8, use at your own discretion if you have VRAM headroom.

### MatAnyone2 Integration
- **Fourth alpha generator** — MatAnyone2 joins GVM, VideoMaMa, and SAM2 as a one-click alpha hint generator. Make sure to paint a frame using hotkeys 1/2 on frame 1 first. Checkpoint auto-downloads from GitHub releases on first use (~390 MB)
- **Performance hardening** — robust Hydra config initialization, graceful error handling, and progress reporting during MatAnyone2 inference

### MLX Apple Silicon Acceleration
- **Native Apple Silicon backend** — on Macs with Apple Silicon and `corridorkey-mlx` installed, CorridorKey inference uses MLX instead of PyTorch MPS for 1.5–2× faster keying
- **Auto-detection** — backend resolves automatically: Apple Silicon + corridorkey-mlx + `.safetensors` checkpoint → MLX, otherwise Torch. Override with `CORRIDORKEY_BACKEND=torch|mlx|auto`
- **Output normalization** — adapter converts MLX uint8 output to float32 0–1 matching the Torch engine contract; despill/despeckle post-processing applied identically
- **Installer support** — `1-install.sh` and `3-update.sh` automatically install `.[mlx]` extras on Apple Silicon Macs

### macOS Support
- **Cross-platform FFmpeg** — macOS FFmpeg install via Homebrew, file manager opens via `open` instead of `explorer`
- **MPS performance warning** — one-time-per-session dialog warns Mac users before launching GPU-heavy features (SAM2, GVM, VideoMaMa, MatAnyone2) that may be extremely slow on MPS, recommending imported alpha mattes instead

### Installer Hardening
- **Managed runtime verification** — install now verifies the actual torch runtime before reporting success, with clearer diagnostics when Python or accelerator selection is wrong
- **macOS polish** — Apple Silicon installs automatically include MLX extras; macOS torch verification skips unnecessary CUDA probing; Homebrew FFmpeg install path now works cleanly in non-interactive runs
- **Windows/Linux robustness** — Windows CUDA detection smoke was hardened for locale/codepage issues; fresh installs now resolve the correct torch backend more reliably
- **Upgrade cleanup** — updater removes lingering legacy `pynvml` installs and suppresses the related non-actionable deprecation warning for older upgraded environments

### Added
- **ALPHA view mode** — preview the raw AlphaHint input before running inference
- **MASK view mode** — preview SAM2-tracked masks before feeding them to alpha generators
- **Clear Mask / Clear All** — right-click context menu on clips to clear tracked masks or all generated data
- **Global drag-and-drop** — drop video files anywhere on the main window to import them
- **Frame scrubber improvements** — scroll wheel scrubbing and larger slider hitbox for easier frame navigation
- **Live clip progress** — selected clip's progress bar updates in real time during inference jobs

### Fixed
- **Live preview EXR color-space override** — `PREVIEW_REPROCESS` no longer silently reinterprets extracted video EXR sequences as Linear on every rerun. When the user leaves the clip in `sRGB`, live preview now stays in `sRGB`; when the user explicitly switches to `Linear`, the preview follows that override
- **`Processed` viewer contract** — `PROC` preview now reflects the premultiplied RGBA data actually written on disk instead of unpremultiplying it in the viewer. `PROC` shows over black, `COMP` remains checkerboard-backed
- **Thumbnail decode mismatch** — clip thumbnails now use the same input decode path as the main viewer
- **SAM2 preview input color truth** — Track Mask preview and full SAM2 tracking load EXR frames with the same source-truth color interpretation as the viewer
- **SAM2 prompt-frame quality** — prompt points now applied as smaller same-frame refinements instead of one bulk call, eliminating boxy/hole-ridden prompt-frame masks
- **SAM2 Hydra reinitialization** — Hydra global state cleared before each tracker build, preventing config collision errors on repeated runs
- **ProRes 10-bit extraction** — fixed frame extraction failing on FFmpeg 8.x with 10-bit ProRes sources
- **In-out alpha alignment** — corrected frame alignment between input and alpha hint sequences during inference
- **Update button text** — fixed garbled button text when window is resized narrow
- **Clear Alpha state** — clearing alpha now properly refreshes the viewer, disables the ALPHA button and coverage bar
- **Windows EcoQoS throttling** — disabled Windows EcoQoS power policy that was silently throttling GPU inference in background
- **UI paint clipping** — fixed paint brush strokes clipping at widget boundaries, tooltip wrapping, and mask-ready state check
- **Report Issue version** — Report Issue dialog now reads app version dynamically instead of hardcoded string

### Changed
- **Azure GPU CI** — added installer smoke test matrix on Azure GPU runners
- **`pynvml` → `nvidia-ml-py`** — switched to canonical PyPI package name for NVIDIA Management Library

### Verification
- Regression tests for EXR live-preview color-space override, `PROC` display transform, thumbnail decode, and SAM2 prompt refinement batching
- macOS CUDA-skip test for `verify_torch_runtime.py`
- Paint prompt tests, split view tests, status bar tests, Windows CUDA detection tests
- Fresh install smoke passed on Windows, macOS, and Ubuntu
- Real upgrade smokes passed for `v1.5.0 -> 1.6.0` and `v1.5.2 -> 1.6.0`

---

## [1.5.1] - 2026-03-11 — Hotfix: FFmpeg Filter, Alpha Video Import

### Fixed
- **FFmpeg extraction broken on standard builds** — `in_primaries` and `in_transfer` are not valid FFmpeg scale filter options; removed them (only `in_color_matrix` and `in_range` are needed for YUV→RGB conversion)
- **FFmpeg startup check** — app now validates FFmpeg availability at launch and shows a clear diagnostic dialog if missing or outdated (v6.x users see fix instructions instead of cryptic extraction errors)
- **Reverted broken v1.4.0 updater auto-patch** that was shipped by mistake

### Added
- **Alpha hint video import** — users can now import ProRes MOV, MP4, and other video files as alpha hints (previously only image sequences were accepted)
- **Auto-detect companion alpha hint** — place `input_alphahint.mov` next to `input.mov` and it's automatically extracted to `AlphaHint/` as grayscale PNGs during source extraction — zero extra clicks
- **`--opt-mode` CLI flag** — override GPU optimization mode (`speed`, `lowvram`, `auto`) from the command line

---

## [1.5.0] - 2026-03-10 — SAM2 Tracking, FFmpeg Hardening, Quality Verification

### SAM2 Tracking Integration
- **Annotations are now prompts, not final masks** — painting foreground/background strokes feeds into SAM2 dense tracking before VideoMaMa, producing far better alpha hints than raw brush strokes
- **TRACK MASK button** — generates dense per-frame segmentation masks from sparse annotation prompts using SAM2
- **VideoMaMa pipeline updated** — now expects SAM2-tracked masks (chunking, VRAM, dtype defaults corrected toward official usage)
- **Tracker model selection** — Preferences > Tracking lets you choose Fast (184 MB), Base+ (324 MB, default), or Highest Quality (898 MB) SAM2 models
- **SAM2 pre-download** — installer optionally pre-downloads the default Base+ checkpoint (324 MB) during install

### FFmpeg Hardening
- **Validation requires both ffmpeg and ffprobe** — rejects installs missing ffprobe
- **Version >= 7 enforced** — rejects older FFmpeg builds at both install and runtime
- **Windows essentials build rejected** — Gyan "essentials" builds lack required filters; validation detects and blocks them
- **Bundled local FFmpeg preferred** — `tools/ffmpeg/bin` is checked first, before PATH, preventing stale system installs from interfering
- **Repair FFmpeg in Preferences** — Windows: one-click download of full BtbN GPL build into `tools/ffmpeg`. macOS/Linux: shows exact platform-specific install commands and copies to clipboard (no system mutation)
- **Open FFmpeg Folder** — quick access to the bundled FFmpeg directory from Preferences

### Cross-Platform Smoke CI
- **GitHub Actions workflow** — fresh install + headless startup smoke on Windows, Ubuntu, and macOS
- **Covers**: installer, dependency resolution, SAM2 pre-download, QApplication creation, MainWindow construction, Preferences dialog, FFmpeg repair button
- **Ubuntu runtime libs** — installs libegl1, libgl1, libpulse0, libxkbcommon-x11-0, libxcb-cursor0
- **Node 24 compatible** — uses actions/checkout@v6 and actions/setup-python@v6

### Quality Verification
- **Multi-metric upstream comparison** — same frame run through upstream CorridorKey and our fork, verified across PSNR (80–90 dB), SSIM (0.999996+), MS-SSIM (0.999999+), LPIPS (0.000001), and DeltaE 2000 (0.015 mean on skin) — all below float32 noise floor
- **Branded HTML report** — `scripts/compare_upstream_d2.py` generates a dated, versioned comparison PNG via Playwright with side-by-side composite and alpha matte panels

### Updater Bridge (master → main)
- **`3-update.bat` / `3-update.sh`** — automatically migrates local `master` checkouts to `main`, repoints tracking if needed
- **`origin/master` compatibility mirror** — kept in sync with `main` for the next two releases so older installs can update gracefully. Planned retirement: after `1.5.1`

### Installer Parity
- **`1-install.sh`** — added Python 3.14+ upper-bound check (was already in `.bat`)

### Fixed
- **UI sound clicks** — 50ms fade-in/out applied to all UI sound effects to eliminate playback pops
- **Windows updater crash** — `3-update.bat` restructured to avoid cmd.exe label-inside-parenthesized-block bug; replaced `::` comments with `REM`, removed UTF-8 em dashes
- **FFmpeg version regex on Windows** — `ffmpeg.exe version ...` now parsed correctly (was failing on `.exe` suffix)
- **VirusTotal security link** — README now links independent 0-detection scan for `1-install.bat`

---

## [1.4.0] - 2026-03-09 — Full Pipeline, Model Handoff, Force-Stop, Installer Overhaul

### Workflow Improvements
- **Import Images as sequence or folders** — images are now able to be imported! PNG, JPG/JPEG, EXR, TIF/TIFF, BMP, DPX
- **Alpha hint re-import** — importing alpha hints on a clip that already has them now asks to overwrite (previously showed "Already Imported")

### Model Residency & GPU Handoff
- **`torch._dynamo.reset()` after model switch** — clears stale Triton compilation cache when switching between GVM/VideoMaMa/inference models, fixing the hang where `torch.compile` would deadlock on cached CUDA state from the previous diffusion pipeline
- **pynvml VRAM detection** — `_get_vram_gb()` now uses NVML (driver-level, no CUDA context calls) instead of `torch.cuda.get_device_properties()` which stalled after GVM teardown. Falls back to torch.cuda if pynvml unavailable
- **Granular model-switch status callbacks** — status bar shows each phase: "Switching GVM → inference...", "Offloading GVM...", "Releasing Python references...", "Waiting for CUDA to finish...", "Clearing CUDA cache..."
- **Diagnostic logging in `_load_model()`** — force-flushed `_diag()` messages at every step (GreenFormer init, model.to(device), checkpoint load, state_dict, hiera patch, torch.compile) for hang diagnosis

### Force-Stop Escape Hatch
- **Double-click STOP to force-stop** — first STOP sends cooperative cancel; if the GPU job is stuck (e.g. in a non-interruptible CUDA operation), clicking STOP again triggers a force-stop that auto-saves the session and relaunches the app
- **Status bar FORCE STOP mode** — after first stop attempt, button changes to "FORCE STOP" with warning tooltip
- **Improved stop handling** — cooperative cancel now propagates through model load and CUDA teardown phases, not just frame processing

### Installer (`1-install.bat`)
- **Auto-install FFmpeg** — downloads from gyan.dev, extracts to `tools/ffmpeg/`, adds to PATH. No more manual FFmpeg install needed
- **VS Build Tools auto-install** — detects MSVC via `cl.exe` and `vswhere.exe`, offers auto-install via winget if missing (needed for OpenEXR compilation). Fully unattended — no user interaction required in the VS installer window
- **Python 3.10–3.13 supported** — installer accepts 3.10–3.13, blocks 3.14+ (PyTorch lacks wheels)
- **Git auto-install** — offers to install Git via winget, then links the extracted folder to the upstream repo for `git pull` updates
- **Desktop shortcut** — optional shortcut creation (no console window)

### UI Polish
- **Toast notifications** — animated overlay messages for transient events (alpha import complete, foreground color change, stop-while-chunking, etc.)
- **Update checker** — background thread checks for new versions on GitHub at startup
- **Despeckle spinbox arrows** — custom SVG up/down arrows (`arrow-up.svg`, `arrow-down.svg`) with themed hover/press states for QSpinBox and QDoubleSpinBox controls
- **QSS spinbox styling** — full restyle of spin box up/down buttons with proper hit areas, hover feedback, and brand-consistent sizing

### Fixed
- **GVM → inference hang (root cause)** — `torch.compile` deadlocked on stale Triton/dynamo state from GVM's diffusion pipeline. `torch._dynamo.reset()` in `_ensure_model()` clears the cache before loading the next model. Compile stays enabled in all modes (speed, lowvram, auto) — no performance loss
- **VRAM probe stall during model switch** — `torch.cuda.get_device_properties()` blocked after GVM teardown; replaced with pynvml (NVML driver API)
- **Auto mode resolved to speed but kept compile enabled** — explicit `speed` mode disabled compile (TEMP workaround) but `auto` on ≥12GB cards still ran compile without the dynamo reset. Now all paths are safe
- **FFmpeg bt470bg color space extraction failure** — Photo-JPEG `.mov` files (e.g. Apple cameras) report `color_space: bt470bg` which FFmpeg's scale filter doesn't accept. Built comprehensive mapping tables for matrix (`bt470bg→bt601`), primaries, and transfer (`bt470bg→gamma28`) identifiers. Unknown values now log a WARNING with the exact mapping file/line to update, so future color spaces are caught immediately instead of silently failing
- **EXR colour conversion accuracy** — replaced `setparams` filter with explicit `scale` filter providing input colour metadata (`in_color_matrix`, `in_primaries`, `in_transfer`, `in_range`) directly to swscale. Fixes washed-out or shifted colours on files with incomplete/missing colour tags (e.g. ProRes `.mov` from cameras)
- **Colour metadata fallbacks** — resolution-aware heuristics for missing matrix (BT.709/BT.601/BT.2020), primaries, transfer, and range. SD PAL (576p), NTSC (480p), HD, and BT.2020 sources all get correct defaults
- **Deleted clips reappear on import** — removing clips from the I/O tray was UI-only; adding a new video triggered `os.listdir()` rescan that rediscovered all folders. Now persists removals to `removed_clips` list in `project.json`, filtered during `scan_project_clips()`. Re-importing a removed clip clears it from the list
- **Clip identity mismatch** — `clip.name` was mutable (overwritten by `display_name`), causing removal tracking to fail. Added stable `folder_name` property using `os.path.basename(root_path)`
- **Corrupt project.json on removal** — `add_removed_clip()` now guards against missing `project.json` (returns early with warning instead of creating partial file)
- **Extraction retry fails on ERROR clips** — retrying extraction only removed the `.dwab_done` marker, leaving partial EXR frames that triggered resume logic. Now wipes the entire Frames/ directory on retry for a clean start
- **FFmpeg hardware decode fallback** — if NVDEC fails (e.g. unsupported codec in `.mov`), automatically retries with software decode instead of failing permanently
- **Re-import of removed clips blocked** — "Already Imported" dialog appeared for clips the user had removed. Duplicate check now skips removed clips; re-importing restores the original clip folder instead of creating duplicates
- **Despeckle spinbox arrows invisible** — default Qt arrows had no contrast against dark theme; replaced with explicit SVG icons
- **Installer winget quoting** — VS Build Tools `--override` flag now works correctly on all Windows versions (temp batch file avoids nested-quote escaping)

### Added
- **Extraction diagnostics** — `video_metadata.json` now includes `exr_vf` (exact FFmpeg filter used) and `source_probe` (raw colour metadata from ffprobe) for debugging colour issues
- **Version in About dialog** — Help > About now shows app version via `importlib.metadata`
- **`removed_clips` persistence** — new `get_removed_clips()`, `add_removed_clip()`, `clear_removed_clip()` functions in `backend/project.py`
- **Import Alpha documentation** — README now documents Option C (bring your own alpha mattes) with supported formats

### Installer & Scripts
- **`2-start.bat`** — adds local `tools/ffmpeg/bin` to PATH before launch
- **`3-update.bat` / `3-update.sh`** — migrates older git installs from local `master` checkouts to `main`, repoints `main` checkouts still tracking `origin/master`, and still preserves ZIP fallback for non-git installs
- **Temporary `master` compatibility mirror** — `origin/master` remains a compatibility branch for the next two releases so older installs can keep using their existing updater before being bridged onto `main`. Planned retirement: after `1.5.1`
- **`pyproject.toml`** — `requires-python` updated to `">=3.10,<3.14"`
- **`.gitignore`** — added `tools/` to prevent ffmpeg binary from being committed

### Debug Infrastructure
- **Debug log bible updated** — added GVM→Inference handoff chain, 3 bare `except:` clauses catalogued, 7 silent failures identified, 6 unlogged state initializations documented
- **Force-flush diagnostics** — `_load_model()` uses `_diag()` that flushes all log handlers immediately, ensuring last message is visible even on hang

### Tests
- 10 new tests in `TestRemovedClips` — empty default, missing JSON, add/clear, idempotency, scan filtering, sorted deterministic, re-import clears removed
- 8 new tests in `test_ffmpeg_tools.py` — probe colour metadata, `build_exr_vf` for RGB/YUV/SD/BT.2020, extract filter chain, metadata roundtrip

---

## [1.3.1] - 2026-03-09 — Low-VRAM compile fix, status callbacks

### Fixed
- **Low-VRAM mode hang on first frame** — `@torch.compiler.disable(recursive=False)` allowed Dynamo to re-enter the tile loop, causing O(N) graph breaks per tile. Changed to `@torch.compiler.disable` (recursive=True) so the tiled scheduler is a true eager island. First-frame compile now takes ~15s instead of hanging indefinitely.
- **Tile kernel compile** — added `fullgraph=True` for the pure CNN tile kernel (no graph breaks needed)
- **`total_mem` AttributeError** — corrected to `total_memory` in both inference engine and GPU monitor (PyTorch API)

### Added
- **Status callbacks** — `on_status` parameter on `run_inference()` for phase labels ("Loading model...", "Compiling...") piped to UI status bar via `status_update` signal

---

## [1.3.0] - 2026-03-09 — 2x Faster Inference, Low-VRAM Support

### Performance (4K: 3.3s → 1.5-1.8s per frame)
- **Hiera FlashAttention patch** — fixes timm's 5D non-contiguous Q/K/V tensors in 18 global attention blocks, enabling SDPA FlashAttention instead of O(N²) math fallback (credit: Jhe Kimchi)
- **TF32 tensor cores** — `torch.set_float32_matmul_precision('high')` for ~15% throughput boost on Ampere+ GPUs (no-op on older hardware)
- **torch.compile** — JIT compilation via Triton inductor backend with `fullgraph=False` for graph break support
- **Quality verified** — 157+ dB PSNR across all optimization levels (mathematically identical output)

### Low-VRAM Support (8GB GPUs)
- **Tiled CNN refiner** — 512×512 tiles with 128px overlap (> 65px receptive field = lossless blending) (credit: Marclie)
- **Boundary-aware blending** — tile edges at image boundaries keep full weight, only internal overlaps get ramped
- **Selective torch.compile** — `@torch.compiler.disable` excludes tile scheduler from Dynamo; tile CNN compiled separately with `fullgraph=True`
- **VRAM auto-detection** — ≥12GB uses speed mode (full compile), <12GB uses tiled mode
- **cuDNN benchmark disabled** — saves 2-5 GB workspace memory
- **Manual override** — `CORRIDORKEY_OPT_MODE=speed|lowvram|auto` environment variable

### Fixes
- **Zombie process on exit** — `os._exit()` kills Triton background threads that prevented clean shutdown (was holding ~5.5GB VRAM after window close)
- **Debug console** — F12 console now closes with main window
- **Batch launcher** — `2-start.bat` exits immediately after spawning app
- **GPU flush** — `gc.collect()` + `torch.cuda.synchronize()` before `empty_cache()` in model unload
- **Console window spam** — Triton compilation no longer opens flurry of terminal windows on Windows

### Dependencies
- Added `triton-windows>=3.5,<4` (Windows-only, enables torch.compile)
- Added `OpenEXR>=3.4` to requirements.txt (was in pyproject.toml only)

### Quality Scripts
- `scripts/benchmark_quality.py` — compare 4 optimization levels on same frame (PSNR/MAE/max diff)
- `scripts/compare_quality.py` — A/B comparison between two alpha output directories

---

## [1.2.4] - 2026-03-08 — In/Out State Fix, Extraction Retry

### In/Out Marker State Fix
- Setting or clearing in/out markers now re-evaluates clip state immediately
- Previously, partial alpha + in/out range wouldn't promote RAW to READY until app restart
- RUN SELECTED button now enables as soon as in/out covers the alpha'd range

### Extraction Retry Fix
- Re-running extraction after an error now works correctly
- Clears stale `.dwab_done` marker so `extract_frames()` doesn't skip the actual work
- Resets clip state from ERROR to EXTRACTING before re-queueing

---

## [1.2.3] - 2026-03-08 — Cross-Platform FFmpeg Discovery

- FFmpeg/FFprobe discovery now checks common macOS/Linux install paths (`/opt/homebrew/bin`, `/usr/local/bin`, etc.) — fixes "FFmpeg not found" when GUI is launched from Finder/Dock where `~/.zshrc` PATH isn't loaded

---

## [1.2.2] - 2026-03-08 — macOS Installer Fix

- Fixed `1-install.sh` failing on macOS due to Bash 4+ syntax (`${var,,}`) — macOS ships with Bash 3.2

---

## [1.2.1] - 2026-03-08 — Partial Alpha + In/Out Range Support

### Partial Alpha Hint
- Clips with partial alpha hints now promote to READY if in/out markers are set and alpha covers the in/out range
- Previously, alpha had to cover ALL input frames regardless of in/out markers — Run Inference stayed greyed out
- Without in/out markers, full-clip alpha coverage is still required (unchanged behavior)

---

## [1.2.0] - 2026-03-08 — Import Alpha, Export UX

### Import Alpha Hint
- New **IMPORT ALPHA** button in the Alpha Generation panel — import your own alpha hint images directly from the GUI
- Supports PNG, JPG, TIFF, and EXR input (non-PNG auto-converted to grayscale PNG)
- Files are automatically renamed to match input frame stems for correct 1:1 index matching
- Natural/numeric sort handles any zero-padding scheme (e.g. `alpha_1.png` through `alpha_10.png` sorts correctly)
- Frame count mismatch warning with option to proceed with partial pairing
- Clip auto-advances to READY state after import — no restart needed

---

## [1.1.3] - 2026-03-08 — VideoMaMa UX, Export Improvements

### VideoMaMa Status Feedback
- Status bar now shows real-time phase updates during VideoMaMa: Loading model, Loading frames, Loading masks, Running inference
- Eliminated silent 6+ minute gap where users had no feedback — each phase is now visible
- Added "Running inference (chunk N/M)..." status before GPU inference begins
- Cancel checks added during frame and mask loading phases (not just between chunks)

### Alpha Generation Panel
- Added "— or —" divider between GVM AUTO and VIDEOMAMA buttons for clarity
- VideoMaMa tooltip now references hotkeys (1 for green/foreground, 2 for red/background)
- Tooltip includes annotation strategy tip: annotate keyframes where subject changes shape

### Clear Annotations Fix
- Clearing annotations now removes exported `VideoMamaMaskHint/` directory and disables VideoMaMa button
- Previously, clearing annotations left stale masks on disk, allowing VideoMaMa to run on outdated data

### Export Card Improvements
- Folder icon on export thumbnails — click to open output folder in Explorer
- Double-click export card to load clip in the viewer
- Right-click context menu lists each output type (Comp, FG, BG, etc.) as separate export options
- Video exports now default to `_EXPORTS/` subdirectory in each clip's project folder
- Export filenames include output type (e.g. `MyClip_Comp_export.mp4`)

### VideoMaMa Cancel Toast
- Cancel notification now appears centered on screen instead of bottom-left

---

## [1.1.2] - 2026-03-03 — In-App Issue Reporter, UI Polish

### In-App Issue Reporter
- **Help > Report Issue...** opens a dialog to file GitHub issues directly from the app
- Auto-collects system info: app version, OS, Python, PyTorch, CUDA, GPU, VRAM, display resolution
- Recent WARNING/ERROR log lines (up to 20) included automatically
- Full report copied to clipboard before opening browser — survives GitHub login redirects
- Notice informs users a free GitHub account is required

### UI Polish
- Fixed Python's `platform.platform()` misreporting Windows 11 as Windows 10

---

## [1.1.1] - 2026-03-03 — Pipeline In/Out Fix, Reset I/O Button

### Pipeline Fix
- **Batch pipeline now respects per-clip in/out markers** — inference jobs use each clip's in/out range instead of always processing the full clip
- Fixed in all three batch paths: RUN PIPELINE (Phase 3 direct + auto-chain after alpha), and Ctrl+Shift+R (Run All Ready)
- Alpha generation (GVM / VideoMaMa) still always processes the full clip — only inference is scoped to in/out range

### Reset I/O Button
- New **RESET I/O** button in the I/O tray header (next to + ADD)
- Clears in/out markers on all clips at once — reverts to full-clip processing
- Double confirmation required: "Continue?" then "Are you sure? Cannot be undone."
- Shows count of affected clips; disabled message if no markers are set

---

## [1.1.0] - 2026-03-03 — EXR DWAB Half-Float Extraction

### Frame Extraction Overhaul
- Video frames now extracted as **EXR half-float** instead of PNG — preserves full floating-point precision from the video decoder, eliminating 8-bit quantization and banding
- Two-pass pipeline: FFmpeg extracts to EXR ZIP16, then a recompression pass converts to **DWAB** (VFX-standard lossy compression, ~4× smaller than ZIP)
- Even 8-bit source video benefits: FFmpeg's internal YUV→RGB conversion stays in float, avoiding rounding errors from integer pipelines
- Hardware-accelerated decode (NVDEC/DXVA2) with automatic fallback to software decode
- DWAB recompression runs in a **separate subprocess** — zero GIL contention, UI stays fully responsive

### UI Performance Fixes
- **Throttled progress signals**: Extraction progress emitted at most every 100ms (was per-frame ~500Hz), preventing main thread saturation
- **Cached thumbnails**: `ThumbnailCanvas` scales thumbnails once on load, not on every repaint — eliminates repeated `Qt.SmoothTransformation` during progress updates
- **Smart data-change handling**: Progress-only updates trigger lightweight `update()` instead of full `_rebuild()` with thumbnail rescaling

### Display & Theme
- **EXR input display fix**: Skip gamma correction and Reinhard tone mapping for INPUT mode frames (FFmpeg EXR output is sRGB-range float, not HDR linear)
- **Opaque context menus**: Fixed QSS `background` vs `background-color` causing transparent right-click menus

### GVM Compatibility
- `ImageSequenceReader` now filters files by image extension — `.dwab_done` marker file and other non-image files no longer cause "cannot identify image file" errors

### Version
- Bumped to 1.1.0

---

## [1.0.0] - 2026-03-03 — Batch Pipeline, Annotation Persistence, Installer

### Batch Pipeline (`fd35073`)
- **RUN PIPELINE** button appears when multiple clips are selected in the I/O tray
- Automatic per-clip route classification via `PipelineRoute` enum:
  - **RAW + no annotations** → GVM Auto → Inference
  - **RAW + annotations** → Export masks → VideoMaMa → Inference
  - **MASKED** → VideoMaMa → Inference
  - **READY / COMPLETE** → Inference only
  - **EXTRACTING / ERROR** → Skip
- Phase 0 (CPU): Headless mask export for annotated clips (`export_masks_headless()`)
- Phase 1–3 (GPU): Jobs queued in dependency order — alpha generation first, then auto-chain inference on completion
- Fully cancellable (Esc) and checkpointable — interrupted runs resume where each clip left off
- Extraction done sound plays only after the last batch clip finishes

### Annotation Persistence (`a81ee1f`)
- Annotation strokes now saved to `annotations.json` per clip and persist across app restarts
- Strokes restored on clip load — no need to re-annotate after closing the app

### Video Import & Extraction
- Dual import: ADD button supports folders (image sequences) or video files; drag-drop accepts videos
- Video extraction pipeline with FFmpeg: progress tracking, cancel support, resume detection
- Metadata sidecar (`video_metadata.json`) for stitching back later

### Viewer & Playback
- Cursor-centered zoom (Ctrl+scroll), shift+scroll horizontal pan (`25019f9`)
- Play/pause transport (Space hotkey) with loop playback within in/out range (`56b451f`)
- Live output mode switching during inference — `FrameIndex` rebuilds on the fly (`2270270`)
- Draggable in/out markers, split RUN/RESUME buttons, middle-click slider reset (`7aa22ee`)
- Alpha coverage feedback: frame counts in status bar, 3-option partial alpha dialog (`2422772`)

### Annotation Brush
- Cycle foreground color with **C** key (green / blue) (`c712a53`)

### Preferences
- Preferences dialog (Edit > Preferences) with tooltips toggle (`73fb3e2`)
- Copy-source preference: copy imported videos into project folder or reference in-place (`81e603a`)
- Deletion safety guard prevents removing the Projects root itself

### Installer & Packaging
- One-click installers (`1-install.bat` / `1-install.sh`) with auto GPU detection (`f5b2892`)
- Update scripts (`3-update.bat` / `3-update.sh`) for easy bug fix delivery (`97023be`)
- Desktop shortcut creation during install (no console window) (`98f7b63`)
- Skip GVM/VideoMaMa download on macOS (CUDA-only models) (`c2707ed`)
- Download SVD base model alongside VideoMaMa weights (`b4aa6a4`)
- Fix VideoMaMa unet folder rename after download (`7fc3dd1`)

### Debug & Logging
- Debug console captures all logs from session start (`32001ae`)
- VideoMaMa VAE decode logging with per-chunk timing (`06bbbbf`)
- System local time for log timestamps instead of hardcoded Eastern timezone (`77c6acb`)

### Fixes
- GVM unet rename bug, enable GVM button after extraction (`534b4d9`)
- Progress bar, queue panel, extraction cancel fixes (`8ac9530`)
- Subtler volume slider — thin groove, white handle (`477f81b`)
- Hide redundant clip info label on right viewport (`ebafdc8`)
- Cancel sound debounce, skip previews during annotation mode (`202b76d`)
- Crisp app icon from official logo SVG rendered at 1024px (`57977da`)

---

## [0.1.0] - 2026-03-02 — Release Prep

### Release Packaging
- Added `pyproject.toml` for uv/pip editable install support
- Added 9 UI sound effect WAV files (click, hover, error, done, cancel)
- Added `dev-docs/USER-GUIDE.md` with comprehensive feature documentation
- Updated `.gitignore` for dev-only artifacts
- Removed obsolete dev-docs (branding prompts, clip pipeline, LLM handover)
- Removed all `_BACKUPS/` directories

### UI Sound System (`15611e8`, `7c815af`, `9060279`, `840f4b3`)
- Audio feedback for UI interactions: click, hover, error, inference done, mask done, cancel
- `audio_manager.py` with debounced playback (200ms) to prevent double-fire
- Context-aware import: ADD button distinguishes folders vs video files
- Escape key cancels active extraction or inference job

### Queue Panel Overhaul (`a9df37a`, `70c51f6`)
- Moved queue to collapsible left sidebar with vertical "QUEUE" tab
- Floating overlay style with semi-transparent background
- Per-job progress bars with status color coding
- Splitter alignment with clip browser

### Hotkeys Dialog & Keyboard System (`9afd225`, `b699071`, `b089492`)
- New hotkeys dialog (Help > Keyboard Shortcuts) showing all bindings
- Removed split view (Ctrl+D) — dual viewer is now always-on
- Fixed `QKeyCombination` import for PySide6 compatibility
- Fixed queue panel progress bar stutter during active jobs

### Code Quality (`9a46c59`, `d7df7de`, `e420603`, `8448532`, `9381c09`)
- Deleted 3 dead files (clip_browser.py, clip_card.py, preview/natural_sort.py)
- Removed 9 dead functions from UI layer
- Removed unused imports across 12 files
- Unified image/video extension constants in `backend/project.py`
- Synced `backend/__init__.py` exports with actual module contents

### Interactive Annotation Overlay
- Green/red brush strokes (hotkeys 1/2) for VideoMaMa mask painting
- Shift+drag to resize brush, Ctrl+Z undo, mask export to VideoMamaMaskHint
- Annotation markers on timeline scrubber (green lane, auto-hides when empty)

---

## 2026-02-28 — Frame I/O Consolidation & Dead Code Removal

### New Module: `backend/frame_io.py`
- Unified frame reading functions: `read_image_frame()`, `read_video_frame_at()`, `read_video_frames()`, `read_mask_frame()`, `read_video_mask_at()`
- Handles EXR (linear float, BGRA stripping) and standard formats (uint8 → float32) in one place
- Optional `gamma_correct_exr` parameter for VideoMaMa's linear→sRGB conversion
- `read_video_frames()` accepts optional `processor` callable for custom per-frame transforms
- `EXR_WRITE_FLAGS` constant moved here from `service.py`

### `backend/service.py` (946 → 877 lines, -69 lines)
- `_read_input_frame()` — sequence path now delegates to `frame_io.read_image_frame()`
- `_read_alpha_frame()` — sequence path now delegates to `frame_io.read_mask_frame()`
- `reprocess_single_frame()` — replaced 50 lines of inline frame reading with `frame_io` calls
- `_load_frames_for_videomama()` — simplified from 30 lines to 7 using `frame_io`
- `_load_mask_frames_for_videomama()` — simplified using `read_video_frames()` with processor
- Removed `normalize_mask_channels`, `normalize_mask_dtype` imports (now internal to `frame_io`)

### Dead Code Removal
- `main.py` — removed unused `import time` (added in Step 2, never used)
- `ui/main_window.py` — removed unused `import tempfile`

### Test Adaptation
- `test_invalid_format.py` — updated `_EXR_FLAGS` reference to `frame_io.EXR_WRITE_FLAGS`
- All 224 tests pass, 0 regressions

---

## 2026-02-28 — Comprehensive Logging Infrastructure

### File-Based Session Logging
- Dual-handler logging: console (respects `--log-level`) + file (always DEBUG)
- Session-named log files: `logs/backend/YYMMDD_HHMMSS_corridorkey.log` (Eastern Time)
- `EasternFormatter` subclass forces America/New_York timezone on all timestamps
- `RotatingFileHandler` — 50MB per file, 3 backups (200MB max)
- Frozen build aware via `get_app_dir()` for log directory path

### Latency Tracking (5 GPU operations)
- `_get_engine()` — model load time
- `run_inference()` — total time + per-frame `process_frame` time + avg
- `run_gvm()` — total time
- `run_videomama()` — total time + per-chunk time
- `reprocess_single_frame()` — total time
- `process_frame()` in inference_engine.py — per-frame GPU time with resolution

### Silent Exception Fixes (6 locations)
- `service.py:201` — VRAM query failure now logged at DEBUG
- `service.py:227` — torch import in `_ensure_model` now logged at DEBUG
- `service.py:295` — torch import in `unload_engines` now logged at DEBUG
- `service.py:628` — state transition to COMPLETE failure now logged at WARNING
- `clip_state.py:88` — video frame count detection failure now logged at DEBUG
- `clip_state.py:215` — manifest JSON parse failure now logged at DEBUG

### inference_engine.py Modernization
- Replaced 4 `print()` calls with proper `logging` (model load, PosEmbed mismatch, missing/unexpected keys)
- Added `logger = logging.getLogger(__name__)` infrastructure

### Entry/Exit Logging
- `_read_input_frame()` — logs frame index at DEBUG
- `_write_outputs()` — logs clip name, frame index, stem at DEBUG
- `detect_device()` — logs selected device at INFO
- `scan_clips_dir()` — logs clip count at INFO

### Documentation
- Created `dev-docs/guides/debug-log-bible.md` — process chains, log format, debug queries, module logger names
- Added `logs/` to `.gitignore`

---

## 2026-02-28 — Comprehensive Backend Test Suite

### New Test Files (7 created/updated)
- `tests/conftest.py` — shared fixtures: `sample_frame`, `sample_mask`, `tmp_clip_dir` (real tiny PNGs), `sample_clip`
- `tests/test_service.py` — 45 tests covering CorridorKeyService (init, device detection, VRAM, model residency, engine loading, scan/filter, frame I/O, write image/manifest/outputs, run_inference full pipeline, reprocess, unload, GVM)
- `tests/test_service_videomama_contract.py` — 10 tests documenting VideoMaMa dtype/range contracts (float32 [0,1] input, binary mask threshold, output write, uint8 binarization bug, missing assets, cancellation)
- `tests/test_service_concurrency.py` — 2 behavioral GPU lock tests (serialization via timestamps, model switch under contention)
- `tests/test_job_queue_full.py` — 37 tests for GPUJobQueue lifecycle (submit→start→complete, failure, cancellation, mark_cancelled, callbacks, callback safety, deduplication, find_job, properties, clear_history, GPUJob)
- `tests/test_validators_edge.py` — 13 edge case tests (normalize_mask_dtype with int32/int64/bool/uint32, zero frame counts, 1D/4D mask arrays, empty arrays, idempotent dir creation)
- `tests/test_invalid_format.py` — 8 format validation tests (EXR flags, PNG conversion, unknown format fallback, OutputConfig with non-standard formats)

### Bug Fix
- **Manifest atomic write** (`service.py:416-419`): Replaced `os.remove()` + `os.rename()` with `os.replace()` — eliminates window where manifest file disappears between remove and rename

### Test Coverage Results
- Before: 77 tests (0 covering service.py)
- After: 224 tests passed, 1 skipped
- service.py: 0 → 45 tests (all 22 methods covered)
- job_queue.py: 4 → 41 tests (full lifecycle, cancellation, callbacks)
- validators.py: 20 → 33 tests (edge cases documented)

### Identified Issues Documented in Tests
- VideoMaMa dtype contract: `_load_frames_for_videomama()` returns float32 [0,1] but uint8 input to `clip(x, 0, 1)*255` binarizes all non-zero values to 255
- Callback exception safety: on_completion/on_error raising exceptions must not corrupt job queue state
- Zero-frame COMPLETE policy: `processed == num_frames` passes when both are 0
- normalize_mask_dtype: int32/int64 values cast without normalizing to [0,1] range

---

## [Phase 4] - 2026-02-28 — Advanced: GPU Safety, Output Config, Live Reprocess, Sessions, PyInstaller

`8833736` — 17 files changed, 1227 insertions, 106 deletions

### GPU Serialization & Thread Safety
- Added `threading.Lock` (`_gpu_lock`) to `CorridorKeyService` — wraps ALL model operations (`_ensure_model`, `process_frame`, `run_inference`, `run_gvm`, `run_videomama`, `reprocess_single_frame`)
- Prevents concurrent GPU access that could corrupt model state or OOM

### PREVIEW_REPROCESS Job Type
- New `JobType.PREVIEW_REPROCESS` with "latest-only" replacement semantics
- Submitting a new preview job cancels any queued preview for the same clip
- Routes through the same GPU queue as inference (no bypass)
- Rapid slider changes only keep the most recent request

### Output Configuration
- New `OutputConfig` dataclass: per-output enable/disable flags and format selectors (EXR/PNG) for FG, Matte, Comp, Processed
- `to_dict()` / `from_dict()` serialization on both `InferenceParams` and `OutputConfig`
- OUTPUT section added to parameter panel with checkboxes and format dropdowns

### Run Manifest
- `.corridorkey_manifest.json` written atomically (tmp+rename) after each inference run
- Records enabled outputs and parameters used
- `completed_stems()` reads manifest to determine which output dirs to check for resume
- Falls back to FG+Matte intersection when no manifest exists (backward compat)

### Live Preview Reprocess
- "Live Preview" checkbox in parameter panel
- 200ms debounced `QTimer` on `params_changed` signal
- Submits `PREVIEW_REPROCESS` through GPU queue (serialized, not parallel)
- `reprocess_single_frame()` on service: GPU-locked, in-memory only, no disk write
- Signal suppression (`_suppress_signals`) during session restore prevents event storms

### Session Save/Load
- JSON sidecar `.corridorkey_session.json` in clips directory
- `_SESSION_VERSION = 1` with forward compatibility (ignores unknown keys)
- Atomic write (tmp+rename pattern)
- Auto-save on window close, auto-load on directory change
- Ctrl+S / Ctrl+O keyboard shortcuts
- Captures: params, output config, live preview state, split view position, window geometry, splitter sizes, selected clip

### PyInstaller Packaging
- `corridorkey.spec` — bundles QSS theme and fonts, hidden imports for all modules, excludes matplotlib/tkinter/jupyter, Console=False
- `scripts/build_windows.ps1` — PowerShell build script with checkpoint copy and build summary

### Frozen Build Support
- `get_base_dir()` / `get_app_dir()` in main.py (sys._MEIPASS aware)
- Frozen-aware paths in `ui/theme/__init__.py`, `ui/app.py`, `backend/service.py`
- Fixed `run_cli()` with proper `hasattr` checks and ImportError handling

### Tests (20 new)
- `test_job_queue_phase4.py` — PREVIEW_REPROCESS replacement, no blocking inference, dedup unchanged, rapid requests
- `test_output_config.py` — InferenceParams roundtrip, OutputConfig roundtrip, enabled_outputs, manifest-based resume, fallback resume
- `test_session.py` — params roundtrip, session format, forward compat, corrupt file handling, atomic write

---

## [Phase 3] - 2026-02-28 — Preview Polish: Split View, Scrubber, View Modes, Zoom/Pan, Thumbnails

`938008f` — 19 files changed, 1809 insertions, 89 deletions

### Split View
- `SplitViewWidget` — before/after comparison with draggable yellow (#FFF203) divider
- Vertical split line, smooth drag, keyboard toggle

### Frame Scrubber
- `FrameScrubber` — timeline widget with frame-accurate seeking
- Click-to-seek, drag scrubbing, frame counter display

### View Modes
- `ViewModeBar` — toggle buttons for Input, Alpha, FG, Matte, Comp, Processed
- Each mode loads from corresponding output directory
- Keyboard shortcuts for quick switching

### Preview Viewport Overhaul
- Zoom (mouse wheel) + pan (middle-click drag)
- Fit-to-viewport on load, zoom-to-cursor behavior
- EXR → 8-bit display transform for HDR content

### Display Transform Pipeline
- `display_transform.py` — tone mapping, gamma correction, alpha compositing over checkerboard
- Handles EXR (float32), PNG (uint8), and mixed formats
- Checkerboard background for transparency visualization

### Frame Index System
- `FrameIndex` — stem-based navigation (not list index) prevents cross-mode misalignment
- `natural_sort.py` — handles non-zero-padded filenames (frame1, frame2, ..., frame10)

### Async Decoder
- `AsyncDecoder` — background frame loading with LRU cache
- Prevents UI blocking on large EXR files

### Thumbnails
- `ThumbnailWorker` — extracts first frame from each clip in background thread
- 60x40px thumbnails displayed in clip browser cards
- `ClipCardDelegate` — custom paint delegate with thumbnail, state badge, frame count

### Tests (15 new)
- `test_display_transform.py` — tone mapping, gamma, alpha compositing
- `test_frame_index.py` — stem navigation, boundary checks, natural sort integration
- `test_natural_sort.py` — zero-padded, non-padded, mixed filenames

---

## [Phase 1+2] - 2026-02-28 — GUI Shell + Batch Queue + GVM/VideoMaMa

`4970885` — 18 files changed, 2497 insertions

### Application Shell
- `ui/app.py` — QApplication with Corridor Digital dark theme, Open Sans font loading
- `main.py` — entry point with `--gui` (default) and `--cli` fallback

### 3-Panel Layout
- `MainWindow` — QSplitter-based 3-panel layout (clip browser | preview | parameters)
- Menu bar: File (Open, Save Session), View, Help
- Brand wordmark header

### Clip Browser (Left Panel)
- `ClipBrowser` — scrollable list with `ExtendedSelection` for batch ops
- `ClipCard` — card widget with state badge (RAW=gray, MASKED=blue, READY=yellow, COMPLETE=green, ERROR=red)
- [+ADD] button → QFileDialog for clips directory
- [WATCH] toggle → QFileSystemWatcher for auto-detection of new clips
- Drag-and-drop folder support
- Processing guards: watcher won't reclassify clips being processed

### Preview Viewport (Center Panel)
- `PreviewViewport` — QLabel + QPixmap display (CPU-rendered, zero VRAM)
- Downsample to viewport size for performance
- Frame navigation (left/right arrows)

### Parameter Panel (Right Panel)
- `ParameterPanel` — all inference controls
- Color Space dropdown (sRGB / Linear)
- Despill strength slider (0-10 → 0.0-1.0)
- Despeckle toggle + size spinbox
- Refiner scale slider (0-30 → 0.0-3.0)
- GVM AUTO and VIDEOMAMA alpha generation buttons (state-gated)

### Status Bar (Bottom)
- `StatusBar` — progress bar, frame counter, percentage, ETA
- VRAM usage bar with numeric readout
- GPU name badge
- [RUN INFERENCE] / [STOP] button with state toggle

### Queue Panel
- `QueuePanel` — visual job queue display
- Per-job progress, status badges, cancel buttons
- Batch queue management

### GPU Job Worker
- `GPUJobWorker` — single QThread processing jobs from `GPUJobQueue`
- Handles INFERENCE, GVM, VIDEOMAMA job types
- Per-frame progress signals, preview throttling (every 5th frame)
- Cancel/abort support (checks `_abort` flag between frames)
- Resume support (skips completed frames)
- Settings snapshot per job (params frozen at queue time)

### GPU Monitor
- `GPUMonitor` — QTimer polling `torch.cuda.memory_reserved()` every 2 seconds
- Reports VRAM usage, GPU name, temperature
- Fallback to nvidia-smi subprocess if torch unavailable

### Clip Model
- `ClipListModel` — QAbstractListModel wrapping ClipEntry list
- Custom roles for clip data, state, thumbnails
- Batch update support, count change signals

### Theme
- `corridor_theme.qss` — 398 lines, full brand stylesheet
- Dark-only: #141300 background, #1E1D13 panels, #FFF203 accents
- Zero border-radius on all widgets
- Styled scrollbars, tooltips, group boxes, menus

---

## [Phase 0] - 2026-02-28 — Backend Service Layer + Bug Fixes

`ef8e636` — Backend extraction from clip_manager.py

### Bug Fixes
- **BUG 1 (CRITICAL):** Fixed `cu.to_srgb()` → `cu.linear_to_srgb()` in inference_engine.py (linear mode was crashing)
- **BUG 2 (CRITICAL):** Fixed mask channel handling — always reduces to single channel regardless of input (2ch/4ch EXR no longer creates invalid tensors)
- **BUG 3 (HIGH):** Added logging for frame count mismatches and read failures (was silently truncating/skipping)
- **BUG 4 (HIGH):** Added cv2.imwrite() return value checking (disk full / permission errors no longer silent)
- **DEPENDENCY:** Changed `opencv-python` → `opencv-python-headless` (avoids Qt5 plugin conflict with PySide6)

### Backend Architecture
- `backend/service.py` — `CorridorKeyService` wrapping scan, validate, process, write operations
- `backend/clip_state.py` — `ClipEntry` dataclass + state machine (RAW → MASKED → READY → COMPLETE → ERROR)
- `backend/job_queue.py` — `GPUJobQueue` with mutual exclusion, deduplication, priority scheduling
- `backend/validators.py` — frame count validation, mask channel checks, write verification
- `backend/errors.py` — typed exceptions (FrameMismatchError, WriteFailureError, VRAMInsufficientError, etc.)

### Tests (32 tests)
- `test_validators.py` — frame parity, mask channel validation, write checks
- `test_clip_state.py` — state machine transitions, guard conditions
- `test_job_queue.py` — queue ordering, dedup, mutual exclusion

---

## Pre-GUI Releases

### 2026-02-27
- `a29d8b3` Rename MaskHint to VideoMamaMaskHint across codebase and folders

### 2026-02-26
- `f35fffe` Optimize inference VRAM with FP16 autocast

### 2026-02-25
- `cec7b85` Add Windows Auto-Installer scripts with HuggingFace model downloads
- `5e5f8dc` Add licensing and acknowledgements for GVM and VideoMaMa
- `0e4bbdc` Add comprehensive master README.md
- `d86ec87` Add technical handover document (LLM_HANDOVER.md)
- `ec6a0c9` Remove unused PointRend module from CorridorKeyModule
- `38989bf` Add true sRGB conversions to color_utils, refiner scale to wizard

### 2026-02-23
- `418a324` Add local Windows and Linux launcher scripts

### 2026-02-22
- `4f1dad6` Add luminance-preserving despill, configurable auto-despeckling garbage matte, checkerboard composite
- `d5559bc` Initial commit: Smart Wizard, VideoMaMa Integration, Optional GVM

