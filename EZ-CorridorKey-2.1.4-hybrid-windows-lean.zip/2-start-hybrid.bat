@echo off
TITLE EZ-CorridorKey Hybrid (GPU+CPU+RAM)
cd /d "%~dp0"

REM Load hybrid env if present
if exist "%~dp0hybrid.env.bat" call "%~dp0hybrid.env.bat"

REM Defaults for hybrid 4GB-class GPU + system RAM
if not defined CORRIDORKEY_HYBRID set "CORRIDORKEY_HYBRID=1"
if not defined CORRIDORKEY_DEVICE set "CORRIDORKEY_DEVICE=auto"
if not defined CORRIDORKEY_OPT_MODE set "CORRIDORKEY_OPT_MODE=lowvram"
if not defined CORRIDORKEY_VRAM_GB set "CORRIDORKEY_VRAM_GB=4"
if not defined CORRIDORKEY_RAM_BUFFER_GB set "CORRIDORKEY_RAM_BUFFER_GB=10"
if not defined CORRIDORKEY_BIREFNET_DEFAULT set "CORRIDORKEY_BIREFNET_DEFAULT=Matting Lite"

if exist "%~dp0tools\ffmpeg\bin\ffmpeg.exe" set "PATH=%~dp0tools\ffmpeg\bin;%PATH%"

if not exist ".venv\Scripts\activate.bat" (
  echo [INFO] No .venv - run installer\Install-Hybrid-GPU.bat first
  pause
  exit /b 1
)

echo.
echo  EZ-CorridorKey Hybrid
echo  Device=%CORRIDORKEY_DEVICE%  VRAM=%CORRIDORKEY_VRAM_GB%GB  RAM_BUF=%CORRIDORKEY_RAM_BUFFER_GB%GB  OPT=%CORRIDORKEY_OPT_MODE%
echo.

call .venv\Scripts\activate.bat
start "" pythonw main.py %*
exit
