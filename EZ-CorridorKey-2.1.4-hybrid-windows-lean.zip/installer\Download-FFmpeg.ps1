#requires -Version 5.1
# Download a minimal FFmpeg build into tools\ffmpeg\bin (not shipped in lean zip).
param(
  [string]$SourceRoot = ""
)

$ErrorActionPreference = "Stop"
if (-not $SourceRoot) {
  $SourceRoot = Split-Path -Parent $PSScriptRoot
}
$SourceRoot = (Resolve-Path $SourceRoot).Path
$destBin = Join-Path $SourceRoot "tools\ffmpeg\bin"
New-Item -ItemType Directory -Force -Path $destBin | Out-Null

if ((Test-Path (Join-Path $destBin "ffmpeg.exe")) -and (Test-Path (Join-Path $destBin "ffprobe.exe"))) {
  Write-Host "FFmpeg already present at $destBin"
  exit 0
}

# Official essentials build (smaller than full)
$url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
$tmp = Join-Path $env:TEMP "ffmpeg-essentials.zip"
$extract = Join-Path $env:TEMP "ffmpeg-essentials-extract"

Write-Host "Downloading FFmpeg essentials..."
Write-Host "  $url"
Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing

if (Test-Path $extract) { Remove-Item $extract -Recurse -Force }
Expand-Archive -Path $tmp -DestinationPath $extract -Force

$bin = Get-ChildItem $extract -Recurse -Directory -Filter "bin" | Select-Object -First 1
if (-not $bin) { throw "Could not find bin/ in FFmpeg zip" }

Copy-Item (Join-Path $bin.FullName "ffmpeg.exe") $destBin -Force
Copy-Item (Join-Path $bin.FullName "ffprobe.exe") $destBin -Force
if (Test-Path (Join-Path $bin.FullName "ffplay.exe")) {
  # Skip ffplay to save disk - not required for CorridorKey
}

Write-Host "Installed:" -ForegroundColor Green
Get-ChildItem $destBin | ForEach-Object { Write-Host "  $($_.FullName)" }
Write-Host "Done."
