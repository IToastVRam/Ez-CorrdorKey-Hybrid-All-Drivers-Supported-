@echo off
setlocal
cd /d "%~dp0\.."
title EZ-CorridorKey Hybrid Installer
echo.
echo  EZ-CorridorKey - Hybrid GPU + CPU + RAM installer
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Hybrid-GPU.ps1" -SourceRoot "%cd%"
echo.
pause
