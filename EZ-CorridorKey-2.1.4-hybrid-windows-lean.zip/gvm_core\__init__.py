from .wrapper import GVMProcessor
