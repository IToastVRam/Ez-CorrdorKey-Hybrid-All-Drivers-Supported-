"""Shared path resolution for CorridorKey <-> DaVinci Resolve bridge."""

from __future__ import annotations

import json
import os
from pathlib import Path

_BRIDGE_DIR = Path(__file__).resolve().parent
_DEFAULT_CK = Path(r"E:\Dev\EZ-CorridorKey")
_DEFAULT_RESOLVE = Path(r"D:\New Folder")


def _expand(p: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(p)))


def load_paths() -> dict:
    cfg = _BRIDGE_DIR / "paths.json"
    data = {}
    if cfg.exists():
        try:
            data = json.loads(cfg.read_text(encoding="utf-8"))
        except Exception:
            data = {}

    ck = _expand(data.get("corridor_key_root") or str(_DEFAULT_CK))
    resolve_root = _expand(data.get("resolve_root") or str(_DEFAULT_RESOLVE))

    # Discover Resolve if default missing
    if not (resolve_root / "Resolve.exe").exists():
        for cand in _discover_resolve_roots():
            if (cand / "Resolve.exe").exists():
                resolve_root = cand
                break

    # Discover CK if moved
    if not (ck / "main.py").exists() and not (ck / "2-start.bat").exists():
        for cand in (
            Path(r"E:\Dev\EZ-CorridorKey"),
            Path(r"D:\Coriddor key\EZ-CorridorKey-main"),
            Path(r"E:\corridor key\EZ-CorridorKey-main"),
        ):
            if (cand / "main.py").exists() or (cand / "2-start.bat").exists():
                ck = cand
                break

    user_scripts = _expand(
        data.get("resolve_scripts_user")
        or r"%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts"
    )
    system_scripts = _expand(
        data.get("resolve_scripts_system")
        or r"C:\ProgramData\Blackmagic Design\DaVinci Resolve\Fusion\Scripts"
    )

    out = {
        "corridor_key_root": ck,
        "corridor_start_bat": _expand(data.get("corridor_start_bat") or str(ck / "2-start.bat")),
        "corridor_clips_in": _expand(data.get("corridor_clips_in") or str(ck / "ClipsForInference")),
        "corridor_output": _expand(data.get("corridor_output") or str(ck / "Output")),
        "resolve_root": resolve_root,
        "resolve_exe": _expand(data.get("resolve_exe") or str(resolve_root / "Resolve.exe")),
        "resolve_fuscript": _expand(data.get("resolve_fuscript") or str(resolve_root / "fuscript.exe")),
        "resolve_scripts_user": user_scripts,
        "resolve_scripts_system": system_scripts,
        "vram_budget_gb": float(data.get("vram_budget_gb") or 4),
    }
    return out


def _discover_resolve_roots() -> list[Path]:
    roots: list[Path] = []
    # Shortcut targets
    shortcut_dirs = [
        Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
        / "Microsoft"
        / "Windows"
        / "Start Menu"
        / "Programs"
        / "Blackmagic Design",
        Path(os.environ.get("PUBLIC", r"C:\Users\Public")) / "Desktop",
        Path.home() / "Desktop",
    ]
    for d in shortcut_dirs:
        if not d.exists():
            continue
        for lnk in d.rglob("*.lnk"):
            if "resolve" not in lnk.name.lower():
                continue
            try:
                import win32com.client  # type: ignore

                shell = win32com.client.Dispatch("WScript.Shell")
                sc = shell.CreateShortCut(str(lnk))
                target = Path(sc.Targetpath)
                if target.name.lower() == "resolve.exe" and target.exists():
                    roots.append(target.parent)
            except Exception:
                # Fallback: parse via PowerShell-created known path
                pass
    # Known installs
    for p in (
        Path(r"D:\New Folder"),
        Path(r"C:\Program Files\Blackmagic Design\DaVinci Resolve"),
        Path(r"C:\Program Files\Blackmagic Design\DaVinci Resolve 19"),
        Path(r"C:\Program Files\Blackmagic Design\DaVinci Resolve 18"),
    ):
        if p.exists():
            roots.append(p)
    # dedupe
    seen = set()
    out = []
    for r in roots:
        key = str(r.resolve()) if r.exists() else str(r)
        if key not in seen:
            seen.add(key)
            out.append(r)
    return out


def save_paths(updates: dict | None = None) -> Path:
    cfg = _BRIDGE_DIR / "paths.json"
    data = {}
    if cfg.exists():
        try:
            data = json.loads(cfg.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    current = load_paths()
    for k, v in current.items():
        data[k] = str(v)
    if updates:
        for k, v in updates.items():
            data[k] = str(v)
    cfg.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return cfg


def ensure_ck_folders(paths: dict | None = None) -> dict:
    p = paths or load_paths()
    for key in ("corridor_clips_in", "corridor_output"):
        Path(p[key]).mkdir(parents=True, exist_ok=True)
    return p
