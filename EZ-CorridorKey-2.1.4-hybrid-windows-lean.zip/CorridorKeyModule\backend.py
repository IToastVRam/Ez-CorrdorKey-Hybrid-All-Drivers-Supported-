"""Backend factory — selects Torch or MLX engine and normalizes output contracts."""

from __future__ import annotations

import glob
import logging
import os
import platform
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)

from .inference_engine import INFERENCE_DEFAULTS as _D

_BUNDLED_CHECKPOINT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "checkpoints")

def _resolve_checkpoint_dir() -> str:
    """Return the writable checkpoint directory.

    In development mode (not frozen), this is CorridorKeyModule/checkpoints/.
    In a frozen PyInstaller build, delegates to backend.project.get_data_dir()
    for the user-chosen install path.
    """
    if not getattr(sys, "frozen", False):
        return _BUNDLED_CHECKPOINT_DIR
    try:
        from backend.project import get_data_dir
        ckpt_dir = os.path.join(get_data_dir(), "CorridorKeyModule", "checkpoints")
        os.makedirs(ckpt_dir, exist_ok=True)
        return ckpt_dir
    except ImportError:
        return _BUNDLED_CHECKPOINT_DIR

CHECKPOINT_DIR = _resolve_checkpoint_dir()
TORCH_EXT = ".pth"
MLX_EXT = ".safetensors"
DEFAULT_IMG_SIZE = 2048


def _checkpoint_search_dirs() -> list[str]:
    """Directories to scan for checkpoints, in priority order.

    The writable data dir comes first so user-downloaded or updated weights
    win, then the bundled dir (next to this module, which in a frozen onedir
    build is _internal/CorridorKeyModule/checkpoints). Both the green and blue
    core weights are bundled by the installers, but _resolve_checkpoint_dir()
    points at the writable data dir when frozen, so without this fallback the
    bundled weights are shipped yet never loaded — a fresh install would prompt
    to re-download core models that are already on disk.
    """
    dirs: list[str] = []
    for d in (CHECKPOINT_DIR, _BUNDLED_CHECKPOINT_DIR):
        if d and d not in dirs:
            dirs.append(d)
    return dirs


def _glob_suffix(ext: str) -> str:
    """Filename suffix to match for a checkpoint extension.

    MLX weights follow the ``<name>.mlx.safetensors`` convention. Matching the
    bare ``.safetensors`` would also pick up the legacy external-package file
    ``corridorkey_mlx.safetensors`` (underscore, not dot, before ``mlx``),
    whose architecture differs from the built-in MLX model and fails to load
    with a large parameter-mismatch error. Require the ``.mlx.`` infix so only
    current-format MLX weights match; the legacy file is ignored.
    """
    return ".mlx.safetensors" if ext == MLX_EXT else ext


def _glob_checkpoints(ext: str) -> list[str]:
    """Glob the checkpoints for ``ext`` across all search dirs, deduped by name.

    Earlier dirs win on a name collision, so a user-updated weight in the
    writable dir shadows the bundled copy of the same name. MLX matching is
    narrowed to the current ``.mlx.safetensors`` convention (see _glob_suffix).
    """
    suffix = _glob_suffix(ext)
    out: list[str] = []
    seen: set[str] = set()
    for d in _checkpoint_search_dirs():
        for match in glob.glob(os.path.join(d, f"*{suffix}")):
            key = os.path.basename(match).lower()
            if key not in seen:
                seen.add(key)
                out.append(match)
    return out

BACKEND_ENV_VAR = "CORRIDORKEY_BACKEND"
VALID_BACKENDS = ("auto", "torch", "mlx")


def resolve_backend(requested: str | None = None) -> str:
    """Resolve backend: CLI flag > env var > auto-detect.

    Auto mode: Apple Silicon + corridorkey_mlx importable + .safetensors found -> mlx.
    Otherwise -> torch.

    Raises RuntimeError if explicit backend is unavailable.
    """
    if requested is None or requested.lower() == "auto":
        backend = os.environ.get(BACKEND_ENV_VAR, "auto").lower()
    else:
        backend = requested.lower()

    if backend == "auto":
        return _auto_detect_backend()

    if backend not in VALID_BACKENDS:
        raise RuntimeError(f"Unknown backend '{backend}'. Valid: {', '.join(VALID_BACKENDS)}")

    if backend == "mlx":
        _validate_mlx_available()

    return backend


def _auto_detect_backend() -> str:
    """Try MLX on Apple Silicon, fall back to Torch."""
    if sys.platform != "darwin" or platform.machine() != "arm64":
        logger.info("Not Apple Silicon — using torch backend")
        return "torch"

    try:
        import mlx.core  # noqa: F401
    except ImportError:
        try:
            import corridorkey_mlx  # type: ignore[import-not-found]  # noqa: F401
        except ImportError:
            logger.info("Neither mlx nor corridorkey_mlx installed — using torch backend")
            return "torch"

    safetensor_files = _glob_checkpoints(MLX_EXT)
    if not safetensor_files:
        logger.info("No %s checkpoint found — using torch backend", MLX_EXT)
        return "torch"

    # MLX's Metal backend must be initialized on the main thread.  If the
    # main-thread prewarm (pyi_rth_mlx.py / app.py) failed silently and
    # mlx.core was never imported, attempting the first import here on a
    # worker thread will cause Metal to abort() the process.  Fall back to
    # Torch/MPS instead of crashing.
    import threading
    if "mlx.core" not in sys.modules and threading.current_thread() is not threading.main_thread():
        logger.warning(
            "mlx.core not initialized on main thread — falling back to "
            "torch/MPS to avoid Metal abort().  This usually means the MLX "
            "prewarm failed at startup; check earlier log messages."
        )
        return "torch"

    logger.info("Apple Silicon + MLX available — using mlx backend")
    return "mlx"


def _validate_mlx_available() -> None:
    """Raise RuntimeError with actionable message if MLX can't be used."""
    if sys.platform != "darwin" or platform.machine() != "arm64":
        raise RuntimeError("MLX backend requires Apple Silicon (M1+ Mac)")

    try:
        import mlx.core  # noqa: F401
    except ImportError:
        try:
            import corridorkey_mlx  # type: ignore[import-not-found]  # noqa: F401
        except ImportError as err:
            raise RuntimeError(
                "MLX backend requested but mlx is not installed. "
                "Install with: pip install mlx"
            ) from err


def _discover_checkpoint(ext: str, screen_color: str = "green") -> Path:
    """Find the checkpoint for the given extension and screen color.

    For Torch (.pth):
      green -> CorridorKey.pth (or any .pth not containing "Blue")
      blue  -> CorridorKeyBlue*.pth

    Falls back to any available checkpoint if the requested variant
    is missing, so single-checkpoint installs keep working.

    Raises FileNotFoundError if no checkpoint exists at all.
    """
    all_matches = _glob_checkpoints(ext)

    if not all_matches:
        other_ext = MLX_EXT if ext == TORCH_EXT else TORCH_EXT
        other_files = _glob_checkpoints(other_ext)
        hint = ""
        if other_files:
            other_backend = "mlx" if other_ext == MLX_EXT else "torch"
            hint = f" (Found {other_ext} files — did you mean CORRIDORKEY_BACKEND={other_backend}?)"
        searched = ", ".join(_checkpoint_search_dirs())
        raise FileNotFoundError(f"No {ext} checkpoint found in {searched}.{hint}")

    # Split into blue and green (non-blue) variants
    blue_matches = [m for m in all_matches if "blue" in os.path.basename(m).lower()]
    green_matches = [m for m in all_matches if "blue" not in os.path.basename(m).lower()]

    if screen_color == "blue":
        if blue_matches:
            return Path(blue_matches[0])
        logger.warning("Blue checkpoint not found, falling back to green")
        return Path(all_matches[0])
    else:
        if green_matches:
            return Path(green_matches[0])
        logger.warning("Green checkpoint not found, falling back to blue")
        return Path(all_matches[0])


def has_blue_checkpoint() -> bool:
    """Check if a blue-screen checkpoint is available."""
    for ext in (TORCH_EXT, MLX_EXT):
        matches = _glob_checkpoints(ext)
        if any("blue" in os.path.basename(m).lower() for m in matches):
            return True
    return False


def _wrap_mlx_output(
    raw: dict,
    source_image: np.ndarray,
    input_is_linear: bool,
    despill_strength: float,
    auto_despeckle: bool,
    despeckle_size: int,
    despeckle_dilation: int = _D["despeckle_dilation"],
    despeckle_blur: int = _D["despeckle_blur"],
    screen_color: str = _D["screen_color"],
    garbage_matte_px: int = _D["garbage_matte_px"],
    mask_linear: np.ndarray | None = None,
) -> dict:
    """Normalize MLX uint8 output to match Torch float32 contract.

    Torch contract:
      alpha:     [H,W,1] float32 0-1
      fg:        [H,W,3] float32 0-1 sRGB
      comp:      [H,W,3] float32 0-1 sRGB
      processed: [H,W,4] float32 linear premultiplied RGBA
    """
    from CorridorKeyModule.core import color_utils as cu

    # alpha: uint8 [H,W] -> float32 [H,W,1]
    alpha_raw = raw["alpha"]
    alpha = alpha_raw.astype(np.float32) / 255.0
    if alpha.ndim == 2:
        alpha = alpha[:, :, np.newaxis]

    # fg: uint8 [H,W,3] -> float32 [H,W,3] (sRGB)
    fg = raw["fg"].astype(np.float32) / 255.0

    # Apply despeckle (MLX stubs this)
    if auto_despeckle:
        processed_alpha = cu.clean_matte(
            alpha, area_threshold=despeckle_size,
            dilation=despeckle_dilation, blur_size=despeckle_blur,
        )
    else:
        processed_alpha = alpha

    # Apply garbage matte
    if garbage_matte_px > 0 and mask_linear is not None:
        k = 2 * garbage_matte_px + 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
        hint_2d = mask_linear[:, :, 0] if mask_linear.ndim == 3 else mask_linear
        expanded_hint = cv2.dilate(hint_2d, kernel)
        if expanded_hint.ndim == 2:
            expanded_hint = expanded_hint[:, :, np.newaxis]
        processed_alpha = processed_alpha * expanded_hint

    # Apply despill (MLX stubs this)
    fg_despilled = cu.despill(fg, green_limit_mode="average", strength=despill_strength,
                              screen_color=screen_color)

    if source_image.dtype != np.float32:
        source_rgb = source_image.astype(np.float32)
        if source_rgb.max() > 1.0:
            source_rgb /= 255.0
    else:
        source_rgb = source_image

    source_srgb = cu.linear_to_srgb(source_rgb) if input_is_linear else source_rgb
    source_lin = source_rgb if input_is_linear else cu.srgb_to_linear(source_rgb)

    # Despill the source too — _restore_opaque_source_detail blends source
    # pixels back in, and they must already be despilled or they undo the
    # despill we just applied to the model fg.
    source_srgb_despilled = cu.despill(source_srgb, green_limit_mode="average",
                                       strength=despill_strength, screen_color=screen_color)
    source_lin_despilled = cu.srgb_to_linear(source_srgb_despilled)

    # Composite over checkerboard for comp output
    h, w = fg.shape[:2]
    bg_srgb = cu.create_checkerboard(w, h, checker_size=128, color1=0.15, color2=0.55)
    bg_lin = cu.srgb_to_linear(bg_srgb)
    fg_despilled_lin = cu.srgb_to_linear(fg_despilled)
    fg_despilled_lin = _restore_opaque_source_detail(
        source_lin_despilled,
        source_srgb_despilled,
        fg_despilled_lin,
        processed_alpha,
        screen_color=screen_color,
    )
    comp_lin = cu.composite_straight(fg_despilled_lin, bg_lin, processed_alpha)
    comp_srgb = cu.linear_to_srgb(comp_lin)

    # Build processed: [H,W,4] premultiplied linear RGBA
    fg_premul_lin = cu.premultiply(fg_despilled_lin, processed_alpha)
    processed_rgba = np.concatenate([fg_premul_lin, processed_alpha], axis=-1)

    # Restore source detail on FG for display accuracy (MLX model colors
    # are lower fidelity than CUDA — blend original source back in on
    # opaque regions so FG view matches what the user shot).
    fg_lin = cu.srgb_to_linear(fg)
    fg_restored_lin = _restore_opaque_source_detail(
        source_lin_despilled, source_srgb_despilled, fg_lin, processed_alpha,
        screen_color=screen_color,
    )
    fg_restored = cu.linear_to_srgb(fg_restored_lin)

    return {
        "alpha": alpha,
        "fg": fg_restored,
        "comp": comp_srgb,
        "processed": processed_rgba,
    }


def _assemble_mlx_output(
    *,
    alpha: np.ndarray,
    fg: np.ndarray,
    source_image: np.ndarray,
    input_is_linear: bool,
    despill_strength: float,
    auto_despeckle: bool,
    despeckle_size: int,
    despeckle_dilation: int = _D["despeckle_dilation"],
    despeckle_blur: int = _D["despeckle_blur"],
    screen_color: str = _D["screen_color"],
    garbage_matte_px: int = _D["garbage_matte_px"],
    mask_linear: np.ndarray | None = None,
) -> dict:
    """Assemble the shared Torch-style contract from MLX float outputs."""
    from CorridorKeyModule.core import color_utils as cu

    alpha = np.clip(alpha.astype(np.float32, copy=False), 0.0, 1.0)
    if alpha.ndim == 2:
        alpha = alpha[:, :, np.newaxis]

    fg = np.clip(fg.astype(np.float32, copy=False), 0.0, 1.0)

    if auto_despeckle:
        processed_alpha = cu.clean_matte(
            alpha, area_threshold=despeckle_size,
            dilation=despeckle_dilation, blur_size=despeckle_blur,
        )
    else:
        processed_alpha = alpha

    if garbage_matte_px > 0 and mask_linear is not None:
        k = 2 * garbage_matte_px + 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
        hint_2d = mask_linear[:, :, 0] if mask_linear.ndim == 3 else mask_linear
        expanded_hint = cv2.dilate(hint_2d, kernel)
        if expanded_hint.ndim == 2:
            expanded_hint = expanded_hint[:, :, np.newaxis]
        processed_alpha = processed_alpha * expanded_hint

    fg_despilled = cu.despill(fg, green_limit_mode="average", strength=despill_strength,
                              screen_color=screen_color)

    if source_image.dtype != np.float32:
        source_rgb = source_image.astype(np.float32)
        if source_rgb.max() > 1.0:
            source_rgb /= 255.0
    else:
        source_rgb = source_image

    source_srgb = cu.linear_to_srgb(source_rgb) if input_is_linear else source_rgb
    source_lin = source_rgb if input_is_linear else cu.srgb_to_linear(source_rgb)

    # Despill the source too — _restore_opaque_source_detail blends source
    # pixels back in, and they must already be despilled or they undo the
    # despill we just applied to the model fg.
    source_srgb_despilled = cu.despill(source_srgb, green_limit_mode="average",
                                       strength=despill_strength, screen_color=screen_color)
    source_lin_despilled = cu.srgb_to_linear(source_srgb_despilled)

    h, w = fg.shape[:2]
    bg_srgb = cu.create_checkerboard(w, h, checker_size=128, color1=0.15, color2=0.55)
    bg_lin = cu.srgb_to_linear(bg_srgb)
    fg_despilled_lin = cu.srgb_to_linear(fg_despilled)
    fg_despilled_lin = _restore_opaque_source_detail(
        source_lin_despilled,
        source_srgb_despilled,
        fg_despilled_lin,
        processed_alpha,
        screen_color=screen_color,
    )
    comp_lin = cu.composite_straight(fg_despilled_lin, bg_lin, processed_alpha)
    comp_srgb = cu.linear_to_srgb(comp_lin)

    fg_premul_lin = cu.premultiply(fg_despilled_lin, processed_alpha)
    processed_rgba = np.concatenate([fg_premul_lin, processed_alpha], axis=-1)

    # Restore source detail on FG for display accuracy (MLX model colors
    # are lower fidelity than CUDA — blend original source back in on
    # opaque regions so FG view matches what the user shot).
    fg_lin = cu.srgb_to_linear(fg)
    fg_restored_lin = _restore_opaque_source_detail(
        source_lin_despilled, source_srgb_despilled, fg_lin, processed_alpha,
        screen_color=screen_color,
    )
    fg_restored = cu.linear_to_srgb(fg_restored_lin)

    return {
        "alpha": alpha,
        "fg": fg_restored,
        "comp": comp_srgb,
        "processed": processed_rgba,
    }


def _prepare_mlx_image_u8(image: np.ndarray, input_is_linear: bool) -> np.ndarray:
    """Prepare image input for corridorkey-mlx.

    The upstream MLX engine currently assumes sRGB/ImageNet-normalized inputs;
    its `input_is_linear` parameter is a compatibility no-op. So for true
    linear inputs we must convert to sRGB before quantizing to uint8.
    """
    from CorridorKeyModule.core import color_utils as cu

    if image.dtype == np.uint8:
        return image

    image_f32 = image.astype(np.float32, copy=False)
    if image_f32.max() > 1.0:
        image_f32 = image_f32 / 255.0

    if input_is_linear:
        image_f32 = cu.linear_to_srgb(image_f32)

    return (np.clip(image_f32, 0.0, 1.0) * 255.0).astype(np.uint8)


def _resize_float_image_bicubic(image: np.ndarray, size: tuple[int, int]) -> np.ndarray:
    """Resize float image data with PIL bicubic to match upstream MLX behavior."""
    if image.ndim == 2:
        return np.asarray(
            Image.fromarray(image.astype(np.float32), mode="F").resize(size, Image.Resampling.BICUBIC),
            dtype=np.float32,
        )

    if image.ndim == 3 and image.shape[2] == 1:
        resized = np.asarray(
            Image.fromarray(image[:, :, 0].astype(np.float32), mode="F").resize(
                size, Image.Resampling.BICUBIC
            ),
            dtype=np.float32,
        )
        return resized[:, :, np.newaxis]

    if image.ndim == 3 and image.shape[2] >= 2:
        channels = [
            np.asarray(
                Image.fromarray(image[:, :, idx].astype(np.float32), mode="F").resize(
                    size, Image.Resampling.BICUBIC
                ),
                dtype=np.float32,
            )
            for idx in range(image.shape[2])
        ]
        return np.stack(channels, axis=-1)

    raise ValueError(f"Unsupported image shape for float resize: {image.shape}")


def _restore_opaque_source_detail(
    source_lin: np.ndarray,
    source_srgb: np.ndarray,
    image_lin: np.ndarray,
    alpha: np.ndarray,
    *,
    opaque_threshold: float = 0.92,
    opaque_softness: float = 0.08,
    edge_band_radius: int = 8,
    edge_band_softness: int = 6,
    edge_source_alpha_threshold: float = 0.78,
    edge_source_alpha_softness: float = 0.18,
    green_spill_threshold: float = 0.03,
    green_spill_softness: float = 0.08,
    screen_color: str = "green",
) -> np.ndarray:
    """Prefer source detail away from the alpha edge band.

    Near the edge, source color is only preserved when the pixel is still
    reasonably opaque *and* the source does not look screen-contaminated.
    This keeps opaque clothing edges from drifting while still letting
    the model own real spill zones like wispy hair.
    """
    alpha_plane = alpha if alpha.ndim == 3 else alpha[:, :, np.newaxis]
    alpha_plane = np.clip(alpha_plane.astype(np.float32, copy=False), 0.0, 1.0)

    opaque_weight = np.clip(
        (alpha_plane - opaque_threshold) / max(opaque_softness, 1e-6),
        0.0,
        1.0,
    )
    alpha_2d = alpha_plane[:, :, 0]
    opaque_mask = (alpha_2d >= opaque_threshold).astype(np.uint8)

    if opaque_mask.size == 0 or not opaque_mask.any():
        interior_weight = np.zeros_like(alpha_plane, dtype=np.float32)
    elif opaque_mask.all():
        interior_weight = np.ones_like(alpha_plane, dtype=np.float32)
    else:
        dist_to_edge = cv2.distanceTransform(opaque_mask, cv2.DIST_L2, 5)
        interior_weight = np.clip(
            (dist_to_edge - float(edge_band_radius)) / max(float(edge_band_softness), 1e-6),
            0.0,
            1.0,
        )[:, :, np.newaxis]

    edge_source_weight = np.clip(
        (alpha_plane - edge_source_alpha_threshold) / max(edge_source_alpha_softness, 1e-6),
        0.0,
        1.0,
    )

    source_srgb = np.clip(source_srgb.astype(np.float32, copy=False), 0.0, 1.0)
    # Detect spill channel: green=1, blue=2
    if screen_color == "blue":
        spill_ch, other_a, other_b = 2, 0, 1
    else:
        spill_ch, other_a, other_b = 1, 0, 2
    spill_excess = (
        source_srgb[..., spill_ch:spill_ch + 1]
        - np.maximum(source_srgb[..., other_a:other_a + 1],
                      source_srgb[..., other_b:other_b + 1])
    )
    green_spill_weight = np.clip(
        (spill_excess - green_spill_threshold) / max(green_spill_softness, 1e-6),
        0.0,
        1.0,
    )

    safe_edge_source_weight = edge_source_weight * (1.0 - green_spill_weight)
    detail_weight = np.maximum(opaque_weight * interior_weight, safe_edge_source_weight)
    return image_lin * (1.0 - detail_weight) + source_lin * detail_weight


def _try_mlx_float_outputs(raw_engine, image_u8: np.ndarray, mask_u8: np.ndarray, refiner_scale: float) -> dict | None:
    """Use corridorkey-mlx internals to recover float outputs before uint8 quantization."""
    if not hasattr(raw_engine, "_model") or not hasattr(raw_engine, "_img_size"):
        return None

    try:
        import mlx.core as mx
        from corridorkey_mlx.io.image import preprocess
    except Exception as exc:
        logger.debug("MLX float-output path unavailable: %s", exc)
        return None

    original_h, original_w = image_u8.shape[:2]
    target_size = int(getattr(raw_engine, "_img_size"))

    rgb_f32 = image_u8.astype(np.float32) / 255.0
    mask_plane = mask_u8 if mask_u8.ndim == 2 else mask_u8[:, :, 0]
    mask_f32 = mask_plane.astype(np.float32)[:, :, np.newaxis] / 255.0

    if rgb_f32.shape[0] != target_size or rgb_f32.shape[1] != target_size:
        resized_rgb_u8 = np.asarray(
            Image.fromarray(image_u8, mode="RGB").resize(
                (target_size, target_size), Image.Resampling.BICUBIC
            ),
            dtype=np.uint8,
        )
        resized_mask_u8 = np.asarray(
            Image.fromarray(mask_plane, mode="L").resize(
                (target_size, target_size), Image.Resampling.BICUBIC
            ),
            dtype=np.uint8,
        )
        rgb_f32 = resized_rgb_u8.astype(np.float32) / 255.0
        mask_f32 = resized_mask_u8.astype(np.float32)[:, :, np.newaxis] / 255.0

    x = preprocess(rgb_f32, mask_f32)
    outputs = raw_engine._model(x)
    mx.eval(outputs)

    alpha_coarse = outputs["alpha_coarse"]
    fg_coarse = outputs["fg_coarse"]
    alpha_refined = outputs["alpha_final"]
    fg_refined = outputs["fg_final"]

    use_refiner = bool(getattr(raw_engine, "_use_refiner", True))
    if not use_refiner or refiner_scale == 0.0:
        alpha_out = alpha_coarse
        fg_out = fg_coarse
    elif refiner_scale == 1.0:
        alpha_out = alpha_refined
        fg_out = fg_refined
    else:
        s = refiner_scale
        alpha_out = alpha_coarse * (1.0 - s) + alpha_refined * s
        fg_out = fg_coarse * (1.0 - s) + fg_refined * s

    alpha = np.array(alpha_out[0], dtype=np.float32)
    fg = np.array(fg_out[0], dtype=np.float32)

    if alpha.ndim == 2:
        alpha = alpha[:, :, np.newaxis]

    if alpha.shape[:2] != (original_h, original_w):
        alpha = _resize_float_image_bicubic(alpha, (original_w, original_h))
        fg = _resize_float_image_bicubic(fg, (original_w, original_h))

    return {
        "alpha": np.clip(alpha, 0.0, 1.0).astype(np.float32),
        "fg": np.clip(fg, 0.0, 1.0).astype(np.float32),
    }


class _MLXEngineAdapter:
    """Wraps CorridorKeyMLXEngine to match Torch process_frame() contract."""

    def __init__(self, raw_engine):
        self._engine = raw_engine
        logger.info("MLX adapter: despill/despeckle handled by adapter, not native MLX")

    def process_frame(
        self,
        image,
        mask_linear,
        refiner_scale=_D["refiner_scale"],
        input_is_linear=False,
        fg_is_straight=True,
        despill_strength=_D["despill_strength"],
        auto_despeckle=_D["auto_despeckle"],
        despeckle_size=_D["despeckle_size"],
        despeckle_dilation=_D["despeckle_dilation"],
        despeckle_blur=_D["despeckle_blur"],
        source_passthrough=_D["source_passthrough"],
        edge_erode_px=_D["edge_erode_px"],
        edge_blur_px=_D["edge_blur_px"],
        screen_color=_D["screen_color"],
        garbage_matte_px=_D["garbage_matte_px"],
    ):
        """Delegate to MLX engine, then normalize output to Torch contract."""
        # corridorkey-mlx expects sRGB uint8 input even when input_is_linear=True.
        image_u8 = _prepare_mlx_image_u8(image, input_is_linear)

        if mask_linear.dtype != np.uint8:
            mask_u8 = (np.clip(mask_linear, 0.0, 1.0) * 255).astype(np.uint8)
        else:
            mask_u8 = mask_linear

        # Squeeze mask to 2D for MLX
        if mask_u8.ndim == 3:
            mask_u8 = mask_u8[:, :, 0]

        float_outputs = _try_mlx_float_outputs(self._engine, image_u8, mask_u8, refiner_scale)
        if float_outputs is not None:
            return _assemble_mlx_output(
                alpha=float_outputs["alpha"],
                fg=float_outputs["fg"],
                source_image=image,
                input_is_linear=input_is_linear,
                despill_strength=despill_strength,
                auto_despeckle=auto_despeckle,
                despeckle_size=despeckle_size,
                despeckle_dilation=despeckle_dilation,
                despeckle_blur=despeckle_blur,
                screen_color=screen_color,
                garbage_matte_px=garbage_matte_px,
                mask_linear=mask_linear,
            )

        raw = self._engine.process_frame(
            image_u8,
            mask_u8,
            refiner_scale=refiner_scale,
            input_is_linear=input_is_linear,
            fg_is_straight=fg_is_straight,
            despill_strength=0.0,      # disable MLX stubs — adapter applies these
            auto_despeckle=False,
            despeckle_size=despeckle_size,
        )

        return _wrap_mlx_output(
            raw, image, input_is_linear, despill_strength, auto_despeckle,
            despeckle_size, despeckle_dilation, despeckle_blur,
            screen_color=screen_color,
            garbage_matte_px=garbage_matte_px,
            mask_linear=mask_linear,
        )


DEFAULT_MLX_TILE_SIZE = 512
DEFAULT_MLX_TILE_OVERLAP = 64


def create_engine(
    backend: str | None = None,
    device: str | None = None,
    img_size: int = DEFAULT_IMG_SIZE,
    optimization_mode: str = "auto",
    tile_size: int | None = DEFAULT_MLX_TILE_SIZE,
    overlap: int = DEFAULT_MLX_TILE_OVERLAP,
    on_status=None,
    screen_color: str = "green",
):
    """Factory: returns an engine with process_frame() matching the Torch contract.

    Args:
        backend: 'auto', 'torch', or 'mlx'. None means auto.
        device: Torch device string ('cuda', 'cpu', 'mps'). Ignored for MLX.
        img_size: Model inference resolution.
        optimization_mode: Torch only — 'auto', 'speed', or 'lowvram'.
        tile_size: MLX only — tile size for tiled inference (default 512).
            Set to None to disable tiling and use full-frame inference.
        overlap: MLX only — overlap pixels between tiles (default 64).
        on_status: Optional status callback for UI.
        screen_color: 'green' or 'blue' — selects the matching checkpoint.
    """
    backend = resolve_backend(backend)

    if backend == "mlx":
        ckpt = _discover_checkpoint(MLX_EXT, screen_color=screen_color)

        # Prefer built-in MLX engine (uses our own mlx_model.py)
        try:
            import mlx.core  # noqa: F401
            from CorridorKeyModule.mlx_inference_engine import MLXCorridorKeyEngine

            logger.info("Built-in MLX engine loaded: %s (screen=%s)", ckpt.name, screen_color)
            return MLXCorridorKeyEngine(
                checkpoint_path=str(ckpt),
                img_size=img_size,
                use_refiner=True,
                on_status=on_status,
            )
        except ImportError:
            pass

        # Fall back to external corridorkey_mlx package (legacy)
        from corridorkey_mlx import CorridorKeyMLXEngine  # type: ignore[import-not-found]

        try:
            raw_engine = CorridorKeyMLXEngine(
                str(ckpt), img_size=img_size, tile_size=tile_size, overlap=overlap,
            )
            mode = f"tiled (tile={tile_size}, overlap={overlap})" if tile_size else "full-frame"
        except TypeError:
            raw_engine = CorridorKeyMLXEngine(str(ckpt), img_size=img_size)
            mode = "full-frame (tiling not supported by installed corridorkey_mlx)"
        logger.info("Legacy MLX engine loaded: %s [%s]", ckpt.name, mode)
        return _MLXEngineAdapter(raw_engine)
    else:
        ckpt = _discover_checkpoint(TORCH_EXT, screen_color=screen_color)
        from CorridorKeyModule.inference_engine import CorridorKeyEngine

        logger.info("Torch engine loaded: %s (device=%s, screen=%s)", ckpt.name, device, screen_color)
        return CorridorKeyEngine(
            checkpoint_path=str(ckpt),
            device=device or "cpu",
            img_size=img_size,
            optimization_mode=optimization_mode,
            on_status=on_status,
        )
