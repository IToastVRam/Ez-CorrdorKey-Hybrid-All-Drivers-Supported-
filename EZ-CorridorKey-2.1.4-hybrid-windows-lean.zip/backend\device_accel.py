"""Hybrid compute for EZ-CorridorKey: GPU (CUDA/DirectML) + CPU + system RAM.

Priority (auto):
  1. NVIDIA CUDA if available
  2. AMD DirectML (torch-directml) with VRAM budget
  3. CPU with system RAM buffers

Env overrides:
  CORRIDORKEY_DEVICE=auto|cuda|dml|cpu
  CORRIDORKEY_VRAM_GB=4
  CORRIDORKEY_RAM_BUFFER_GB=10
  CORRIDORKEY_OPT_MODE=lowvram|speed|auto
  CORRIDORKEY_HYBRID=1
"""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_VRAM_GB = 4.0
DEFAULT_RAM_BUFFER_GB = 10.0


def vram_budget_gb() -> float:
    try:
        return float(os.environ.get("CORRIDORKEY_VRAM_GB", DEFAULT_VRAM_GB))
    except ValueError:
        return DEFAULT_VRAM_GB


def ram_buffer_gb() -> float:
    try:
        return float(os.environ.get("CORRIDORKEY_RAM_BUFFER_GB", DEFAULT_RAM_BUFFER_GB))
    except ValueError:
        return DEFAULT_RAM_BUFFER_GB


def system_ram_gb() -> float:
    """Total physical RAM in GB (Windows-friendly)."""
    try:
        import psutil  # type: ignore

        return float(psutil.virtual_memory().total) / (1024**3)
    except Exception:
        pass
    try:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return float(stat.ullTotalPhys) / (1024**3)
    except Exception:
        pass
    return 0.0


def available_ram_gb() -> float:
    try:
        import psutil  # type: ignore

        return float(psutil.virtual_memory().available) / (1024**3)
    except Exception:
        pass
    try:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return float(stat.ullAvailPhys) / (1024**3)
    except Exception:
        pass
    return 0.0


def _dml_available() -> bool:
    try:
        import torch_directml  # noqa: F401

        return True
    except Exception:
        return False


def dml_device():
    import torch_directml

    return torch_directml.device()


def detect_compute_device() -> str:
    """Return cuda | privateuseone | mps | cpu."""
    forced = (os.environ.get("CORRIDORKEY_DEVICE") or "auto").strip().lower()
    try:
        import torch
    except ImportError:
        logger.warning("PyTorch missing — CPU only")
        return "cpu"

    if forced == "cpu":
        return "cpu"
    if forced == "cuda":
        return "cuda" if torch.cuda.is_available() else "cpu"
    if forced in ("dml", "directml"):
        if _dml_available():
            return "privateuseone"
        logger.warning("DirectML requested but torch-directml not installed")
        return "cpu"

    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    if _dml_available():
        logger.info(
            "AMD DirectML hybrid · VRAM budget %.1f GB · RAM buffer %.1f GB (sys %.1f GB)",
            vram_budget_gb(),
            ram_buffer_gb(),
            system_ram_gb(),
        )
        return "privateuseone"
    logger.warning(
        "No CUDA/DirectML — CPU + system RAM (%.1f GB total). "
        "Run installer\\Install-Hybrid-GPU.bat for AMD DirectML.",
        system_ram_gb(),
    )
    return "cpu"


def torch_device(name: str | None = None):
    import torch

    name = name or detect_compute_device()
    if name in ("privateuseone", "dml"):
        try:
            return dml_device()
        except Exception as exc:
            logger.warning("DirectML device failed (%s) — CPU", exc)
            return torch.device("cpu")
    if name == "cuda" and torch.cuda.is_available():
        return torch.device("cuda")
    if name == "mps":
        return torch.device("mps")
    return torch.device("cpu")


def device_label(name: str | None = None) -> str:
    name = name or detect_compute_device()
    ram = system_ram_gb()
    if name == "privateuseone":
        return (
            f"DirectML hybrid (GPU ~{vram_budget_gb():.0f}GB VRAM + "
            f"CPU/RAM buffer {ram_buffer_gb():.0f}GB / sys {ram:.0f}GB)"
        )
    if name == "cuda":
        try:
            import torch

            gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            return f"CUDA ({torch.cuda.get_device_name(0)} · {gb:.1f}GB) + RAM {ram:.0f}GB"
        except Exception:
            return f"CUDA + system RAM {ram:.0f}GB"
    if name == "mps":
        return f"Apple MPS + unified RAM {ram:.0f}GB"
    return f"CPU + system RAM {ram:.0f}GB"


def is_low_vram_device(name: str | None = None) -> bool:
    name = name or detect_compute_device()
    if name in ("cpu", "mps", "privateuseone"):
        return True
    if name == "cuda":
        try:
            import torch

            if torch.cuda.is_available():
                gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
                return gb < 10.0
        except Exception:
            return True
    return vram_budget_gb() < 10.0


def apply_hybrid_env() -> None:
    """Force safe hybrid defaults for 4–8GB GPUs + system RAM offload."""
    os.environ.setdefault("CORRIDORKEY_HYBRID", "1")
    os.environ.setdefault("CORRIDORKEY_OPT_MODE", "lowvram")
    os.environ.setdefault("CORRIDORKEY_VRAM_GB", str(DEFAULT_VRAM_GB))
    # Scale RAM buffer with installed RAM (leave headroom for OS + Resolve)
    total = system_ram_gb()
    if total > 0 and "CORRIDORKEY_RAM_BUFFER_GB" not in os.environ:
        # Use ~40% of RAM up to 16GB, min 8GB on 16+ systems, 6GB on 8–12
        if total >= 32:
            buf = 16.0
        elif total >= 16:
            buf = 10.0
        elif total >= 12:
            buf = 8.0
        else:
            buf = max(4.0, total * 0.35)
        os.environ["CORRIDORKEY_RAM_BUFFER_GB"] = f"{buf:.1f}"
    else:
        os.environ.setdefault("CORRIDORKEY_RAM_BUFFER_GB", str(DEFAULT_RAM_BUFFER_GB))
    os.environ.setdefault("CORRIDORKEY_BIREFNET_DEFAULT", "Matting Lite")
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
    # Encourage CPU threads for hybrid
    try:
        import torch

        threads = max(2, min(8, (os.cpu_count() or 4) // 2))
        torch.set_num_threads(threads)
    except Exception:
        pass


# Back-compat alias
apply_low_vram_env = apply_hybrid_env


def empty_cache(device_name: str | None = None) -> None:
    try:
        import gc

        import torch

        gc.collect()
        name = device_name or detect_compute_device()
        if name == "cuda" and torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


def summarize() -> dict[str, Any]:
    dev = detect_compute_device()
    return {
        "device": dev,
        "label": device_label(dev),
        "vram_budget_gb": vram_budget_gb(),
        "ram_buffer_gb": ram_buffer_gb(),
        "system_ram_gb": round(system_ram_gb(), 1),
        "available_ram_gb": round(available_ram_gb(), 1),
        "low_vram": is_low_vram_device(dev),
        "directml": _dml_available(),
        "hybrid": os.environ.get("CORRIDORKEY_HYBRID", "1") == "1",
        "resolve_exe": os.environ.get("CORRIDORKEY_RESOLVE_EXE", ""),
    }
