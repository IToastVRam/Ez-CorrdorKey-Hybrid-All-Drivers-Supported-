"""DaVinci Resolve menu script: open CorridorKey (AMD hybrid path).

Workspace → Scripts → Utility → CorridorKey Open
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

# Resolve injects `bmd` when run from the Scripts menu.
# Also works if fuscript launches this file.


def _bridge_dir() -> Path:
    # Installed copy under Fusion/Scripts/Utility may be a thin launcher;
    # prefer config next to this file, then E:\Dev path.
    here = Path(__file__).resolve().parent
    for cand in (
        here / "paths.json",
        here.parent / "paths.json",
        Path(r"E:\Dev\EZ-CorridorKey\resolve_bridge\paths.json"),
    ):
        if cand.exists():
            return cand.parent
    return Path(r"E:\Dev\EZ-CorridorKey\resolve_bridge")


def _load() -> dict:
    cfg = _bridge_dir() / "paths.json"
    if cfg.exists():
        data = json.loads(cfg.read_text(encoding="utf-8"))
    else:
        data = {}
    ck = Path(os.path.expandvars(data.get("corridor_key_root", r"E:\Dev\EZ-CorridorKey")))
    bat = Path(os.path.expandvars(data.get("corridor_start_bat", str(ck / "2-start.bat"))))
    resolve_exe = Path(os.path.expandvars(data.get("resolve_exe", r"D:\New Folder\Resolve.exe")))
    return {
        "ck": ck,
        "bat": bat,
        "resolve_exe": resolve_exe,
        "clips": Path(os.path.expandvars(data.get("corridor_clips_in", str(ck / "ClipsForInference")))),
        "output": Path(os.path.expandvars(data.get("corridor_output", str(ck / "Output")))),
    }


def _msg(title: str, body: str) -> None:
    try:
        # Fusion UI dialog if available
        if "fu" in globals():
            fu.ShowMessage(title, body, "OK")  # type: ignore[name-defined]
            return
    except Exception:
        pass
    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(0, body, title, 0x40)
    except Exception:
        print(f"{title}: {body}")


def main() -> None:
    p = _load()
    p["clips"].mkdir(parents=True, exist_ok=True)
    p["output"].mkdir(parents=True, exist_ok=True)

    if not p["bat"].exists() and not (p["ck"] / "main.py").exists():
        _msg(
            "CorridorKey",
            f"CorridorKey not found.\nExpected:\n{p['ck']}\n\nEdit resolve_bridge\\paths.json",
        )
        return

    env = os.environ.copy()
    env["CORRIDORKEY_DEVICE"] = env.get("CORRIDORKEY_DEVICE", "auto")
    env["CORRIDORKEY_OPT_MODE"] = "lowvram"
    env["CORRIDORKEY_VRAM_GB"] = "4"
    env["CORRIDORKEY_RAM_BUFFER_GB"] = "10"
    env["CORRIDORKEY_RESOLVE_EXE"] = str(p["resolve_exe"])
    env["CORRIDORKEY_RESOLVE_ROOT"] = str(p["resolve_exe"].parent)

    if p["bat"].exists():
        subprocess.Popen(
            ["cmd.exe", "/c", "start", "", str(p["bat"])],
            cwd=str(p["ck"]),
            env=env,
            shell=False,
        )
    else:
        py = p["ck"] / ".venv" / "Scripts" / "pythonw.exe"
        if not py.exists():
            py = Path(sys.executable)
        subprocess.Popen([str(py), str(p["ck"] / "main.py")], cwd=str(p["ck"]), env=env)

    _msg(
        "CorridorKey",
        "Launched CorridorKey (AMD 4GB + CPU hybrid).\n\n"
        f"Clips in:\n{p['clips']}\n\n"
        f"Output:\n{p['output']}\n\n"
        f"Resolve:\n{p['resolve_exe']}",
    )


if __name__ == "__main__":
    main()
