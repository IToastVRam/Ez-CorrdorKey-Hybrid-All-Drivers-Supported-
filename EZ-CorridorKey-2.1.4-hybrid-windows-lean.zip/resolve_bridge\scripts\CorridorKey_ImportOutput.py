"""DaVinci Resolve: import CorridorKey Output folder into the Media Pool.

Workspace → Scripts → Edit → CorridorKey Import Output
"""

from __future__ import annotations

import json
import os
from pathlib import Path


def _load() -> dict:
    for cfg in (
        Path(__file__).resolve().parent / "paths.json",
        Path(r"E:\Dev\EZ-CorridorKey\resolve_bridge\paths.json"),
    ):
        if cfg.exists():
            data = json.loads(cfg.read_text(encoding="utf-8"))
            break
    else:
        data = {}
    ck = Path(os.path.expandvars(data.get("corridor_key_root", r"E:\Dev\EZ-CorridorKey")))
    return {
        "output": Path(os.path.expandvars(data.get("corridor_output", str(ck / "Output")))),
        "resolve_exe": Path(os.path.expandvars(data.get("resolve_exe", r"D:\New Folder\Resolve.exe"))),
    }


def _msg(title: str, body: str) -> None:
    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(0, body, title, 0x40)
    except Exception:
        print(title, body)


def _get_resolve():
    try:
        return bmd.scriptapp("Resolve")  # type: ignore[name-defined]
    except Exception:
        pass
    try:
        import DaVinciResolveScript as dvr  # type: ignore

        return dvr.scriptapp("Resolve")
    except Exception:
        return None


def main() -> None:
    p = _load()
    out = p["output"]
    if not out.exists():
        _msg("CorridorKey Import", f"Output folder not found:\n{out}")
        return

    # Collect recent media files
    exts = {".mp4", ".mov", ".mxf", ".avi", ".mkv", ".png", ".exr", ".tif", ".tiff", ".jpg"}
    files = []
    for f in out.rglob("*"):
        if f.is_file() and f.suffix.lower() in exts:
            files.append(str(f))
    files = sorted(files, key=lambda s: os.path.getmtime(s), reverse=True)[:80]

    if not files:
        _msg("CorridorKey Import", f"No media found under:\n{out}")
        return

    resolve = _get_resolve()
    if resolve is None:
        _msg(
            "CorridorKey Import",
            "Could not attach to Resolve API.\n"
            "Run this from Workspace → Scripts while Resolve is open.\n\n"
            f"Files ready at:\n{out}",
        )
        return

    pm = resolve.GetProjectManager()
    project = pm.GetCurrentProject() if pm else None
    if not project:
        _msg("CorridorKey Import", "No project open in Resolve.")
        return

    media_pool = project.GetMediaPool()
    imported = media_pool.ImportMedia(files) if media_pool else None
    count = len(imported) if imported else 0
    _msg(
        "CorridorKey Import",
        f"Imported {count} item(s) into Media Pool from:\n{out}\n\n"
        f"Resolve: {p['resolve_exe']}",
    )


if __name__ == "__main__":
    main()
