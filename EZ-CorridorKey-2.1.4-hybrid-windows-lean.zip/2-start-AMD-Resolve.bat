@echo off
TITLE EZ-CorridorKey (AMD 4GB + Resolve)
cd /d "%~dp0"

REM --- Path to your DaVinci Resolve install ---
set "CORRIDORKEY_RESOLVE_EXE=D:\New Folder\Resolve.exe"
set "CORRIDORKEY_RESOLVE_ROOT=D:\New Folder"
if exist "%~dp0resolve_bridge\paths.json" (
  for /f "usebackq tokens=2 delims=:, " %%A in (`findstr /i "resolve_exe" "%~dp0resolve_bridge\paths.json"`) do (
    set "TMP=%%~A"
  )
)

REM --- AMD RX 580 class: DirectML hybrid + 4GB VRAM budget + CPU offload ---
set "CORRIDORKEY_DEVICE=auto"
set "CORRIDORKEY_OPT_MODE=lowvram"
set "CORRIDORKEY_VRAM_GB=4"
set "CORRIDORKEY_RAM_BUFFER_GB=10"
set "CORRIDORKEY_BIREFNET_DEFAULT=Matting Lite"

if not exist ".venv\Scripts\activate.bat" (
  echo [INFO] .venv missing — run 1-install.bat first, then Install_AMD_DirectML.bat
  pause
  exit /b 1
)

if exist "%~dp0tools\ffmpeg\bin\ffmpeg.exe" set "PATH=%~dp0tools\ffmpeg\bin;%PATH%"

call .venv\Scripts\activate.bat
echo Resolve: %CORRIDORKEY_RESOLVE_EXE%
echo CorridorKey AMD hybrid start...
start "" pythonw main.py %*
exit
